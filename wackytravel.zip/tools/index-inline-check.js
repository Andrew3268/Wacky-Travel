
    const $ = (id) => document.getElementById(id);
    const escapeHtml = (value) => String(value || "").replace(/[&<>'"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[ch]));
    const safeArray = (value) => { try { const parsed = JSON.parse(value || "[]"); return Array.isArray(parsed) ? parsed : []; } catch { return []; } };
    const normalizeText = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const slugify = (value) => normalizeText(value).toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9가-힣_-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    const HOME_DESTINATION_LIMIT = 5;
    const HOME_HOTEL_LIMIT = 6;

    const state = {
      isAdmin: false,
      countries: [],
      destinations: [],
      hotelPosts: [],
      posts: []
    };

    const countrySlugAliases = { 베트남: 'vietnam', 일본: 'japan', 태국: 'thailand', 대한민국: 'korea', 한국: 'korea', 대만: 'taiwan', 싱가포르: 'singapore', 말레이시아: 'malaysia', 인도네시아: 'indonesia', 필리핀: 'philippines', 홍콩: 'hong-kong', 마카오: 'macau', 중국: 'china', 미국: 'usa', 프랑스: 'france', 이탈리아: 'italy', 스페인: 'spain' };
    const slugifyCountry = (value) => {
      const raw = normalizeText(value);
      if (!raw) return '';
      if (countrySlugAliases[raw]) return countrySlugAliases[raw];
      return slugify(raw);
    };

    function getCountrySlugFromName(countryName) {
      const raw = normalizeText(countryName);
      const found = state.countries.find((country) => normalizeText(country.name) === raw);
      return found?.slug || slugifyCountry(raw);
    }

    function getCountryNameBySlug(slug) {
      const found = state.countries.find((country) => String(country.slug || '') === String(slug || ''));
      return found?.name || '';
    }

    async function fetchJson(url, options = {}) {
      const res = await fetch(url, { credentials: 'same-origin', cache: 'no-store', ...options });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json?.message || '요청에 실패했습니다.');
      return json;
    }

    async function requestTravelSettings(method, payload) {
      return fetchJson(`/api/travel-settings?ts=${Date.now()}`, {
        method,
        headers: { Accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify(payload)
      });
    }

    function mergeDestinationSources(primaryItems = [], settingItems = []) {
      const bySlug = new Map();
      const mergeItem = (item = {}) => {
        const slug = String(item.slug || '').trim();
        if (!slug) return;
        const previous = bySlug.get(slug) || {};
        bySlug.set(slug, { ...previous, ...item });
      };
      primaryItems.forEach(mergeItem);
      settingItems.forEach(mergeItem);
      return Array.from(bySlug.values());
    }

    async function loadHome() {
      const [destRes, settingsRes, hotelRes, postRes, adminRes] = await Promise.all([
        fetch('/api/destinations?limit=100', { cache: 'no-store' }).catch(() => null),
        fetch(`/api/travel-settings?ts=${Date.now()}`, { cache: 'no-store' }).catch(() => null),
        fetch(`/api/posts?per_page=${HOME_HOTEL_LIMIT}&content_type=top5_series&sort=published&ts=${Date.now()}`, { cache: 'no-store' }).catch(() => null),
        fetch('/api/posts?per_page=6').catch(() => null),
        fetch('/api/admin/session', { credentials: 'same-origin' }).catch(() => null)
      ]);
      const destData = destRes ? await destRes.json().catch(() => ({ items: [] })) : { items: [] };
      const settingsData = settingsRes ? await settingsRes.json().catch(() => ({ countries: [], destinations: [] })) : { countries: [], destinations: [] };
      const hotelPostData = hotelRes ? await hotelRes.json().catch(() => ({ items: [] })) : { items: [] };
      const postData = postRes ? await postRes.json().catch(() => ({ items: [] })) : { items: [] };
      const adminData = adminRes ? await adminRes.json().catch(() => ({ authenticated: false })) : { authenticated: false };

      state.isAdmin = Boolean(adminData.authenticated);
      state.countries = Array.isArray(settingsData.countries) ? settingsData.countries : [];
      state.destinations = mergeDestinationSources(
        Array.isArray(destData.items) ? destData.items : [],
        Array.isArray(settingsData.destinations) ? settingsData.destinations : []
      );
      state.hotelPosts = Array.isArray(hotelPostData.items) ? hotelPostData.items : [];
      state.posts = Array.isArray(postData.items) ? postData.items : [];

      renderDestinations();
      renderHotels();
      renderPosts();
    }

    async function reloadDestinations() {
      const [destData, settingsData] = await Promise.all([
        fetchJson('/api/destinations?limit=100'),
        fetchJson('/api/travel-settings')
      ]);
      state.destinations = mergeDestinationSources(
        Array.isArray(destData.items) ? destData.items : [],
        Array.isArray(settingsData.destinations) ? settingsData.destinations : []
      );
      state.countries = Array.isArray(settingsData.countries) ? settingsData.countries : [];
      renderDestinations();
    }

    function getActiveCountriesForHub() {
      const activeCountries = state.countries.filter((country) => Number(country.is_active ?? 1) === 1);
      const namesInDestinations = new Set(state.destinations.map((item) => normalizeText(item.country)).filter(Boolean));
      const merged = [...activeCountries];
      namesInDestinations.forEach((name) => {
        if (!merged.some((country) => normalizeText(country.name) === name)) {
          merged.push({ slug: slugifyCountry(name), name, sort_order: 999, is_active: 1 });
        }
      });
      return merged.sort((a, b) => {
        const ao = Number(a.sort_order || 0) || 999;
        const bo = Number(b.sort_order || 0) || 999;
        if (ao !== bo) return ao - bo;
        return String(a.name || '').localeCompare(String(b.name || ''), 'ko');
      });
    }

    function isPublishedDestination(item) {
      return String(item.status || 'published') === 'published' && Number(item.is_active ?? 1) === 1;
    }

    function compareDestinations(a, b) {
      const ao = Number(a.sort_order || 0) || 999;
      const bo = Number(b.sort_order || 0) || 999;
      if (ao !== bo) return ao - bo;
      return String(a.name || a.title || '').localeCompare(String(b.name || b.title || ''), 'ko');
    }

    function compareHomeDestinations(a, b) {
      const ao = Number(a.home_featured_order || 0) || 999;
      const bo = Number(b.home_featured_order || 0) || 999;
      if (ao !== bo) return ao - bo;
      return compareDestinations(a, b);
    }

    function destinationBelongsToCountry(item, countryName = '', countrySlug = '') {
      const normalizedCountryName = normalizeText(countryName);
      const itemCountryName = normalizeText(item.country);
      if (normalizedCountryName && itemCountryName === normalizedCountryName) return true;
      const normalizedCountrySlug = String(countrySlug || '').trim();
      const itemCountrySlug = String(item.country_slug || getCountrySlugFromName(itemCountryName) || slugifyCountry(itemCountryName)).trim();
      return Boolean(normalizedCountrySlug && itemCountrySlug === normalizedCountrySlug);
    }

    function getFallbackHubDestinationsForCountry(countryName = '', countrySlug = '') {
      return state.destinations
        .filter((item) => isPublishedDestination(item) && destinationBelongsToCountry(item, countryName, countrySlug))
        .sort(compareDestinations)
        .slice(0, HOME_DESTINATION_LIMIT);
    }

    function getHomeHubDestinationsForCountry(countryName = '', countrySlug = '', { includeFallback = false } = {}) {
      const featuredItems = state.destinations
        .filter((item) => isPublishedDestination(item) && Number(item.home_featured || 0) === 1 && destinationBelongsToCountry(item, countryName, countrySlug))
        .sort(compareHomeDestinations)
        .slice(0, HOME_DESTINATION_LIMIT);
      if (featuredItems.length || !includeFallback) return featuredItems;
      return getFallbackHubDestinationsForCountry(countryName, countrySlug);
    }

    function renderDestinations() {
      const container = $('homeDestinations');
      const countries = getActiveCountriesForHub();
      const countryGroups = countries
        .map((country) => {
          const countryName = country.name || '기타 여행지';
          const countrySlug = country.slug || slugifyCountry(countryName);
          const items = getHomeHubDestinationsForCountry(countryName, countrySlug, { includeFallback: true });
          return { country, countryName, countrySlug, items };
        })
        .filter((group) => group.items.length);
      container.innerHTML = countryGroups.map(({ countryName, countrySlug, items }) => {
        return `<section class="country-destination-group country-destination-group--compact" aria-labelledby="country-${escapeHtml(countrySlug)}">
          <div class="country-destination-group__head">
            <div class="country-destination-group__title">
              <h3 id="country-${escapeHtml(countrySlug)}">${escapeHtml(countryName)}</h3>
            </div>
            <div class="country-destination-group__actions">
              <a class="country-destination-group__link" href="/countries/${encodeURIComponent(countrySlug)}">${escapeHtml(countryName)} 전체 보기 <span aria-hidden="true">→</span></a>
            </div>
          </div>
          <div class="destination-chip-list" aria-label="${escapeHtml(countryName)} 도시 목록">
            ${items.length ? items.map(renderDestinationCard).join('') : `<div class="empty-card empty-card--compact">여행지 허브에 노출할 ${escapeHtml(countryName)} 도시를 선택해 보세요.</div>`}
          </div>
        </section>`;
      }).join('') || '<div class="empty-card">여행지 허브에 노출할 도시를 선택하세요.</div>';
    }

    function getDestinationPreviewText(item, label) {
      const raw = normalizeText(item.card_description)
        || normalizeText(item.hero_summary)
        || normalizeText(item.meta_description)
        || normalizeText(item.summary)
        || `${label} 여행 정보와 호텔 추천을 모아볼 수 있는 도시입니다.`;
      const cleaned = raw
        .replace(/[#*_`>\[\](){}|~]/g, ' ')
        .replace(/https?:\/\/\S+/g, '')
        .replace(/\s+/g, ' ')
        .trim();
      const withoutDuplicate = cleaned.startsWith(label) ? cleaned.slice(label.length).replace(/^[\s·:：,.-]+/, '') : cleaned;
      return withoutDuplicate.length > 48 ? `${withoutDuplicate.slice(0, 48).trim()}…` : withoutDuplicate;
    }

    function renderDestinationCard(item) {
      const label = normalizeText(item.city) || normalizeText(item.name) || normalizeText(item.title) || '여행지';
      const href = `/destinations/${encodeURIComponent(item.slug || '')}`;
      return `<div class="destination-chip destination-chip--editable">
        <span class="destination-chip__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" focusable="false" role="img" aria-hidden="true">
            <path d="M12 21s6-5.4 6-11a6 6 0 1 0-12 0c0 5.6 6 11 6 11Z"></path>
            <circle cx="12" cy="10" r="2.2"></circle>
          </svg>
        </span>
        <a class="destination-chip__link" href="${href}" aria-label="${escapeHtml(label)} 여행지 보기">
          <span class="destination-chip__name">${escapeHtml(label)}</span>
        </a>
        <a class="destination-chip__arrow" href="${href}" aria-label="${escapeHtml(label)} 여행지 보기">
          <svg viewBox="0 0 24 24" focusable="false" role="img" aria-hidden="true">
            <path d="M5 12h12"></path>
            <path d="m13 6 6 6-6 6"></path>
          </svg>
        </a>
      </div>`;
    }

    function isTop5HotelSeriesPost(item = {}) {
      return String(item.content_type || '').trim() === 'top5_series';
    }

    function getPostTimeValue(item = {}) {
      const raw = item.published_at || item.updated_at || '';
      const time = new Date(raw).getTime();
      return Number.isFinite(time) ? time : 0;
    }

    function getHomeHotelPosts() {
      return state.hotelPosts
        .filter(isTop5HotelSeriesPost)
        .sort((a, b) => getPostTimeValue(b) - getPostTimeValue(a))
        .slice(0, HOME_HOTEL_LIMIT);
    }

    function toggleVisibilityByItems(elementId, items = []) {
      const element = $(elementId);
      if (!element) return;
      element.hidden = !Array.isArray(items) || items.length === 0;
    }

    function renderHotels() {
      const items = getHomeHotelPosts();
      toggleVisibilityByItems('homeHotelPostsSection', items);
      const container = $('homeHotels');
      if (!container) return;
      if (!items.length) {
        container.innerHTML = '';
        return;
      }
      container.innerHTML = items.map((item) => {
        const slug = String(item.slug || '');
        const href = `/post/${encodeURIComponent(slug)}`;
        const tags = safeArray(item.tags_json).slice(0, 3);
        const meta = [labelHotelPostType(item.content_type), item.category].filter(Boolean).join(' · ');
        const title = getHotelCardTitle(item);
        return `<article class="travel-card hotel-card">
          ${item.cover_image ? `<a class="travel-card__media" href="${href}"><img src="${escapeHtml(item.cover_image)}" alt="${escapeHtml(item.cover_image_alt || title)}" loading="lazy" decoding="async" /></a>` : ''}
          <div class="travel-card__body"><div class="travel-card__meta">${escapeHtml(meta)}</div><h3><a href="${href}">${escapeHtml(title)}</a></h3><p>${escapeHtml(item.summary || '도시별 호텔을 한 번에 비교할 수 있는 추천 시리즈입니다.')}</p>${tags.length ? `<div class="tag-row">${tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join('')}</div>` : ''}<a class="btn btn--brand affiliate-btn" href="${href}">호텔 추천 보기</a></div>
        </article>`;
      }).join('');
    }

    function getHotelCardTitle(item = {}) {
      if (String(item.content_type || '').trim() === 'hotel_intro') {
        return item.hotel_name || extractHotelNameFromTitle(item.title) || item.title || '추천 호텔 리뷰';
      }
      return item.title || '호텔 추천 글';
    }

    function extractHotelNameFromTitle(title = '') {
      const clean = String(title || '').replace(/^#+\s*/, '').trim();
      if (!clean) return '';
      const firstClause = clean.split(/[,.，、|｜?？!！]/)[0].trim();
      return firstClause
        .replace(/\s*(추천|후기|리뷰|가격|위치|예약|조식|가성비|숙소|호텔 선택|체크포인트).*$/i, '')
        .trim() || firstClause;
    }

    function labelHotelPostType(value) {
      const type = String(value || '').trim();
      if (type === 'top5_series') return '여행 스타일별 호텔 추천';
      if (type === 'hotel_intro') return '추천 호텔 리뷰';
      return type || '호텔 글';
    }

    function renderPosts() {
      const items = Array.isArray(state.posts) ? state.posts : [];
      toggleVisibilityByItems('homePostsSection', items);
      toggleVisibilityByItems('homePostsNavLink', items);
      const container = $('homePosts');
      if (!container) return;
      if (!items.length) {
        container.innerHTML = '';
        return;
      }
      container.innerHTML = items.map((post) => {
        const slug = String(post.slug || '');
        const adminActions = state.isAdmin ? `
          <div class="post-admin-mini-actions" aria-label="글 관리">
            <a class="post-admin-mini-btn" href="/edit.html?slug=${encodeURIComponent(slug)}">수정</a>
            <button class="post-admin-mini-btn post-admin-mini-btn--danger js-delete-post" type="button" data-slug="${escapeHtml(slug)}" data-title="${escapeHtml(post.title)}">삭제</button>
          </div>
        ` : '';
        return `
          <article class="travel-list__item">
            <div>
              <div class="travel-card__meta">${escapeHtml(post.content_type || '여행 글')}</div>
              <h3><a href="/post/${encodeURIComponent(slug)}">${escapeHtml(post.title)}</a></h3>
              <p>${escapeHtml(post.summary)}</p>
            </div>
            <div class="travel-list__actions">
              <a class="text-link" href="/post/${encodeURIComponent(slug)}">읽기</a>
              ${adminActions}
            </div>
          </article>
        `;
      }).join('');
    }

    function getHomeManagerCountry() {
      const countrySlug = String($('homeDestinationCountrySlug')?.value || '').trim();
      const countryName = normalizeText($('homeDestinationCountryName')?.value || getCountryNameBySlug(countrySlug));
      return { countrySlug, countryName };
    }

    function getSortedDestinationList(countrySlug = '', countryName = '') {
      return state.destinations
        .filter((item) => destinationBelongsToCountry(item, countryName, countrySlug))
        .sort((a, b) => {
          const af = Number(a.home_featured || 0) === 1 ? 0 : 1;
          const bf = Number(b.home_featured || 0) === 1 ? 0 : 1;
          if (af !== bf) return af - bf;
          if (af === 0) return compareHomeDestinations(a, b);
          return compareDestinations(a, b);
        });
    }

    function getSelectedHomeDestinationSlugs() {
      return Array.from(document.querySelectorAll('[data-home-destination-row]'))
        .filter((row) => row.querySelector('[data-home-destination-slug]')?.checked)
        .map((row) => row.dataset.homeDestinationRow || row.querySelector('[data-home-destination-slug]')?.value || '')
        .filter(Boolean);
    }

    function getHomeDestinationSelectionCount() {
      return new Set(getSelectedHomeDestinationSlugs()).size;
    }

    function updateHomeDestinationCount() {
      const countEl = $('homeDestinationCount');
      if (!countEl) return;
      const { countryName } = getHomeManagerCountry();
      countEl.textContent = `${countryName || '현재 나라'} ${getHomeDestinationSelectionCount()}/${HOME_DESTINATION_LIMIT} 선택`;
    }

    function updateHomeDestinationOrderBadges() {
      const rows = Array.from(document.querySelectorAll('[data-home-destination-row]'));
      const selectedRows = rows.filter((row) => row.querySelector('[data-home-destination-slug]')?.checked);
      rows.forEach((row) => {
        const input = row.querySelector('[data-home-destination-slug]');
        const controls = row.querySelector('[data-home-destination-controls]');
        const badge = row.querySelector('[data-home-destination-order-badge]');
        const isChecked = Boolean(input?.checked);
        row.classList.toggle('is-selected', isChecked);
        if (controls) controls.hidden = !isChecked;
        if (badge && !isChecked) badge.textContent = '미노출';
      });
      selectedRows.forEach((row, index) => {
        const badge = row.querySelector('[data-home-destination-order-badge]');
        const upBtn = row.querySelector('[data-home-destination-move="up"]');
        const downBtn = row.querySelector('[data-home-destination-move="down"]');
        if (badge) badge.textContent = `노출 ${index + 1}`;
        if (upBtn) upBtn.disabled = index === 0;
        if (downBtn) downBtn.disabled = index === selectedRows.length - 1;
      });
      updateHomeDestinationCount();
    }

    function renderHomeDestinationChecklist() {
      const list = $('homeDestinationChecklist');
      const { countrySlug, countryName } = getHomeManagerCountry();
      const items = getSortedDestinationList(countrySlug, countryName);
      if ($('homeDestinationCountryHeading')) {
        $('homeDestinationCountryHeading').textContent = `${countryName || '현재 나라'} 인기 도시 노출 선택`;
      }

      if (!items.length) {
        list.innerHTML = `<div class="home-destination-empty small">${escapeHtml(countryName || '현재 나라')}에 아직 추가된 도시가 없습니다. 먼저 + 도시추가로 도시를 등록한 뒤 인기 도시를 선택해 주세요.</div>`;
        updateHomeDestinationCount();
        return;
      }

      list.innerHTML = items.map((item) => {
        const slug = String(item.slug || '');
        const label = normalizeText(item.city) || normalizeText(item.name) || slug;
        const isChecked = Number(item.home_featured || 0) === 1;
        return `<div class="home-destination-option ${isChecked ? 'is-selected' : ''}" data-home-destination-row="${escapeHtml(slug)}">
          <label class="home-destination-option__main">
            <input type="checkbox" value="${escapeHtml(slug)}" data-home-destination-slug="${escapeHtml(slug)}" ${isChecked ? 'checked' : ''} />
            <span class="home-destination-option__body">
              <strong>${escapeHtml(label)}</strong>
              <em>${escapeHtml(countryName || item.country || '기타')}</em>
            </span>
          </label>
          <div class="home-destination-option__controls" data-home-destination-controls ${isChecked ? '' : 'hidden'}>
            <span class="home-destination-option__badge" data-home-destination-order-badge>${isChecked ? '노출 중' : '미노출'}</span>
            <button class="home-destination-option__move" type="button" data-home-destination-move="up" data-slug="${escapeHtml(slug)}" aria-label="${escapeHtml(label)} 순서 올리기">↑</button>
            <button class="home-destination-option__move" type="button" data-home-destination-move="down" data-slug="${escapeHtml(slug)}" aria-label="${escapeHtml(label)} 순서 내리기">↓</button>
          </div>
        </div>`;
      }).join('');
      updateHomeDestinationOrderBadges();
    }

    function enforceHomeDestinationLimit(changedInput = null) {
      const count = getHomeDestinationSelectionCount();
      if (count <= HOME_DESTINATION_LIMIT) {
        updateHomeDestinationOrderBadges();
        return true;
      }
      if (changedInput) changedInput.checked = false;
      updateHomeDestinationOrderBadges();
      setHomeDestinationManagerStatus(`해당 나라의 여행지 허브에는 최대 ${HOME_DESTINATION_LIMIT}개 도시만 노출할 수 있습니다.`, true);
      return false;
    }

    function moveHomeDestinationRow(slug = '', direction = 'up') {
      const list = $('homeDestinationChecklist');
      if (!list) return;
      const selectedRows = Array.from(list.querySelectorAll('[data-home-destination-row]'))
        .filter((row) => row.querySelector('[data-home-destination-slug]')?.checked);
      const currentIndex = selectedRows.findIndex((row) => String(row.dataset.homeDestinationRow || '') === String(slug || ''));
      if (currentIndex < 0) return;
      const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
      if (targetIndex < 0 || targetIndex >= selectedRows.length) return;
      const currentRow = selectedRows[currentIndex];
      const targetRow = selectedRows[targetIndex];
      if (direction === 'up') {
        list.insertBefore(currentRow, targetRow);
      } else {
        list.insertBefore(targetRow, currentRow);
      }
      updateHomeDestinationOrderBadges();
    }

    async function saveHomeDestinationSelection() {
      const slugs = getSelectedHomeDestinationSlugs();
      if (slugs.length > HOME_DESTINATION_LIMIT) {
        throw new Error(`해당 나라의 여행지 허브에는 최대 ${HOME_DESTINATION_LIMIT}개 도시만 노출할 수 있습니다.`);
      }
      const { countrySlug, countryName } = getHomeManagerCountry();
      await requestTravelSettings('PUT', {
        entity: 'home_destinations',
        current_slug: countrySlug || 'home-destinations',
        country_slug: countrySlug,
        country: countryName,
        slugs: slugs.slice(0, HOME_DESTINATION_LIMIT)
      });
    }

    function openHomeDestinationManager(countrySlug = '', fallbackCountryName = '') {
      if (!state.isAdmin) return;
      const countryName = normalizeText(fallbackCountryName) || getCountryNameBySlug(countrySlug) || getActiveCountriesForHub().find((country) => String(country.slug || '') === String(countrySlug || ''))?.name || '';
      $('homeDestinationCountrySlug').value = countrySlug || slugifyCountry(countryName);
      $('homeDestinationCountryName').value = countryName;
      $('homeDestinationManagerTitle').textContent = `${countryName || '현재 나라'} 인기 도시 관리`;
      $('homeDestinationManagerBackdrop').hidden = false;
      $('homeDestinationManagerModal').hidden = false;
      $('homeDestinationManagerModal').setAttribute('aria-hidden', 'false');
      $('homeDestinationManagerModal').classList.add('is-open');
      document.body.classList.add('has-preview-open');
      setHomeDestinationManagerStatus('');
      renderHomeDestinationChecklist();
    }

    function closeHomeDestinationManager() {
      $('homeDestinationManagerModal').classList.remove('is-open');
      $('homeDestinationManagerModal').setAttribute('aria-hidden', 'true');
      $('homeDestinationManagerModal').hidden = true;
      $('homeDestinationManagerBackdrop').hidden = true;
      document.body.classList.remove('has-preview-open');
    }

    async function submitHomeDestinationManager(event) {
      event.preventDefault();
      if (getHomeDestinationSelectionCount() > HOME_DESTINATION_LIMIT) {
        setHomeDestinationManagerStatus(`해당 나라의 여행지 허브에는 최대 ${HOME_DESTINATION_LIMIT}개 도시만 노출할 수 있습니다.`, true);
        return;
      }
      try {
        setHomeDestinationManagerStatus('저장 중입니다...');
        await saveHomeDestinationSelection();
        await reloadDestinations();
        setHomeDestinationManagerStatus('저장되었습니다.');
        closeHomeDestinationManager();
      } catch (error) {
        setHomeDestinationManagerStatus(error.message || '저장에 실패했습니다.', true);
      }
    }

    function setDestinationManagerStatus(message = '', isError = false) {
      const el = $('destinationManagerStatus');
      if (!el) return;
      el.textContent = message;
      el.style.color = isError ? '#b91c1c' : '';
    }

    function setHomeDestinationManagerStatus(message = '', isError = false) {
      const el = $('homeDestinationManagerStatus');
      if (!el) return;
      el.textContent = message;
      el.style.color = isError ? '#b91c1c' : '';
    }

    function renderDestinationCountryOptions(selectedSlug = '') {
      const select = $('dmCountry');
      const countries = getActiveCountriesForHub();
      select.innerHTML = countries.map((country) => `<option value="${escapeHtml(country.slug || slugifyCountry(country.name))}">${escapeHtml(country.name || country.slug)}</option>`).join('');
      select.value = selectedSlug || countries[0]?.slug || '';
    }

    function fillDestinationForm(item = {}, countrySlug = '') {
      const countryName = item.country || getCountryNameBySlug(countrySlug);
      const selectedCountrySlug = getCountrySlugFromName(countryName) || countrySlug;
      renderDestinationCountryOptions(selectedCountrySlug);
      $('dmName').value = item.name || '';
      $('dmSlug').value = item.slug || '';
      $('dmCity').value = item.city || item.name || '';
      $('dmStatus').value = item.status || 'published';
      $('dmSortOrder').value = Number(item.sort_order || 0) || '';
      $('dmHeroEyebrow').value = item.hero_eyebrow || item.country || countryName || '';
      $('dmHeroTitle').value = item.hero_title || item.title || (item.name ? `${item.name} 여행 가이드` : '');
      $('dmHeroSummary').value = item.hero_summary || item.summary || '';
      $('dmHeroImage').value = item.hero_image || item.cover_image || '';
      $('dmHeroImageAlt').value = item.hero_image_alt || item.cover_image_alt || '';
      $('dmCardTitle').value = item.card_title || '';
      $('dmCardDescription').value = item.card_description || '';
      $('dmBestSeason').value = item.best_season || '';
      $('dmAirportInfo').value = item.airport_info || '';
      $('dmTransportSummary').value = item.transport_summary || '';
      $('dmMetaDescription').value = item.meta_description || '';
    }

    function openDestinationManager({ mode = 'create', item = null, countrySlug = '' } = {}) {
      if (!state.isAdmin) return;
      $('destinationMode').value = mode;
      $('destinationCurrentSlug').value = item?.slug || '';
      $('destinationManagerTitle').textContent = mode === 'edit' ? '도시 수정' : '도시 추가';
      $('destinationSubmitBtn').textContent = mode === 'edit' ? '수정하기' : '저장하기';
      $('deleteDestinationBtn').hidden = mode !== 'edit';
      fillDestinationForm(item || {}, countrySlug);
      $('destinationManagerBackdrop').hidden = false;
      $('destinationManagerModal').hidden = false;
      $('destinationManagerModal').setAttribute('aria-hidden', 'false');
      $('destinationManagerModal').classList.add('is-open');
      document.body.classList.add('has-preview-open');
      setDestinationManagerStatus('');
    }

    function closeDestinationManager() {
      $('destinationManagerModal').classList.remove('is-open');
      $('destinationManagerModal').setAttribute('aria-hidden', 'true');
      $('destinationManagerModal').hidden = true;
      $('destinationManagerBackdrop').hidden = true;
      document.body.classList.remove('has-preview-open');
    }

    function readDestinationFormPayload() {
      const countrySlug = $('dmCountry').value;
      const country = getCountryNameBySlug(countrySlug);
      const name = normalizeText($('dmName').value);
      const formSlug = slugify($('dmSlug').value || name);
      const heroTitle = normalizeText($('dmHeroTitle').value) || `${name} 여행 가이드`;
      const summary = normalizeText($('dmHeroSummary').value);
      const heroImage = normalizeText($('dmHeroImage').value);
      const heroImageAlt = normalizeText($('dmHeroImageAlt').value);
      const cardTitle = normalizeText($('dmCardTitle').value);
      const cardDescription = normalizeText($('dmCardDescription').value);
      return {
        entity: 'destination',
        current_slug: $('destinationCurrentSlug').value,
        slug: formSlug,
        name,
        country_slug: countrySlug,
        country,
        city: normalizeText($('dmCity').value) || name,
        status: $('dmStatus').value || 'published',
        is_active: $('dmStatus').value === 'published' ? 1 : 0,
        sort_order: Number($('dmSortOrder').value || 0) || 0,
        summary,
        cover_image: heroImage,
        cover_image_alt: heroImageAlt,
        card_title: cardTitle,
        card_description: cardDescription,
        card_image: heroImage,
        card_image_alt: heroImageAlt,
        hero_eyebrow: normalizeText($('dmHeroEyebrow').value) || country,
        hero_title: heroTitle,
        hero_summary: summary,
        hero_image: heroImage,
        hero_image_alt: heroImageAlt,
        title: heroTitle,
        meta_description: normalizeText($('dmMetaDescription').value),
        best_season: normalizeText($('dmBestSeason').value),
        airport_info: normalizeText($('dmAirportInfo').value),
        transport_summary: normalizeText($('dmTransportSummary').value)
      };
    }

    async function saveDestination(event) {
      event.preventDefault();
      const mode = $('destinationMode').value;
      const payload = readDestinationFormPayload();
      if (!payload.name || !payload.slug || !payload.country) {
        setDestinationManagerStatus('나라, 도시명, slug를 입력해 주세요.', true);
        return;
      }
      try {
        setDestinationManagerStatus('저장 중입니다...');
        await requestTravelSettings(mode === 'edit' ? 'PUT' : 'POST', payload);
        await reloadDestinations();
        setDestinationManagerStatus('저장되었습니다.');
        closeDestinationManager();
      } catch (error) {
        setDestinationManagerStatus(error.message || '저장에 실패했습니다.', true);
      }
    }

    async function deleteDestination() {
      const slug = $('destinationCurrentSlug').value;
      const name = $('dmName').value || slug;
      if (!slug) return;
      const ok = window.confirm(`'${name}' 도시를 비공개 처리할까요?\n연결된 글은 보존되지만 index와 도시 목록에서는 숨겨집니다.`);
      if (!ok) return;
      try {
        setDestinationManagerStatus('비공개 처리 중입니다...');
        await requestTravelSettings('DELETE', { entity: 'destination', slug });
        await reloadDestinations();
        closeDestinationManager();
      } catch (error) {
        setDestinationManagerStatus(error.message || '비공개 처리에 실패했습니다.', true);
      }
    }

    function bindHomeHeroSearch() {
      const form = $('wthomeSearchForm');
      const input = $('wthomeSearchInput');
      if (!form || !input) return;

      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const query = normalizeText(input.value);
        if (!query) {
          input.focus();
          return;
        }
        window.location.href = `/search/?q=${encodeURIComponent(query)}`;
      });
    }

    function bindDestinationManager() {
      $('homeDestinations').addEventListener('click', (event) => {
        const addBtn = event.target.closest('[data-add-destination-country]');
        if (addBtn) return openDestinationManager({ mode: 'create', countrySlug: addBtn.dataset.addDestinationCountry });
        const manageBtn = event.target.closest('[data-manage-home-destinations]');
        if (manageBtn) return openHomeDestinationManager(manageBtn.dataset.manageHomeDestinations || '', manageBtn.dataset.manageHomeDestinationsName || '');
        const editBtn = event.target.closest('[data-edit-destination]');
        if (editBtn) {
          const item = state.destinations.find((destination) => String(destination.slug || '') === String(editBtn.dataset.editDestination || ''));
          if (item) openDestinationManager({ mode: 'edit', item });
        }
      });
      $('closeDestinationManagerBtn').addEventListener('click', closeDestinationManager);
      $('cancelDestinationManagerBtn').addEventListener('click', closeDestinationManager);
      $('destinationManagerBackdrop').addEventListener('click', closeDestinationManager);
      $('destinationManagerForm').addEventListener('submit', saveDestination);
      $('deleteDestinationBtn').addEventListener('click', deleteDestination);
      $('closeHomeDestinationManagerBtn').addEventListener('click', closeHomeDestinationManager);
      $('cancelHomeDestinationManagerBtn').addEventListener('click', closeHomeDestinationManager);
      $('homeDestinationManagerBackdrop').addEventListener('click', closeHomeDestinationManager);
      $('homeDestinationManagerForm').addEventListener('submit', submitHomeDestinationManager);
      $('homeDestinationChecklist').addEventListener('change', (event) => {
        const input = event.target.closest('[data-home-destination-slug]');
        if (input) enforceHomeDestinationLimit(input);
      });
      $('homeDestinationChecklist').addEventListener('click', (event) => {
        const moveBtn = event.target.closest('[data-home-destination-move]');
        if (!moveBtn) return;
        event.preventDefault();
        event.stopPropagation();
        moveHomeDestinationRow(moveBtn.dataset.slug || '', moveBtn.dataset.homeDestinationMove || 'up');
      });
      $('dmName').addEventListener('input', () => {
        if ($('destinationMode').value === 'create' && !$('dmSlug').value.trim()) $('dmSlug').value = slugify($('dmName').value);
        if (!$('dmCity').value.trim()) $('dmCity').value = $('dmName').value;
        if (!$('dmHeroTitle').value.trim()) $('dmHeroTitle').value = `${$('dmName').value} 여행 가이드`;
      });
    }

    bindHomeHeroSearch();
    bindDestinationManager();
    loadHome().catch(() => {
      $('homeDestinations').innerHTML = '<div class="empty-card">여행지를 불러오지 못했습니다.</div>';
    });
