/*
 * Tokyo hotel location survey logic.
 * This file is intentionally city-specific.
 */
const cityConfig = {
  cityName: "도쿄",
  destinationSlug: "tokyo",
  postContentType: "top5_series",
  areas: {
    shinjuku: {
      name: "신주쿠",
      regionSlug: "shinjuku",
      regionSlugAliases: ["신주쿠"],
      label: "첫 도쿄 여행자에게 가장 무난한 교통 중심 위치",
      summary: "대표 노선, 저녁 일정, 서쪽 도쿄 이동을 고려하면 신주쿠 주변이 가장 무난합니다.",
      leadTitle: "교통 선택지가 넓어 짧고 유연한 동선을 만들기 좋습니다.",
      leadText: "시부야, 하라주쿠, 도쿄역, 롯폰기 방향을 자주 오갈 계획이라면 이동 피로를 줄이기 좋습니다. 짧은 일정일수록 위치 장점이 크게 느껴집니다.",
      stayRange: ["신주쿠역, 니시신주쿠역, 신주쿠산초메역 도보 10분 이내", "밤 소음이 걱정되면 가부키초 바로 안쪽보다 큰길 또는 니시신주쿠 방향", "공항버스 이용을 고려한다면 버스터미널 접근성 확인"],
      avoidRange: ["밤 소음이 걱정된다면 번화가 바로 앞 저층 객실", "객실 크기를 중요하게 본다면 극중심가의 초소형 비즈니스 호텔", "부모님 동반이라면 출구와 엘리베이터 동선이 복잡한 위치"],
      bestFor: ["첫 도쿄 여행", "친구 여행", "맛집·쇼핑 중심 일정", "짧은 2박 3일 일정"],
      notFor: ["조용한 숙소가 최우선인 여행", "도쿄역·긴자 중심 일정", "디즈니·오다이바가 핵심인 가족 여행"],
      bookingTips: ["신주쿠역 도보 시간만 보지 말고 실제 이용할 노선 출구와의 거리를 확인하세요.", "가부키초 접근성과 소음은 반비례할 수 있으니 후기에서 밤 소음 언급을 확인하세요.", "공항 이동이 중요하면 리무진버스 또는 철도 환승 동선을 우선 비교하세요."],
      chips: ["첫 여행", "교통", "맛집", "저녁 동선", "쇼핑"],
      compareGood: "대표 노선과 맛집 동선이 넓고 여행 초보자도 이동 계획을 세우기 쉽습니다.",
      compareCaution: "역과 번화가가 큰 만큼 출구, 소음, 객실 크기, 가격을 꼼꼼히 봐야 합니다.",
      mismatchNote: "이번 답변에서 조용함, 가족형 여유, 디즈니 이동을 더 중요하게 봤다면 신주쿠는 1순위가 아닐 수 있습니다.",
      links: [{ title: "신주쿠 근처 호텔 추천 TOP5", url: "/post/tokyo-shinjuku-hotels" }, { title: "도쿄 첫 여행 호텔 추천 TOP5", url: "/post/tokyo-first-trip-hotels" }],
      hotels: [{ name: "JR 호텔 블라썸 신주쿠", tag: "신주쿠역 접근", location: "신주쿠 권역", reason: "신주쿠 중심 동선과 깔끔한 객실 후기를 중요하게 본다면 후보에 넣어볼 만한 숙소입니다.", meta: ["첫 여행", "교통", "쇼핑 동선"], url: "/post/jr-kyushu-hotel-blossom-shinjuku" }, { name: "호텔 그레이스리 신주쿠", tag: "신주쿠 중심", location: "신주쿠 동쪽", reason: "맛집, 쇼핑, 저녁 동선 중심으로 짧게 움직이고 싶은 여행자에게 어울리는 위치입니다.", meta: ["맛집", "저녁 동선", "친구 여행"], url: "/post/hotel-gracery-shinjuku" }, { name: "토큐 스테이 신주쿠", tag: "실속형 후보", location: "신주쿠산초메 권역", reason: "신주쿠 접근성과 실용적인 객실 편의성을 중요하게 본다면 잘 맞습니다.", meta: ["가성비", "역세권", "대표 동선"], url: "/post/tokyu-stay-shinjuku" }]
    },
    shibuya: {
      name: "시부야",
      regionSlug: "shibuya",
      regionSlugAliases: ["시부야", "시부야"],
      label: "쇼핑과 감성 동선에 강한 위치",
      summary: "쇼핑, 카페, 하라주쿠·오모테산도 동선을 중요하게 본다면 시부야가 잘 맞습니다.",
      leadTitle: "트렌디한 거리와 쇼핑 동선을 짧게 묶기 좋습니다.",
      leadText: "시부야, 하라주쿠, 오모테산도, 다이칸야마를 자주 오갈 계획이라면 이동 시간을 크게 줄일 수 있습니다.",
      stayRange: ["시부야역, 하라주쿠역, 오모테산도역 도보 10분 이내", "쇼핑 중심이면 시부야역 또는 하라주쿠 접근성이 좋은 위치", "밤 소음이 걱정되면 역 바로 앞보다 한 블록 떨어진 위치"],
      avoidRange: ["공항 이동이 최우선인데 시부야에만 고정하는 선택", "역 도보 12분 이상인데 언덕길이 있는 위치", "숙박비가 높은데 객실 크기 후기가 부족한 호텔"],
      bestFor: ["쇼핑 중심 여행", "커플 여행", "친구 여행", "카페·감성 일정"],
      notFor: ["도쿄역·긴자 중심 여행", "공항 이동이 가장 중요한 여행", "조용한 숙소가 최우선인 여행"],
      bookingTips: ["시부야역은 복잡하므로 호텔까지 실제 출구 동선을 확인하세요.", "하라주쿠·오모테산도 동선이 많으면 시부야보다 중간 지점도 비교하세요.", "가격이 비슷하다면 역 출구와 편의점 접근성이 좋은 호텔을 우선 비교하세요."],
      chips: ["쇼핑", "카페", "커플", "친구 여행"],
      compareGood: "쇼핑·카페 동선이 짧아 도쿄의 트렌디한 분위기를 즐기기 좋습니다.",
      compareCaution: "숙박비와 혼잡도가 높은 편이라 객실 크기와 출구 동선을 꼭 봐야 합니다.",
      mismatchNote: "이번 답변에서 공항 이동, 조용함, 가족형 여유를 더 많이 선택했다면 시부야는 보조 후보에 가깝습니다.",
      links: [{ title: "시부야 근처 호텔 추천 TOP5", url: "/post/tokyo-shibuya-hotels" }, { title: "도쿄 쇼핑하기 좋은 호텔 추천 TOP5", url: "/post/tokyo-shopping-hotels" }],
      hotels: [{ name: "시부야 스트림 엑셀 호텔 도큐", tag: "시부야 중심", location: "시부야 권역", reason: "시부야 쇼핑 동선과 하라주쿠 접근성을 같이 챙기고 싶다면 잘 맞는 후보입니다.", meta: ["쇼핑", "커플", "도보 동선"], url: "/post/shibuya-stream-excel-hotel-tokyu" }, { name: "시퀀스 미야시타 파크", tag: "감성형", location: "시부야·하라주쿠 사이", reason: "시부야와 하라주쿠 분위기를 하루에 묶고 싶은 일정에 보기 좋습니다.", meta: ["감성", "쇼핑", "친구 여행"], url: "/post/sequence-miyashita-park" }, { name: "트렁크 호텔 요요기 파크", tag: "부티크 후보", location: "요요기·시부야 권역", reason: "조금 더 여유 있는 분위기와 감성적인 숙소 분위기를 같이 따져볼 때 후보에 넣어볼 만합니다.", meta: ["부티크", "커플", "차분함"], url: "/post/trunk-hotel-yoyogi-park" }]
    },
    ginzaTokyoStation: {
      name: "긴자 & 도쿄역",
      regionSlug: "ginza-tokyo-station",
      regionSlugAliases: ["긴자 & 도쿄역", "긴자 & 도쿄역", "긴자 도쿄역"],
      label: "공항·근교와 깔끔한 도심에 강한 위치",
      summary: "도쿄역, 긴자, 마루노우치, 공항 이동을 함께 생각한다면 긴자 & 도쿄역 주변이 편합니다.",
      leadTitle: "정돈된 도심과 이동 안정성을 함께 잡기 좋습니다.",
      leadText: "도쿄역, 긴자 쇼핑, 공항 이동, 신칸센·근교 이동을 함께 고려하는 일정에 강합니다.",
      stayRange: ["도쿄역, 긴자역, 유라쿠초역 도보 10분 이내", "공항 이동이 많다면 도쿄역 또는 긴자 리무진버스 접근성 확인", "부모님 동반이면 지상 이동이 쉬운 큰길 주변"],
      avoidRange: ["늦은 밤 신주쿠·시부야에서 오래 머무는 일정", "캐주얼한 저녁 분위기를 기대하는 선택", "가격이 높은데 객실 크기가 너무 작은 호텔"],
      bestFor: ["부모님 동반", "공항 이동", "근교 당일치기", "깔끔한 도심 선호"],
      notFor: ["시부야 쇼핑 중심", "저녁 동선 중심 친구 여행", "숙소비 절약 최우선"],
      bookingTips: ["도쿄역은 넓으니 호텔이 어느 출구와 가까운지 확인하세요.", "나리타·하네다 중 어떤 공항을 쓰는지에 따라 이동 편의가 달라집니다.", "부모님 동반이면 지하 이동보다 지상 접근이 쉬운 호텔을 우선 비교하세요."],
      chips: ["공항 이동", "근교", "부모님", "깔끔한 도심"],
      compareGood: "공항·근교와 도심 쇼핑을 안정적으로 묶기 좋습니다.",
      compareCaution: "시부야·신주쿠 밤 일정이 많다면 매번 이동이 필요할 수 있습니다.",
      mismatchNote: "이번 답변에서 쇼핑 감성, 저녁 동선, 가성비를 강하게 선택했다면 긴자 & 도쿄역은 2순위 대안으로 보는 편이 좋습니다.",
      links: [{ title: "긴자 근처 호텔 추천 TOP5", url: "/post/tokyo-ginza-hotels" }, { title: "도쿄역 근처 호텔 추천 TOP5", url: "/post/tokyo-station-hotels" }],
      hotels: [{ name: "호텔 메트로폴리탄 도쿄 마루노우치", tag: "도쿄역 접근", location: "도쿄역 권역", reason: "근교 이동과 공항 이동을 중요하게 본다면 후보에 넣어볼 만한 위치입니다.", meta: ["근교 이동", "공항", "부모님"], url: "/post/hotel-metropolitan-tokyo-marunouchi" }, { name: "미쓰이 가든 호텔 긴자 프리미어", tag: "긴자 도심형", location: "긴자 권역", reason: "긴자 쇼핑과 깔끔한 도심 숙소를 모두 챙기고 싶은 일정에 어울립니다.", meta: ["긴자", "깔끔한 도심", "커플"], url: "/post/mitsui-garden-hotel-ginza-premier" }, { name: "다이와 로이넷 호텔 긴자 프리미어", tag: "실속형", location: "긴자·유라쿠초 권역", reason: "긴자 접근성과 가격 균형을 같이 따져보기 좋습니다.", meta: ["긴자", "실속", "역세권"], url: "/post/daiwa-roynet-hotel-ginza-premier" }]
    },
    uenoAsakusa: {
      name: "우에노 & 아사쿠사",
      regionSlug: "ueno-asakusa",
      regionSlugAliases: ["우에노 & 아사쿠사", "우에노 & 아사쿠사", "우에노 아사쿠사"],
      label: "가성비와 전통 관광을 같이 챙기기 좋은 위치",
      summary: "나리타공항 접근, 아사쿠사, 우에노공원, 스카이트리 동선을 중시한다면 우에노 & 아사쿠사가 잘 맞습니다.",
      leadTitle: "도쿄 동쪽 관광과 숙박비 균형을 잡기 좋습니다.",
      leadText: "전통 관광과 실속형 호텔을 함께 찾는 여행자에게 좋은 선택지입니다.",
      stayRange: ["우에노역, 아사쿠사역, 쿠라마에역 도보 10분 이내", "나리타 이동이 중요하면 우에노 접근성 확인", "조용함을 원하면 아사쿠사 중심보다 쿠라마에·이리야 방향"],
      avoidRange: ["매일 신주쿠·시부야를 오가는 일정", "도쿄역·긴자 쇼핑이 중심인 일정", "늦은 밤 서쪽 도쿄에 머무는 여행"],
      bestFor: ["가성비", "전통 관광", "나리타공항", "동쪽 도쿄"],
      notFor: ["시부야 중심 쇼핑 여행", "디즈니 중심 가족 여행", "긴자 고급 도심 분위기 선호"],
      bookingTips: ["우에노와 아사쿠사는 분위기가 다르므로 일정에 맞춰 고르세요.", "서쪽 도쿄 이동이 많다면 왕복 시간을 반드시 계산하세요.", "가격이 저렴할수록 역 출구와 객실 크기 후기를 확인하세요."],
      chips: ["가성비", "전통", "나리타", "동쪽 관광"],
      compareGood: "전통 관광과 실속형 숙소를 함께 잡기 좋습니다.",
      compareCaution: "신주쿠·시부야를 매일 오가면 이동 시간이 늘 수 있습니다.",
      mismatchNote: "이번 답변에서 쇼핑, 저녁 동선, 디즈니를 더 강하게 선택했다면 우에노 & 아사쿠사는 보조 후보에 가깝습니다.",
      links: [{ title: "우에노 근처 호텔 추천 TOP5", url: "/post/tokyo-ueno-hotels" }, { title: "아사쿠사 근처 호텔 추천 TOP5", url: "/post/tokyo-asakusa-hotels" }],
      hotels: [{ name: "노가 호텔 우에노 도쿄", tag: "우에노 감성형", location: "우에노 권역", reason: "우에노 접근성과 감성적인 숙소 분위기를 중요하게 본다면 잘 맞습니다.", meta: ["우에노", "가성비", "감성"], url: "/post/nohga-hotel-ueno-tokyo" }, { name: "리치몬드 호텔 프리미어 아사쿠사", tag: "아사쿠사 중심", location: "아사쿠사 권역", reason: "아사쿠사와 스카이트리 동선을 짧게 잡고 싶은 일정에 어울립니다.", meta: ["아사쿠사", "전통", "동쪽 관광"], url: "/post/richmond-hotel-premier-asakusa" }, { name: "더 게이트 호텔 카미나리몬 바이 훌릭", tag: "아사쿠사 전망형", location: "카미나리몬 권역", reason: "아사쿠사의 분위기와 도보 관광을 같이 따져보기 좋습니다.", meta: ["전망", "아사쿠사", "커플"], url: "/post/the-gate-hotel-kaminarimon-by-hulic" }]
    },
    odaibaBay: {
      name: "오다이바 & 도쿄베이",
      regionSlug: "odaiba-tokyo-bay",
      regionSlugAliases: ["오다이바 & 도쿄베이", "오다이바 & 도쿄베이", "오다이바 & 도쿄베이", "오다이바 도쿄베이"],
      label: "가족 여행과 도쿄베이권 일정에 좋은 위치",
      summary: "아이와 함께하거나 디즈니·오다이바 일정이 핵심이면 오다이바 & 도쿄베이가 잘 맞습니다.",
      leadTitle: "아이와 함께 무리 없이 쉬어가는 일정에 잘 맞습니다.",
      leadText: "대형 쇼핑몰, 바다 전망, 가족형 호텔을 활용하기 좋고 디즈니 전후 일정에도 후보에 넣어볼 만합니다.",
      stayRange: ["다이바역, 아리아케역, 도쿄베이 권역", "디즈니 일정이 있다면 마이하마·신우라야스 접근성 비교", "도심 관광도 많다면 유리카모메·린카이선 동선 확인"],
      avoidRange: ["신주쿠·시부야·아사쿠사를 매일 촘촘히 도는 일정", "늦은 밤 도심 식당가에서 오래 머무는 여행", "가성비가 최우선인 단기 여행"],
      bestFor: ["가족 여행", "디즈니", "오다이바", "여유 일정"],
      notFor: ["첫 도쿄 대표 명소를 촘촘히 도는 여행", "쇼핑·저녁 동선 중심 친구 여행", "숙소비 절약 최우선"],
      bookingTips: ["도심 관광 비중이 높다면 중심부까지 이동 시간을 반드시 계산하세요.", "디즈니 일정 전후라면 마이하마·신우라야스와 도쿄베이를 함께 비교하세요.", "가족 여행은 객실 크기와 조식, 셔틀 여부를 함께 확인하세요."],
      chips: ["가족", "디즈니", "도쿄베이", "여유"],
      compareGood: "가족형 일정과 휴식 분위기를 만들기 좋습니다.",
      compareCaution: "도쿄 중심 관광을 매일 하려면 이동 시간이 길어질 수 있습니다.",
      mismatchNote: "이번 답변에서 첫 여행 대표 동선, 쇼핑, 가성비를 더 많이 골랐다면 오다이바는 1순위가 아닐 수 있습니다.",
      links: [{ title: "오다이바 근처 호텔 추천 TOP5", url: "/post/tokyo-odaiba-hotels" }, { title: "도쿄 가족 여행 호텔 추천 TOP5", url: "/post/tokyo-family-hotels" }],
      hotels: [{ name: "그랜드 닛코 도쿄 다이바", tag: "오다이바 도쿄베이", location: "오다이바 권역", reason: "도쿄베이권과 여유로운 가족 일정을 중요하게 본다면 잘 맞습니다.", meta: ["가족", "도쿄베이", "여유"], url: "/post/grand-nikko-tokyo-daiba" }, { name: "힐튼 도쿄 오다이바", tag: "도쿄베이 전망", location: "오다이바 권역", reason: "도쿄베이 전망과 가족형 숙소를 모두 챙기고 싶은 일정에 어울립니다.", meta: ["전망", "가족", "휴식"], url: "/post/hilton-tokyo-odaiba" }, { name: "호텔 트러스티 도쿄 베이사이드", tag: "도쿄베이 실속", location: "아리아케 권역", reason: "도쿄베이권 접근성과 가격 균형을 같이 따져보기 좋습니다.", meta: ["실속", "도쿄베이", "가족"], url: "/post/hotel-trusty-tokyo-bayside" }]
    },
    akasakaRoppongi: {
      name: "아카사카 & 롯폰기",
      regionSlug: "akasaka-roppongi",
      regionSlugAliases: ["아카사카 & 롯폰기", "아카사카 & 롯폰기", "아카사카 롯폰기"],
      label: "차분한 도심과 미식 일정에 좋은 위치",
      summary: "번화가 한복판은 피하고 싶지만 도심 접근성을 포기하고 싶지 않다면 아카사카 & 롯폰기가 잘 맞습니다.",
      leadTitle: "도심 접근성은 유지하면서 조용히 쉬기 좋습니다.",
      leadText: "긴자, 롯폰기, 신주쿠, 시부야 방향으로 움직이기 좋고 숙소 주변 분위기는 비교적 정돈된 편입니다.",
      stayRange: ["아카사카역, 롯폰기역, 가미야초역 도보 10분 이내", "조용함을 원하면 큰길에서 한 블록 안쪽 위치", "야경·미식 일정이 많다면 롯폰기 접근성 확인"],
      avoidRange: ["도쿄가 처음인데 대표 관광지만 촘촘히 도는 일정", "숙소비를 최대한 아끼는 여행", "디즈니·오다이바가 핵심인 가족 여행"],
      bestFor: ["조용한 도심", "커플 여행", "미식", "출장 겸 여행"],
      notFor: ["가성비 최우선", "첫 여행 대표 동선", "가족형 도쿄베이 일정"],
      bookingTips: ["아카사카와 롯폰기는 분위기가 다르므로 저녁 동선을 기준으로 고르세요.", "언덕과 출구 동선을 확인하면 캐리어 이동이 쉬워집니다.", "가격대가 높은 편이므로 객실 크기와 조식 포함 여부를 함께 비교하세요."],
      chips: ["조용함", "커플", "미식", "도심"],
      compareGood: "번잡함을 줄이면서 도심 접근성을 유지하기 좋습니다.",
      compareCaution: "초행자의 대표 관광 동선만 보면 위치 장점이 덜 느껴질 수 있습니다.",
      mismatchNote: "이번 답변에서 가성비, 가족형 여유, 첫 여행 대표 동선을 많이 골랐다면 아카사카 & 롯폰기는 보조 후보입니다.",
      links: [{ title: "아카사카 근처 호텔 추천 TOP5", url: "/post/tokyo-akasaka-hotels" }, { title: "도쿄 조용한 숙소 추천 TOP5", url: "/post/tokyo-quiet-hotels" }],
      hotels: [{ name: "더 프린스 갤러리 도쿄 기오이초", tag: "아카사카·기오이초", location: "아카사카 권역", reason: "도심 접근성은 챙기면서 차분하게 쉬고 싶은 여행자에게 좋습니다.", meta: ["조용함", "고급", "커플"], url: "/post/the-prince-gallery-tokyo-kioicho" }, { name: "미쓰이 가든 호텔 롯폰기 도쿄 프리미어", tag: "롯폰기 도심", location: "롯폰기 권역", reason: "롯폰기 생활권에서 깔끔한 숙소와 저녁 동선을 같이 따져볼 때 좋습니다.", meta: ["롯폰기", "미식", "도심"], url: "/post/mitsui-garden-hotel-roppongi-tokyo-premier" }, { name: "호텔 더 셀레스틴 도쿄 시바", tag: "시바·도쿄타워", location: "시바 권역", reason: "비교적 차분한 분위기와 도쿄타워 주변 동선을 같이 따져볼 때 좋습니다.", meta: ["차분함", "도쿄타워", "커플"], url: "/post/hotel-the-celestine-tokyo-shiba" }]
    }
  },
  questions: [
    { title: "이번 도쿄 여행은 몇 번째인가요?", help: "처음인지, 재방문인지에 따라 숙소 위치 기준이 달라집니다.", options: [
          { title: "첫 여행", desc: "대표 동선과 이동 편의성이 가장 중요해요.", scores: { shinjuku: 6, ginzaTokyoStation: 5, uenoAsakusa: 3 } },
          { title: "재방문", desc: "조금 더 취향에 맞는 구역을 고르고 싶어요.", scores: { shibuya: 4, akasakaRoppongi: 4, uenoAsakusa: 3 } },
          { title: "익숙한 여행", desc: "번잡한 중심보다 분위기와 휴식이 중요해요.", scores: { akasakaRoppongi: 5, uenoAsakusa: 3, odaibaBay: 2 } }
        ]},
    { title: "이번 여행 동행자는 누구인가요?", help: "혼자, 커플, 친구, 가족 여부에 따라 좋은 위치가 달라집니다.", options: [
          { title: "혼자 여행", desc: "교통과 주변 편의성이 중요해요.", scores: { shinjuku: 4, uenoAsakusa: 3, ginzaTokyoStation: 3 } },
          { title: "커플 여행", desc: "맛집, 쇼핑, 분위기를 함께 챙기고 싶어요.", scores: { shibuya: 4, akasakaRoppongi: 4, ginzaTokyoStation: 2 } },
          { title: "친구 여행", desc: "저녁 이후에도 활기차고 식당이 많은 곳이 좋아요.", scores: { shinjuku: 5, shibuya: 4 } },
          { title: "가족·아이", desc: "무리 없는 이동과 안정적인 동선이 중요해요.", scores: { odaibaBay: 5, ginzaTokyoStation: 4, uenoAsakusa: 2 } },
          { title: "부모님 동반", desc: "교통이 편하고 너무 복잡하지 않은 곳이 좋아요.", scores: { ginzaTokyoStation: 5, akasakaRoppongi: 3, shinjuku: 2 } }
        ]},
    { title: "이번 여행에서 가장 중요한 일정은 무엇인가요?", help: "가장 많이 시간을 쓸 활동을 기준으로 추천합니다.", options: [
          { title: "관광·맛집", desc: "처음 가는 도쿄다운 기본 동선을 보고 싶어요.", scores: { shinjuku: 6, ginzaTokyoStation: 3, uenoAsakusa: 2 } },
          { title: "쇼핑·카페", desc: "시부야, 하라주쿠, 오모테산도 분위기가 중요해요.", scores: { shibuya: 7, shinjuku: 2 } },
          { title: "전통·가성비", desc: "아사쿠사, 우에노, 스카이트리 쪽도 많이 보고 싶어요.", scores: { uenoAsakusa: 7, ginzaTokyoStation: 2 } },
          { title: "공항·근교", desc: "도쿄역이나 신칸센, 공항 이동이 중요해요.", scores: { ginzaTokyoStation: 7, shinjuku: 2 } },
          { title: "가족 여유", desc: "오다이바, 디즈니, 대형 쇼핑몰 일정이 있어요.", scores: { odaibaBay: 7, ginzaTokyoStation: 2 } }
        ]},
    { title: "근교 여행 계획이 있나요?", help: "요코하마, 가마쿠라, 하코네, 닛코, 디즈니 일정이 있으면 숙소 기준이 달라집니다.", options: [
          { title: "근교 2일 이상", desc: "도쿄 밖으로 나가는 일정이 꽤 많아요.", scores: { ginzaTokyoStation: 6, shinjuku: 4, uenoAsakusa: 3 } },
          { title: "디즈니 일정", desc: "도쿄디즈니리조트 전후 이동이 중요해요.", scores: { odaibaBay: 7, ginzaTokyoStation: 4 } },
          { title: "근교 하루", desc: "시내 관광도 중요하지만 하루쯤은 다른 곳도 보고 싶어요.", scores: { shinjuku: 4, ginzaTokyoStation: 4, uenoAsakusa: 2 } },
          { title: "시내 중심", desc: "신주쿠, 시부야, 긴자, 아사쿠사 중심으로 움직일 예정이에요.", scores: { shinjuku: 4, shibuya: 3, uenoAsakusa: 3 } }
        ]},
    { title: "숙소 주변 분위기는 어떤 쪽이 좋나요?", help: "같은 도쿄여도 지역마다 저녁 이후 분위기와 체감 소음이 다릅니다.", options: [
          { title: "번화가", desc: "저녁 이후에도 주변에 식당과 볼거리가 많았으면 해요.", scores: { shinjuku: 6, shibuya: 3 } },
          { title: "트렌디한 거리", desc: "쇼핑, 카페, 젊은 감성이 중요해요.", scores: { shibuya: 7, shinjuku: 2 } },
          { title: "깔끔한 도심", desc: "백화점, 역세권, 정돈된 거리를 선호해요.", scores: { ginzaTokyoStation: 6, akasakaRoppongi: 2 } },
          { title: "차분한 숙소", desc: "번화가 접근성은 필요하지만 너무 복잡한 건 싫어요.", scores: { akasakaRoppongi: 6, uenoAsakusa: 3, ginzaTokyoStation: 2 } },
          { title: "가족형 분위기", desc: "아이와 함께 무리 없는 동선을 만들고 싶어요.", scores: { odaibaBay: 6, ginzaTokyoStation: 3 } }
        ]},
    { title: "공항 이동은 얼마나 중요한가요?", help: "하네다·나리타 이동을 중요하게 보면 역 접근성과 노선이 단순한 위치가 유리합니다.", options: [
          { title: "매우 중요", desc: "공항에서 숙소까지 길 찾기를 최대한 단순하게 하고 싶어요.", scores: { ginzaTokyoStation: 6, uenoAsakusa: 4, shinjuku: 3 } },
          { title: "보통", desc: "한 번 정도 갈아타는 것은 괜찮지만 너무 복잡한 건 싫어요.", scores: { ginzaTokyoStation: 3, shinjuku: 3, uenoAsakusa: 2, akasakaRoppongi: 2 } },
          { title: "중요 낮음", desc: "공항보다 현지 일정과 숙소 주변 분위기가 더 중요해요.", scores: { shibuya: 3, shinjuku: 2, akasakaRoppongi: 2, odaibaBay: 1 } }
        ]},
    { title: "디즈니·오다이바 일정이 있나요?", help: "디즈니, 오다이바, 도쿄베이 일정이 있으면 숙소 위치 기준이 달라집니다.", options: [
          { title: "디즈니 핵심", desc: "디즈니 이동을 편하게 잡고 싶어요.", scores: { odaibaBay: 7, ginzaTokyoStation: 4 } },
          { title: "오다이바 핵심", desc: "도쿄베이와 오다이바 주변을 여유롭게 보고 싶어요.", scores: { odaibaBay: 8, ginzaTokyoStation: 2 } },
          { title: "하루 방문", desc: "하루 정도만 들르고 시내 일정도 중요해요.", scores: { ginzaTokyoStation: 3, shinjuku: 2, akasakaRoppongi: 2, odaibaBay: 2 } },
          { title: "방문 없음", desc: "신주쿠, 시부야, 긴자, 우에노 같은 시내 동선이 더 중요해요.", scores: { shinjuku: 3, shibuya: 3, uenoAsakusa: 2, ginzaTokyoStation: 2 } }
        ]},
    { title: "숙소 예산은 어떤 편인가요?", help: "도쿄는 위치가 중심에 가까울수록 가격이 올라가거나 객실이 작아질 수 있습니다.", options: [
          { title: "예산 절약", desc: "중심가 바로 앞이 아니어도 괜찮아요.", scores: { uenoAsakusa: 6, shibuya: 2, shinjuku: 1 } },
          { title: "가격·위치 균형", desc: "너무 비싸지 않으면서 이동도 편했으면 해요.", scores: { shinjuku: 4, uenoAsakusa: 4, shibuya: 3 } },
          { title: "위치 우선", desc: "짧은 일정이라 이동 시간을 줄이고 싶어요.", scores: { shinjuku: 4, ginzaTokyoStation: 5, shibuya: 4, akasakaRoppongi: 3 } }
        ]}
  ]
};

    let currentQuestionIndex = 0;
    let answers = new Array(cityConfig.questions.length).fill(null);

    const locationPage = document.getElementById("locationPage");
    const surveyWrap = document.querySelector(".wt-survey-wrap");
    const surveyView = document.getElementById("surveyView");
    const resultView = document.getElementById("resultView");
    const startSurveyBtn = document.getElementById("startSurveyBtn");
    const backBtn = document.getElementById("backBtn");
    const questionCount = document.getElementById("questionCount");
    const progressText = document.getElementById("progressText");
    const progressBar = document.getElementById("progressBar");
    const progressFill = document.getElementById("progressFill");
    const questionTitle = document.getElementById("questionTitle");
    const questionHelp = document.getElementById("questionHelp");
    const optionsArea = document.getElementById("optionsArea");
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    const resetBtn = document.getElementById("resetBtn");

    function setText(id, text) {
      const element = document.getElementById(id);
      if (element) element.textContent = text;
    }

    function fillList(id, items) {
      const target = document.getElementById(id);
      target.innerHTML = "";
      items.forEach((item) => {
        const li = document.createElement("li");
        li.textContent = item;
        target.appendChild(li);
      });
    }

    function getAnsweredPercent() {
      const answeredCount = answers.filter((answer) => answer !== null).length;
      return Math.round((answeredCount / cityConfig.questions.length) * 100);
    }

    function getProgressMessage() {
      const total = cityConfig.questions.length;
      const step = currentQuestionIndex + 1;

      if (step === 1) return "가볍게 시작해볼까요?";
      if (step === total) return "마지막 질문이에요!";
      if (step >= total - 1) return "거의 다 왔어요";
      if (step >= Math.ceil(total * 0.65)) return "조금만 더 가면 추천 완료!";
      if (step >= Math.ceil(total * 0.4)) return "좋아요, 취향이 보이기 시작해요";
      return "동선을 하나씩 맞춰보는 중이에요";
    }

    function startSurvey() {
      locationPage?.classList.add("is-survey-started");
      locationPage?.classList.remove("is-result-mode");
      surveyWrap?.classList.add("is-survey-started");
      surveyWrap?.classList.remove("is-result-mode");
      resultView?.classList.remove("is-active");
      surveyView.style.display = "block";
      renderQuestion();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function goBack() {
      window.history.back();
    }

    function closeSurveyToStart() {
      currentQuestionIndex = 0;
      answers = new Array(cityConfig.questions.length).fill(null);
      resultView?.classList.remove("is-active");
      surveyWrap?.classList.remove("is-result-mode");
      surveyWrap?.classList.remove("is-survey-started");
      locationPage?.classList.remove("is-result-mode");
      locationPage?.classList.remove("is-survey-started");
      surveyView.style.display = "block";
      renderQuestion();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function renderQuestion() {
      const question = cityConfig.questions[currentQuestionIndex];
      const selectedIndex = answers[currentQuestionIndex];
      const percent = getAnsweredPercent();

      questionCount.textContent = `${currentQuestionIndex + 1} / ${cityConfig.questions.length}`;
      progressText.textContent = getProgressMessage();
      progressFill.style.width = `${percent}%`;
      progressBar.setAttribute("aria-valuenow", String(percent));

      questionTitle.textContent = question.title;
      questionHelp.textContent = question.help;
      optionsArea.innerHTML = "";

      question.options.forEach((option, optionIndex) => {
        const button = document.createElement("button");
        const title = document.createElement("span");

        button.type = "button";
        button.className = "wt-option";
        button.setAttribute("aria-pressed", selectedIndex === optionIndex ? "true" : "false");

        if (selectedIndex === optionIndex) {
          button.classList.add("is-selected");
        }

        title.className = "wt-option-title";
        title.textContent = option.title;

        button.appendChild(title);
        button.addEventListener("click", () => {
          answers[currentQuestionIndex] = optionIndex;
          renderQuestion();
        });

        optionsArea.appendChild(button);
      });

      prevBtn.disabled = false;
      prevBtn.textContent = currentQuestionIndex === 0 ? "닫기" : "이전";
      nextBtn.disabled = selectedIndex === null;
      nextBtn.textContent = currentQuestionIndex === cityConfig.questions.length - 1 ? "결과 보기" : "다음";
    }

    function goNext() {
      if (answers[currentQuestionIndex] === null) return;

      if (currentQuestionIndex < cityConfig.questions.length - 1) {
        currentQuestionIndex += 1;
        renderQuestion();
        questionTitle.focus?.();
      } else {
        showResult();
      }
    }

    function goPrev() {
      if (currentQuestionIndex === 0) {
        closeSurveyToStart();
        return;
      }
      currentQuestionIndex -= 1;
      renderQuestion();
    }


function getSelectedOption(questionIndex) {
  const answerIndex = answers[questionIndex];
  if (answerIndex === null || answerIndex === undefined) return null;
  return cityConfig.questions[questionIndex]?.options?.[answerIndex] || null;
}

function getSelectedOptionTitle(questionIndex) {
  return getSelectedOption(questionIndex)?.title || "";
}

function answerIs(questionIndex, title) {
  return getSelectedOptionTitle(questionIndex) === title;
}

function answerIn(questionIndex, titles) {
  return titles.includes(getSelectedOptionTitle(questionIndex));
}

function addAreaScore(scores, areaKey, amount) {
  if (Object.prototype.hasOwnProperty.call(scores, areaKey)) {
    scores[areaKey] += amount;
  }
}

function applyAccuracyAdjustments(scores) {
  const firstTrip = answerIs(0, "첫 여행");
  const repeatTrip = answerIn(0, ["재방문", "익숙한 여행"]);
  const couple = answerIs(1, "커플 여행");
  const friends = answerIs(1, "친구 여행");
  const family = answerIn(1, ["가족·아이", "부모님 동반"]);
  const parents = answerIs(1, "부모님 동반");
  const basicTour = answerIs(2, "관광·맛집");
  const shoppingCafe = answerIs(2, "쇼핑·카페") || answerIs(4, "트렌디한 거리");
  const traditionalBudget = answerIs(2, "전통·가성비");
  const airportNear = answerIs(2, "공항·근교");
  const familyLeisure = answerIs(2, "가족 여유") || answerIs(4, "가족형 분위기");
  const nearHeavy = answerIs(3, "근교 2일 이상");
  const nearOneDay = answerIs(3, "근교 하루");
  const disneyInNear = answerIs(3, "디즈니 일정");
  const cityOnly = answerIs(3, "시내 중심");
  const busyNight = answerIs(4, "번화가");
  const cleanCity = answerIs(4, "깔끔한 도심");
  const quietStay = answerIs(4, "차분한 숙소");
  const airportImportant = answerIs(5, "매우 중요");
  const airportNormal = answerIs(5, "보통");
  const disneyCore = answerIs(6, "디즈니 핵심");
  const odaibaCore = answerIs(6, "오다이바 핵심");
  const bayDay = answerIs(6, "하루 방문");
  const noBay = answerIs(6, "방문 없음");
  const budgetSave = answerIs(7, "예산 절약");
  const balanceBudget = answerIs(7, "가격·위치 균형");
  const locationFirst = answerIs(7, "위치 우선");

  if (firstTrip && basicTour && (cityOnly || busyNight || locationFirst) && noBay) {
    addAreaScore(scores, "shinjuku", 5);
  }
  if (friends && busyNight && !disneyCore && !odaibaCore) {
    addAreaScore(scores, "shinjuku", 4);
  }
  if (nearOneDay && basicTour) {
    addAreaScore(scores, "shinjuku", 2);
  }

  if (shoppingCafe && (couple || friends || repeatTrip)) {
    addAreaScore(scores, "shibuya", 5);
  }
  if (shoppingCafe && !airportImportant && noBay) {
    addAreaScore(scores, "shibuya", 3);
  }

  if ((airportNear || nearHeavy || airportImportant) && (parents || cleanCity || locationFirst)) {
    addAreaScore(scores, "ginzaTokyoStation", 5);
  }
  if (airportImportant && (nearHeavy || nearOneDay || airportNear)) {
    addAreaScore(scores, "ginzaTokyoStation", 4);
  }
  if (parents && airportNormal) {
    addAreaScore(scores, "ginzaTokyoStation", 3);
  }

  if (traditionalBudget && budgetSave) {
    addAreaScore(scores, "uenoAsakusa", 6);
  }
  if (traditionalBudget && airportImportant) {
    addAreaScore(scores, "uenoAsakusa", 3);
  }
  if (budgetSave && !shoppingCafe && !disneyCore && !odaibaCore) {
    addAreaScore(scores, "uenoAsakusa", 3);
  }

  if ((disneyCore || odaibaCore || disneyInNear) && (family || familyLeisure)) {
    addAreaScore(scores, "odaibaBay", 7);
  }
  if (odaibaCore) {
    addAreaScore(scores, "odaibaBay", 5);
  }
  if (disneyCore && !cityOnly) {
    addAreaScore(scores, "odaibaBay", 4);
    addAreaScore(scores, "ginzaTokyoStation", 2);
  }
  if (bayDay && family) {
    addAreaScore(scores, "ginzaTokyoStation", 2);
    addAreaScore(scores, "odaibaBay", 2);
  }

  if (quietStay && (repeatTrip || couple) && !budgetSave) {
    addAreaScore(scores, "akasakaRoppongi", 5);
  }
  if (cleanCity && couple && !airportImportant) {
    addAreaScore(scores, "akasakaRoppongi", 3);
  }
  if (repeatTrip && locationFirst && noBay) {
    addAreaScore(scores, "akasakaRoppongi", 2);
  }


  // v13 accuracy reinforcement: reduce Tokyo Station over-selection and give Akasaka/Roppongi a clearer quiet central use case.
  const airportLow = answerIs(5, "중요 낮음");
  if (quietStay && (couple || repeatTrip || parents) && noBay && !budgetSave) {
    addAreaScore(scores, "akasakaRoppongi", 8);
  }
  if (cleanCity && (couple || parents || repeatTrip) && !airportImportant && noBay) {
    addAreaScore(scores, "akasakaRoppongi", 6);
  }
  if (repeatTrip && locationFirst && noBay && !airportImportant && !traditionalBudget) {
    addAreaScore(scores, "akasakaRoppongi", 5);
  }
  if (airportNormal && quietStay && !disneyCore && !odaibaCore) {
    addAreaScore(scores, "akasakaRoppongi", 4);
  }
  if (!airportImportant && !nearHeavy && !airportNear && !parents && !disneyCore) {
    addAreaScore(scores, "ginzaTokyoStation", -3);
  }
  if (airportLow && (shoppingCafe || quietStay || busyNight)) {
    addAreaScore(scores, "ginzaTokyoStation", -3);
  }
  if (traditionalBudget && (budgetSave || balanceBudget) && noBay) {
    addAreaScore(scores, "uenoAsakusa", 5);
  }
  if (firstTrip && basicTour && cityOnly && noBay) {
    addAreaScore(scores, "shinjuku", 3);
  }
  if (shoppingCafe && noBay && !airportImportant) {
    addAreaScore(scores, "shibuya", 3);
  }


  // v13 balance pass: Akasaka/Roppongi should win for quiet central stays, not just receive secondary points.
  if (quietStay && noBay && !budgetSave && !disneyCore && !odaibaCore) {
    addAreaScore(scores, "akasakaRoppongi", 10);
  }
  if (cleanCity && repeatTrip && noBay && !airportImportant) {
    addAreaScore(scores, "akasakaRoppongi", 8);
  }
  if (airportLow && (quietStay || cleanCity) && noBay) {
    addAreaScore(scores, "akasakaRoppongi", 6);
  }
  if (!airportImportant && !nearHeavy && !airportNear && !parents && !disneyCore && !odaibaCore) {
    addAreaScore(scores, "ginzaTokyoStation", -4);
  }
  if (airportLow && noBay) {
    addAreaScore(scores, "ginzaTokyoStation", -2);
  }


  // v13 final balance: reserve Ginza/Tokyo Station for clear airport/rail/family reasons.
  if (quietStay && noBay && !airportImportant && !nearHeavy) {
    addAreaScore(scores, "akasakaRoppongi", 4);
  }
  if (cleanCity && !airportImportant && !nearHeavy && noBay) {
    addAreaScore(scores, "akasakaRoppongi", 3);
  }
  if (!(airportNear || nearHeavy || airportImportant || parents || disneyCore || odaibaCore) && noBay) {
    addAreaScore(scores, "ginzaTokyoStation", -5);
  }
  if (traditionalBudget && noBay && !airportImportant) {
    addAreaScore(scores, "uenoAsakusa", 3);
  }
}

    

function getTieBreakPriority(areaKey) {
  const order = Object.keys(cityConfig.areas);
  const reverseIndex = order.length - order.indexOf(areaKey);
  return reverseIndex;
}

    function calculateScores() {
      const scores = {};
      Object.keys(cityConfig.areas).forEach((areaKey) => {
        scores[areaKey] = 0;
      });

      answers.forEach((answerIndex, questionIndex) => {
        if (answerIndex === null) return;
        const selectedOption = cityConfig.questions[questionIndex].options[answerIndex];
        Object.entries(selectedOption.scores).forEach(([areaKey, score]) => {
          scores[areaKey] += score;
        });
      });

      applyAccuracyAdjustments(scores);

      return Object.entries(scores)
        .map(([key, score]) => ({ key, score, ...cityConfig.areas[key] }))
        .sort((a, b) => (b.score - a.score) || (getTieBreakPriority(b.key) - getTieBreakPriority(a.key)));
    }



    function renderHotelCards(area) {
      const section = document.getElementById("hotelRecommendSection");
      const hotelCardList = document.getElementById("hotelCardList");
      const hotels = Array.isArray(area.hotels) ? area.hotels.slice(0, 5) : [];

      if (!section || !hotelCardList) return;

      if (hotels.length === 0) {
        section.style.display = "none";
        hotelCardList.innerHTML = "";
        return;
      }

      section.style.display = "block";
      setText("hotelSectionTitle", `${area.name}에서 먼저 비교해볼 호텔 5곳`);
      setText("hotelSectionDesc", "추천된 위치를 기준으로 먼저 비교해볼 만한 호텔 후보입니다. 실제 예약 전에는 가격, 객실 타입, 취소 조건, 최근 후기를 함께 확인하세요.");
      hotelCardList.innerHTML = "";

      hotels.forEach((hotel, index) => {
        const article = document.createElement("article");
        const top = document.createElement("div");
        const rank = document.createElement("span");
        const tag = document.createElement("span");
        const name = document.createElement("h4");
        const location = document.createElement("p");
        const reason = document.createElement("p");
        const meta = document.createElement("div");
        const footer = document.createElement("div");
        const linkWrap = document.createElement("div");
        const link = document.createElement("a");

        article.className = "wt-hotel-card";
        top.className = "wt-hotel-card-top";
        rank.className = "wt-hotel-rank";
        tag.className = "wt-hotel-tag";
        name.className = "wt-hotel-name";
        location.className = "wt-hotel-location";
        reason.className = "wt-hotel-reason";
        meta.className = "wt-hotel-meta";
        footer.className = "wt-hotel-card-footer";
        linkWrap.className = "wt-hotel-link-wrap";
        link.className = "wt-hotel-link";

        rank.textContent = `${index + 1}`;
        tag.textContent = hotel.tag || "추천 후보";
        name.textContent = hotel.name;
        location.textContent = hotel.location;
        reason.textContent = hotel.reason;
        link.href = hotel.url || "#";
        link.textContent = "잔여 객실 확인";
        link.setAttribute("aria-label", `${hotel.name} 잔여 객실 확인`);

        (hotel.meta || []).forEach((item) => {
          const chip = document.createElement("span");
          chip.textContent = item;
          meta.appendChild(chip);
        });

        top.appendChild(rank);
        top.appendChild(tag);
        linkWrap.appendChild(link);
        footer.appendChild(meta);
        footer.appendChild(linkWrap);
        article.appendChild(top);
        article.appendChild(name);
        article.appendChild(location);
        article.appendChild(reason);
        article.appendChild(footer);
        hotelCardList.appendChild(article);
      });
    }

    function getRelatedPostRegionSlugs(area) {
      return [...new Set([
        area.regionSlug,
        ...(Array.isArray(area.regionSlugAliases) ? area.regionSlugAliases : [])
      ].map((item) => String(item || "").trim()).filter(Boolean))];
    }

    async function fetchRelatedPostsByRegion(area) {
      const regionSlugs = getRelatedPostRegionSlugs(area);

      for (const regionSlug of regionSlugs) {
        const params = new URLSearchParams({
          destination: cityConfig.destinationSlug,
          type: cityConfig.postContentType,
          region: regionSlug,
          limit: "5"
        });

        try {
          const response = await fetch(`/api/destination-posts?${params.toString()}`, {
            headers: { accept: "application/json" }
          });
          if (!response.ok) continue;
          const data = await response.json();
          const items = Array.isArray(data.items) ? data.items : [];
          if (items.length) return items.slice(0, 5);
        } catch (_) {
          return [];
        }
      }

      return [];
    }

    async function renderRelatedPosts(area) {
      const section = document.getElementById("relatedPostSection");
      const list = document.getElementById("relatedPostList");

      if (!section || !list) return;

      section.style.display = "none";
      list.innerHTML = "";
      setText("relatedPostTitle", `${area.name} 여행 스타일별 호텔 추천 글`);
      setText("relatedPostDesc", "현재 추천된 지역에 연결된 여행 스타일별 호텔 추천 글만 보여줍니다.");

      const posts = await fetchRelatedPostsByRegion(area);

      if (!posts.length) {
        section.style.display = "none";
        list.innerHTML = "";
        return;
      }

      section.style.display = "block";
      list.innerHTML = "";

      posts.forEach((post) => {
        const title = String(post.title || "여행 스타일별 호텔 추천 글").trim();
        const slug = String(post.slug || "").trim();
        const item = document.createElement("li");
        const link = document.createElement("a");

        link.href = slug ? `/post/${encodeURIComponent(slug)}` : "#";
        link.textContent = title;
        link.setAttribute("aria-label", `${title} 보기`);

        item.appendChild(link);
        list.appendChild(item);
      });
    }

    
function getLastHangulChar(text) {
  const chars = Array.from(String(text || "")).reverse();
  return chars.find((char) => /[가-힣]/.test(char)) || "";
}

function hasKoreanBatchim(text) {
  const char = getLastHangulChar(text);
  if (!char) return false;
  const code = char.charCodeAt(0) - 0xac00;
  return code >= 0 && code <= 11171 && code % 28 !== 0;
}

function withJosa(text, pair) {
  const [withBatchim, withoutBatchim] = String(pair).split("/");
  return `${text}${hasKoreanBatchim(text) ? withBatchim : withoutBatchim}`;
}

function getResultFocusSentence(area) {
  if (!area) return "";
  const chips = Array.isArray(area.chips) ? area.chips.slice(0, 3) : [];
  if (!chips.length) return "";
  return `${withJosa(area.name, "은/는")} ${chips.join(" · ")} 흐름을 우선하는 여행자에게 잘 맞습니다.`;
}

function getSelectedAnswerSignals() {
      return answers
        .map((_, questionIndex) => getSelectedOptionTitle(questionIndex))
        .filter(Boolean)
        .filter((item, index, arr) => arr.indexOf(item) === index)
        .slice(0, 5);
    }

        function getSignalSentence() {
      return "";
    }

        function getScoreFitSentence(rankedAreas) {
      const top = rankedAreas?.[0];
      const second = rankedAreas?.[1];
      if (!top || !second) return "";

      const gap = top.score - second.score;
      if (gap <= 2) {
        return `${withJosa(top.name, "은/는")} 가장 잘 맞는 후보지만 ${second.name}도 거의 비슷합니다. 두 지역의 호텔 가격, 객실 크기, 실제 이동 시간을 같이 비교하면 선택이 더 쉬워집니다.`;
      }
      if (gap <= 5) {
        return `${withJosa(top.name, "이/가")} 조금 더 유리합니다. 다만 일정의 중심이 ${second.name} 쪽에 더 가깝다면 ${second.name}도 충분히 좋은 대안입니다.`;
      }
      return `${withJosa(top.name, "은/는")} 이번 일정에서 우선순위가 분명한 지역입니다. 먼저 이 권역 안에서 호텔을 추린 뒤 가격, 객실 크기, 최근 후기를 비교해보세요.`;
    }

        function getAlternativeSentence(area, rankedAreas) {
      const second = rankedAreas?.[1];
      if (!second) return "";

      const gap = rankedAreas[0].score - second.score;
      if (gap <= 2) {
        return `${second.name}도 거의 같은 후보입니다. ${second.compareGood || second.summary}`;
      }
      return `대안으로는 ${withJosa(second.name, "이/가")} 있습니다. ${second.compareGood || second.summary}`;
    }

    function normalizeResultReasons(area, reasons) {
      const next = Array.isArray(reasons) ? [...reasons] : [];
      if (next.length < 4) {
        const cautionText = [area.compareCaution, area.mismatchNote]
          .filter(Boolean)
          .join(" ") || "추천 지역도 일정 성격에 따라 장단점이 달라집니다. 호텔 예약 전 이동 시간, 주변 분위기, 최근 후기를 함께 확인하세요.";
        next.push({ title: "주의할 점도 함께 보세요", text: cautionText });
      }
      return next.slice(0, 4);
    }

    function getPersuasiveContent(area, rankedAreas) {
      const contents = {
        shinjuku: {
          intro: "신주쿠는 도쿄가 처음이거나 일정이 넓게 퍼져 있을 때 가장 안전한 기준점이 됩니다. 교통 선택지가 많고 저녁 이후 식사·쇼핑 동선도 짧게 잡기 쉽습니다.",
          reasons: [
            { title: "처음 가도 동선을 잡기 쉽습니다", text: "신주쿠역을 기준으로 시부야, 하라주쿠, 도쿄역, 롯폰기 방향을 모두 연결하기 좋아 일정이 한쪽으로 치우치지 않습니다." },
            { title: "저녁 시간이 편해집니다", text: "식당, 쇼핑, 편의시설이 늦게까지 이어져 하루 일정을 마친 뒤에도 숙소 주변에서 시간을 쓰기 좋습니다." },
            { title: "짧은 일정의 실패 확률이 낮습니다", text: "2박 3일처럼 시간이 부족한 여행에서는 이동 선택지가 많은 중심지가 더 안정적입니다." }
          ],
          conclusionTitle: "신주쿠가 맞는 경우: 도쿄 대표 동선을 넓게 보고 싶을 때",
          conclusionText: "가부키초 바로 안쪽은 밤 소음과 혼잡도가 있을 수 있습니다. 신주쿠역·신주쿠산초메·니시신주쿠 중 실제 이용할 노선과 출구를 기준으로 비교하세요."
        },
        shibuya: {
          intro: "시부야는 쇼핑, 카페, 하라주쿠·오모테산도 동선을 중요하게 보는 여행자에게 가장 잘 맞습니다. 도쿄의 트렌디한 분위기를 체감하기 좋은 위치입니다.",
          reasons: [
            { title: "쇼핑·카페 동선이 짧습니다", text: "시부야, 하라주쿠, 오모테산도, 다이칸야마를 자주 오간다면 이동 시간을 크게 줄일 수 있습니다." },
            { title: "커플·친구 여행에 강합니다", text: "낮에는 쇼핑과 카페, 저녁에는 식당과 산책 동선을 자연스럽게 이어가기 좋습니다." },
            { title: "도쿄 분위기를 바로 느끼기 좋습니다", text: "도심의 에너지와 감성적인 거리 분위기를 숙소 주변에서 바로 활용할 수 있습니다." }
          ],
          conclusionTitle: "시부야가 맞는 경우: 쇼핑과 감성 동선이 여행의 중심일 때",
          conclusionText: "숙박비와 혼잡도는 높은 편입니다. 역 바로 앞보다 한 블록 떨어진 위치, 하라주쿠·오모테산도 접근성, 언덕길 여부를 함께 확인하세요."
        },
        ginzaTokyoStation: {
          intro: "긴자 & 도쿄역은 공항 이동, 신칸센·근교 이동, 정돈된 도심 분위기를 함께 원하는 여행자에게 잘 맞습니다. 부모님 동반이나 일정 변경이 많은 여행에서도 안정적입니다.",
          reasons: [
            { title: "공항·근교 이동이 단순합니다", text: "도쿄역, 긴자, 유라쿠초를 기준으로 나리타·하네다 이동과 신칸센·근교 일정을 계획하기 쉽습니다." },
            { title: "동네 분위기가 정돈되어 있습니다", text: "복잡한 번화가보다 큰길과 백화점·식당가 중심의 분위기라 부모님 동반이나 깔끔한 도심 숙소를 원하는 여행에 잘 맞습니다." },
            { title: "체력 소모를 줄이기 좋습니다", text: "이른 귀국일, 늦은 도착일, 짐이 많은 일정에서는 이동 안정성이 숙소 만족도에 크게 영향을 줍니다." }
          ],
          conclusionTitle: "긴자 & 도쿄역이 맞는 경우: 이동 안정성과 깔끔한 도심을 우선할 때",
          conclusionText: "시부야·신주쿠 밤 일정이 많다면 매번 이동이 필요합니다. 도쿄역은 넓기 때문에 호텔이 어느 출구와 가까운지까지 확인하세요."
        },
        uenoAsakusa: {
          intro: "우에노 & 아사쿠사는 숙박비 균형, 전통 관광, 나리타공항 접근성을 함께 보는 여행자에게 설득력 있는 위치입니다.",
          reasons: [
            { title: "동쪽 도쿄 관광이 편합니다", text: "아사쿠사, 우에노공원, 스카이트리, 쿠라마에 동선을 묶기 좋아 전통적인 분위기의 일정을 만들기 쉽습니다." },
            { title: "가성비 호텔을 찾기 좋습니다", text: "서쪽 중심지보다 숙소 선택 폭이 넓고, 예산을 아끼면서도 지하철·JR 접근성을 확보하기 좋습니다." },
            { title: "나리타공항 이용 시 유리합니다", text: "우에노는 나리타 이동 동선이 단순해 도착일과 귀국일 부담을 줄이는 데 도움이 됩니다." }
          ],
          conclusionTitle: "우에노 & 아사쿠사가 맞는 경우: 전통 관광과 예산 균형을 함께 볼 때",
          conclusionText: "매일 신주쿠·시부야를 오갈 계획이라면 이동 시간이 길어질 수 있습니다. 일정이 동쪽 중심인지 먼저 확인한 뒤 호텔을 비교하세요."
        },
        odaibaBay: {
          intro: "오다이바 & 도쿄베이는 가족 여행, 디즈니 전후 일정, 바다 전망과 여유로운 숙박을 중요하게 볼 때 잘 맞습니다.",
          reasons: [
            { title: "아이와 움직이기 편합니다", text: "대형 쇼핑몰과 가족형 호텔이 많아 이동보다 체류의 편안함을 중요하게 보는 일정에 적합합니다." },
            { title: "디즈니·도쿄베이 일정과 연결됩니다", text: "마이하마·신우라야스와 함께 비교하면 디즈니 전후 일정, 오다이바 산책, 베이권 휴식 동선을 만들기 좋습니다." },
            { title: "도심과 다른 휴식감이 있습니다", text: "신주쿠·시부야처럼 빽빽한 도심보다 여유 있는 분위기를 원할 때 만족도가 높습니다." }
          ],
          conclusionTitle: "오다이바 & 도쿄베이가 맞는 경우: 가족형 여유 일정이 핵심일 때",
          conclusionText: "도쿄 대표 관광지를 매일 촘촘히 돌 계획이라면 이동 시간이 길어질 수 있습니다. 도심 관광 비중과 디즈니·베이권 비중을 먼저 나눠보세요."
        },
        akasakaRoppongi: {
          intro: "아카사카 & 롯폰기는 번화가 한복판은 피하면서도 도심 접근성, 미식, 깔끔한 숙소 분위기를 놓치고 싶지 않은 여행자에게 좋습니다.",
          reasons: [
            { title: "도심 접근성과 조용함의 균형이 좋습니다", text: "긴자, 롯폰기, 신주쿠, 시부야 방향으로 움직이기 좋고 숙소 주변은 비교적 정돈된 편입니다." },
            { title: "커플·재방문 여행에 잘 맞습니다", text: "대표 관광지보다 식사, 야경, 카페, 미술관 등 취향형 일정을 넣기 좋습니다." },
            { title: "숙소 만족도를 챙기기 좋습니다", text: "혼잡한 역 앞보다 차분한 도심형 호텔을 비교하기 좋아 쉬는 시간의 만족도를 높일 수 있습니다." }
          ],
          conclusionTitle: "아카사카 & 롯폰기가 맞는 경우: 조용한 도심과 미식 동선을 원할 때",
          conclusionText: "첫 도쿄 여행에서 대표 명소를 빠르게 도는 일정이라면 신주쿠나 긴자 & 도쿄역이 더 쉬울 수 있습니다. 언덕길과 역 출구 동선도 함께 확인하세요."
        }
      };

      const content = contents[area.key] || {
        intro: area.summary,
        reasons: [
          { title: "여행 목적과 맞는 위치입니다", text: area.compareGood || area.summary },
          { title: "이동 기준을 단순하게 만들 수 있습니다", text: area.leadText || "숙소 위치를 먼저 정하면 하루 동선이 훨씬 단순해집니다." },
          { title: "호텔 비교 기준이 명확해집니다", text: "지역을 먼저 정하면 가격, 객실, 후기, 역 접근성을 더 현실적으로 비교할 수 있습니다." }
        ],
        conclusionTitle: `이번 도쿄 여행은 ${area.name}을 중심으로 비교해보세요.`,
        conclusionText: "추천 지역 안에서도 역 출구, 저녁 이후 분위기, 객실 크기, 공항 이동 후기를 함께 확인하면 실패 확률을 줄일 수 있습니다."
      };

          const fitText = getScoreFitSentence(rankedAreas);
      const alternativeText = getAlternativeSentence(area, rankedAreas);

      return {
        ...content,
        reasons: normalizeResultReasons(area, content.reasons),
        intro: [content.intro, fitText].filter(Boolean).join(" "),
        conclusionText: [content.conclusionText, alternativeText].filter(Boolean).join(" ")
      };
    }

    function getMatchedAnswers(areaKey) {
      return answers
        .map((answerIndex, questionIndex) => {
          if (answerIndex === null) return null;
          const question = cityConfig.questions[questionIndex];
          const option = question.options[answerIndex];
          const score = option.scores?.[areaKey] || 0;
          if (score <= 0) return null;
          return { title: option.title, score };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score)
        .slice(0, 5);
    }

    function renderPersuasiveResult(topArea, rankedAreas) {
      const content = getPersuasiveContent(topArea, rankedAreas);
      const reasonCardList = document.getElementById("reasonCardList");

      setText("resultWhyText", content.intro);
      setText("decisionConclusionTitle", content.conclusionTitle);
      setText("decisionConclusionText", content.conclusionText);


      if (reasonCardList) {
        reasonCardList.innerHTML = "";
        content.reasons.forEach((reason, index) => {
          const article = document.createElement("article");
          const number = document.createElement("span");
          const title = document.createElement("h4");
          const text = document.createElement("p");

          article.className = "wt-reason-card";
          number.className = "wt-reason-number";
          number.textContent = `${index + 1}`;
          title.textContent = reason.title;
          text.textContent = reason.text;

          article.appendChild(number);
          article.appendChild(title);
          article.appendChild(text);
          reasonCardList.appendChild(article);
        });
      }
    }

    function showResult() {
      const rankedAreas = calculateScores();
      const topArea = rankedAreas[0];

      locationPage?.classList.add("is-survey-started");
      locationPage?.classList.add("is-result-mode");
      surveyView.style.display = "none";
      resultView.classList.add("is-active");
      surveyWrap.classList.add("is-survey-started");
      surveyWrap.classList.add("is-result-mode");

      setText("resultTitle", topArea.name);
      setText("resultSummary", topArea.summary);
      setText("resultLeadTitle", topArea.leadTitle);
      setText("resultLeadText", topArea.leadText);

      renderPersuasiveResult(topArea, rankedAreas);
      renderHotelCards(topArea);
      renderRelatedPosts(topArea);


      progressText.textContent = "추천 결과가 나왔어요!";
      progressFill.style.width = "100%";
      progressBar.setAttribute("aria-valuenow", "100");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function resetSurvey() {
      currentQuestionIndex = 0;
      answers = new Array(cityConfig.questions.length).fill(null);
      resultView.classList.remove("is-active");
      surveyWrap.classList.remove("is-result-mode");
      surveyWrap.classList.remove("is-survey-started");
      locationPage?.classList.remove("is-result-mode");
      locationPage?.classList.remove("is-survey-started");
      surveyView.style.display = "block";
      renderQuestion();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    startSurveyBtn?.addEventListener("click", startSurvey);
    backBtn?.addEventListener("click", goBack);
    nextBtn.addEventListener("click", goNext);
    prevBtn.addEventListener("click", goPrev);
    resetBtn.addEventListener("click", resetSurvey);

    renderQuestion();
  