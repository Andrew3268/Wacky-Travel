

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function unwrapCfImageUrl(src = "") {
  const value = String(src || "").trim();
  if (!value || !value.includes("/cdn-cgi/image/")) return value;

  const marker = "/cdn-cgi/image/";
  const markerIndex = value.indexOf(marker);
  if (markerIndex < 0) return value;

  const afterMarker = value.slice(markerIndex + marker.length);
  const optionEnd = afterMarker.indexOf("/");
  if (optionEnd < 0) return value;

  const embedded = afterMarker.slice(optionEnd + 1);
  if (!embedded) return value;
  return embedded;
}

function absolutizeImageUrl(src = "") {
  const unwrapped = unwrapCfImageUrl(src);
  const value = String(unwrapped || "").trim();
  if (!value) return "";
  if (/^(data|blob):/i.test(value)) return value;
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith("//")) return `https:${value}`;
  try {
    return new URL(value, window.location.origin).toString();
  } catch (_) {
    return value;
  }
}

function getImageHostname(url = "") {
  try { return new URL(url).hostname.toLowerCase(); } catch (_) { return ""; }
}

function getImageBaseDomain(hostname = "") {
  const parts = String(hostname || "").toLowerCase().split(".").filter(Boolean);
  if (parts.length <= 2) return parts.join(".");
  return parts.slice(-2).join(".");
}

function isLocalImageOrigin(origin = "") {
  const host = getImageHostname(origin);
  return host === "localhost" || host === "127.0.0.1" || host.endsWith(".localhost");
}


function isImageProxyUrl(url = "") {
  const value = String(url || "").trim();
  if (!value) return false;
  try {
    const parsed = new URL(value, window.location.origin);
    return parsed.pathname.startsWith("/img/");
  } catch (_) {
    return value.startsWith("/img/") || value.includes("/img/");
  }
}

function isR2DevImageUrl(url = "") {
  const raw = String(url || "").toLowerCase();
  const normalized = unwrapCfImageUrl(raw).toLowerCase();
  const host = getImageHostname(normalized);
  return raw.includes(".r2.dev") || normalized.includes(".r2.dev") || host.endsWith(".r2.dev") || host === "r2.dev";
}

function encodeImageBase64Url(value = "") {
  const bytes = new TextEncoder().encode(String(value || ""));
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function buildImageProxyUrl(src = "") {
  const absolute = absolutizeImageUrl(src);
  if (!absolute || /^(data|blob):/i.test(absolute)) return absolute;
  if (!isR2DevImageUrl(absolute)) return absolute;
  return `${window.location.origin}/img/${encodeImageBase64Url(absolute)}`;
}

function canUseCloudflareImageTransform(absolute = "") {
  const normalized = unwrapCfImageUrl(absolute);

  // /img/*는 R2 이미지 캐시용 Pages Function 프록시 경로입니다.
  // 이 경로를 /cdn-cgi/image 원본으로 다시 넣으면 배포 환경에서 404가 발생할 수 있어
  // R2 이미지는 프록시 캐시만 사용하고 Cloudflare 이미지 변환은 적용하지 않습니다.
  if (isImageProxyUrl(normalized)) return false;

  const srcHost = getImageHostname(normalized);
  const originHost = getImageHostname(window.location.origin);
  if (!srcHost || !originHost) return false;
  if (isLocalImageOrigin(window.location.origin)) return false;
  if (srcHost === originHost) return true;
  return getImageBaseDomain(srcHost) === getImageBaseDomain(originHost);
}

function buildCfImageUrl(src = "", options = {}) {
  const raw = String(src || "").trim();
  const absolute = absolutizeImageUrl(raw);
  if (!absolute) return "";
  if (/^(data|blob):/i.test(absolute)) return absolute;
  const deliveryUrl = buildImageProxyUrl(absolute);
  if (!deliveryUrl) return "";
  if (!canUseCloudflareImageTransform(deliveryUrl)) return deliveryUrl;
  const config = { format: "auto", quality: 82, ...options };
  const params = Object.entries(config)
    .filter(([, value]) => value !== null && value !== undefined && value !== "")
    .map(([key, value]) => `${key}=${value}`)
    .join(",");
  return `/cdn-cgi/image/${params}/${deliveryUrl}`;
}

function buildImageAttrs(src = "", config = {}) {
  const widths = Array.isArray(config.widths) && config.widths.length ? config.widths : [320, 640, 960, 1200];
  const normalized = [...new Set(widths.map((value) => Math.max(1, parseInt(value, 10) || 0)).filter(Boolean))].sort((a, b) => a - b);
  const baseOptions = { fit: config.fit || "scale-down", format: config.format || "auto", quality: config.quality || 82 };
  const absolute = absolutizeImageUrl(src);
  const deliveryUrl = buildImageProxyUrl(absolute);
  const transformed = canUseCloudflareImageTransform(deliveryUrl);
  const srcset = transformed ? normalized.map((width) => `${buildCfImageUrl(src, { ...baseOptions, width })} ${width}w`).join(", ") : "";
  const fallbackWidth = config.fallbackWidth || normalized[Math.min(1, normalized.length - 1)] || 640;
  return {
    src: buildCfImageUrl(src, { ...baseOptions, width: fallbackWidth }),
    srcset,
    sizes: config.sizes || "100vw",
    original: deliveryUrl || absolute,
    directOriginal: absolute
  };
}

function renderOptimizedImageAttrs(src = "", config = {}) {
  const image = buildImageAttrs(src, config);
  const fallbackSrc = image.original || absolutizeImageUrl(src);
  const directFallbackSrc = image.directOriginal && image.directOriginal !== fallbackSrc ? image.directOriginal : "";
  return `src="${escapeHtml(image.src)}"${image.srcset ? ` srcset="${escapeHtml(image.srcset)}"` : ""} sizes="${escapeHtml(image.sizes)}" data-original-src="${escapeHtml(fallbackSrc)}"${directFallbackSrc ? ` data-direct-src="${escapeHtml(directFallbackSrc)}"` : ""} onerror="this.onerror=null;this.removeAttribute('srcset');this.src=this.dataset.originalSrc || this.dataset.directSrc;"`;
}
function getPostsHeroActiveKey() {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  const params = new URLSearchParams(window.location.search);
  const category = (params.get('category') || '').trim();

  if (path.includes('/about')) return 'about';
  if (category) return category;
  return 'all';
}


async function loadSiteCategories() {
  try {
    const res = await fetch('/api/categories', { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('Failed to load categories');
    const data = await res.json().catch(() => ({}));
    const rawItems = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : [];
    return rawItems
      .map((item) => {
        if (typeof item === 'string') return { name: item.trim(), count: 0 };
        return {
          name: String(item?.name || '').trim(),
          count: Number(item?.count || 0)
        };
      })
      .filter((item) => item.name);
  } catch (_) {
    return [];
  }
}

function mergeCategoryCounts(baseCategories = [], countedCategories = []) {
  const countMap = new Map(
    (Array.isArray(countedCategories) ? countedCategories : []).map((item) => [
      String(item?.name || '').trim(),
      Number(item?.count || 0)
    ])
  );

  const merged = [];
  const seen = new Set();

  (Array.isArray(baseCategories) ? baseCategories : []).forEach((item) => {
    const name = String(item?.name || '').trim();
    if (!name || seen.has(name)) return;
    seen.add(name);
    merged.push({
      name,
      count: countMap.has(name) ? countMap.get(name) : Number(item?.count || 0)
    });
  });

  (Array.isArray(countedCategories) ? countedCategories : []).forEach((item) => {
    const name = String(item?.name || '').trim();
    if (!name || seen.has(name)) return;
    seen.add(name);
    merged.push({
      name,
      count: Number(item?.count || 0)
    });
  });

  return merged;
}


function applyPostsHeroActiveState(container) {
  if (!container) return;
  const activeKey = getPostsHeroActiveKey();
  const links = container.querySelectorAll('.posts-home-hero__category-link, .posts-home-hero__about-link');
  links.forEach((link) => {
    const key = String(link.getAttribute('data-active-key') || '').trim();
    const isActive = key && key === activeKey;
    link.classList.toggle('is-active', isActive);
    if (isActive) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
}

function buildPostsHeroNav(categories = []) {
  const activeKey = getPostsHeroActiveKey();
  const unique = [];
  const seen = new Set();

  (Array.isArray(categories) ? categories : []).forEach((cat) => {
    const name = String(cat?.name || '').trim();
    if (!name || seen.has(name)) return;
    seen.add(name);
    unique.push({ name, count: Number(cat?.count || 0) });
  });

  const items = [
    `<a class="posts-home-hero__category-link ${activeKey === 'all' ? 'is-active' : ''}" data-active-key="all" ${activeKey === 'all' ? 'aria-current="page"' : ''} href="/">ALL</a>`,
    ...unique.map((cat) => {
      const safeName = cat.name;
      const isActive = activeKey === safeName;
      const href = `/?category=${encodeURIComponent(safeName)}`;
      return `<a class="posts-home-hero__category-link ${isActive ? 'is-active' : ''}" data-active-key="${escapeHtml(safeName)}" ${isActive ? 'aria-current="page"' : ''} href="${href}">${escapeHtml(safeName)}</a>`;
    }),
    `<a class="posts-home-hero__about-link ${activeKey === 'about' ? 'is-active' : ''}" data-active-key="about" ${activeKey === 'about' ? 'aria-current="page"' : ''} href="/about/">ABOUT</a>`
  ];

  return items.join('');
}


/* CITY_HOTEL_PICKS_RUNTIME_V3 */
(function () {
  const cityPostRoots = Array.from(document.querySelectorAll('[data-city-post-root]'));
  const cityTravelRoots = Array.from(document.querySelectorAll('[data-city-travel-root]'));
  if (!cityPostRoots.length && !cityTravelRoots.length) return;

  const CITY_ARCHIVES = {
    osaka: {
      top5_series: '/destinations/osaka/hotel-recommendations/',
      hotel_intro: '/destinations/osaka/hotels/',
      fallback: '/destinations/osaka/hotels/',
      fallbackLabel: '오사카 호텔 글 더 보기 →'
    },
    fukuoka: {
      top5_series: '/destinations/fukuoka/hotel-recommendations/',
      hotel_intro: '/destinations/fukuoka/hotels/',
      fallback: '/destinations/fukuoka/hotels/',
      fallbackLabel: '후쿠오카 호텔 글 더 보기 →'
    },
    tokyo: {
      top5_series: '/destinations/tokyo/hotel-recommendations/',
      hotel_intro: '/destinations/tokyo/hotels/',
      fallback: '/destinations/tokyo/hotels/',
      fallbackLabel: '도쿄 호텔 글 더 보기 →'
    },
    sapporo: {
      top5_series: '/destinations/sapporo/hotel-recommendations/',
      hotel_intro: '/destinations/sapporo/hotels/',
      fallback: '/destinations/sapporo/hotels/',
      fallbackLabel: '삿포로 호텔 글 더 보기 →'
    },
    okinawa: {
      top5_series: '/destinations/okinawa/hotel-recommendations/',
      hotel_intro: '/destinations/okinawa/hotels/',
      fallback: '/destinations/okinawa/hotels/',
      fallbackLabel: '오키나와 호텔 글 더 보기 →'
    }
  };

  const HOTEL_ARCHIVE_LABELS = {
    top5_series: '여행 스타일별 호텔 추천 더 보기 →',
    hotel_intro: '추천 호텔 리뷰 더 보기 →'
  };

  const fetchJson = async (url, fallback) => {
    try {
      const response = await fetch(url, { headers: { accept: 'application/json' }, cache: 'no-store' });
      if (!response.ok) return fallback;
      return await response.json();
    } catch (_) {
      return fallback;
    }
  };

  const buildDestinationPostUrl = ({ destination, type, offset = 0, limit = 6 }) => {
    const params = new URLSearchParams({
      destination: String(destination || ''),
      type: String(type || ''),
      offset: String(Math.max(0, Number(offset || 0))),
      limit: String(Math.max(1, Number(limit || 6)))
    });
    return '/api/destination-posts?' + params.toString();
  };

  const renderEmpty = (grid) => {
    if (!grid) return;
    grid.innerHTML = '<div class="empty-card" data-city-post-empty="">아직 관련글이 없습니다.</div>';
  };

  const renderTravelEmpty = (list) => {
    if (!list) return;
    list.innerHTML = '<div class="empty-card" data-city-travel-empty="">아직 관련 글이 없습니다.</div>';
  };

  const setFooterLink = ({ footer, destination, type, hasItems }) => {
    if (!footer) return;
    footer.innerHTML = '';
    footer.hidden = true;
    if (!hasItems) return;
    const archive = CITY_ARCHIVES[destination] || {};
    const href = archive[type] || archive.fallback || `/destinations/${encodeURIComponent(destination || '')}/hotels/`;
    const label = HOTEL_ARCHIVE_LABELS[type] || archive.fallbackLabel || '호텔 글 더 보기 →';
    footer.innerHTML = `<a class="hotel-load-more" href="${escapeHtml(href)}">${escapeHtml(label)}</a>`;
    footer.hidden = false;
  };

  const setActiveTab = (root, type) => {
    if (!root) return;
    root.querySelectorAll('[data-city-post-tab]').forEach((button) => {
      const active = button.getAttribute('data-city-post-tab') === type;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    root.querySelectorAll('[data-city-post-panel]').forEach((panel) => {
      const active = panel.getAttribute('data-city-post-panel') === type;
      panel.classList.toggle('is-active', active);
      panel.hidden = !active;
    });
  };

  const loadHotelGroup = async (root, type) => {
    const destination = String(root?.dataset?.destinationSlug || '').trim();
    const limit = Math.max(1, Number(root?.dataset?.pageSize || 6) || 6);
    const grid = root?.querySelector(`[data-city-post-grid="${type}"]`);
    const footer = root?.querySelector(`[data-city-post-footer="${type}"]`);
    if (!destination || !grid) return { type, hasItems: false, total: 0 };

    grid.setAttribute('aria-busy', 'true');
    const data = await fetchJson(buildDestinationPostUrl({ destination, type, offset: 0, limit }), {
      ok: false,
      html: '',
      hasMore: false,
      nextOffset: 0,
      total: 0
    });

    const hasHtml = Boolean(data && data.ok && String(data.html || '').trim());
    if (!hasHtml) {
      grid.innerHTML = '';
      setFooterLink({ footer, destination, type, hasItems: false });
      grid.removeAttribute('aria-busy');
      return { type, hasItems: false, total: Number(data?.total || 0) };
    }

    grid.innerHTML = data.html;
    setFooterLink({ footer, destination, type, hasItems: true });
    grid.removeAttribute('aria-busy');
    return { type, hasItems: true, total: Number(data?.total || 0) };
  };

  const updateHotelSectionVisibility = (root, results = []) => {
    if (!root) return;
    const section = root.closest('.wt-city-dynamic-section');
    const availableTypes = (Array.isArray(results) ? results : [])
      .filter((item) => item && item.hasItems)
      .map((item) => item.type);
    const hasAnyContent = availableTypes.length > 0;

    if (section) section.hidden = !hasAnyContent;
    root.hidden = !hasAnyContent;
    if (!hasAnyContent) return;

    root.querySelectorAll('[data-city-post-tab]').forEach((button) => {
      const type = button.getAttribute('data-city-post-tab');
      const isAvailable = availableTypes.includes(type);
      button.hidden = !isAvailable;
      button.dataset.cityPostDisabled = isAvailable ? 'false' : 'true';
      button.setAttribute('aria-hidden', isAvailable ? 'false' : 'true');
      if (isAvailable) {
        button.style.removeProperty('display');
      } else {
        button.style.display = 'none';
        button.classList.remove('is-active');
        button.setAttribute('aria-selected', 'false');
        button.setAttribute('tabindex', '-1');
      }
    });

    root.querySelectorAll('[data-city-post-panel]').forEach((panel) => {
      const type = panel.getAttribute('data-city-post-panel');
      const isAvailable = availableTypes.includes(type);
      panel.dataset.cityPostDisabled = isAvailable ? 'false' : 'true';
      panel.setAttribute('aria-hidden', isAvailable ? 'false' : 'true');
      if (isAvailable) {
        panel.style.removeProperty('display');
      } else {
        panel.hidden = true;
        panel.style.display = 'none';
        panel.classList.remove('is-active');
      }
    });

    const currentActive = root.querySelector('[data-city-post-tab].is-active:not([hidden])')?.getAttribute('data-city-post-tab');
    setActiveTab(root, currentActive || availableTypes[0]);
  };

  const loadTravelPosts = async (root) => {
    const destination = String(root?.dataset?.destinationSlug || '').trim();
    const limit = Math.max(1, Number(root?.dataset?.pageSize || 5) || 5);
    const list = root?.querySelector('[data-city-travel-list]');
    const footer = root?.querySelector('[data-city-travel-footer]');
    const section = root?.closest('.wt-city-dynamic-section');
    if (!destination || !list) {
      if (section) section.hidden = true;
      if (root) root.hidden = true;
      return;
    }

    const data = await fetchJson(buildDestinationPostUrl({ destination, type: 'travel_content', offset: 0, limit }), {
      ok: false,
      html: '',
      hasMore: false,
      nextOffset: 0
    });

    if (data && data.ok && String(data.html || '').trim()) {
      list.innerHTML = data.html;
      if (footer) {
        if (data.hasMore) {
          footer.innerHTML = `<button class="hotel-load-more" type="button" data-city-travel-more="travel_content" data-offset="${Number(data.nextOffset || limit)}">더보기</button>`;
          footer.hidden = false;
        } else {
          footer.innerHTML = '';
          footer.hidden = true;
        }
      }
      if (section) section.hidden = false;
      root.hidden = false;
      return;
    }

    list.innerHTML = '';
    if (footer) {
      footer.innerHTML = '';
      footer.hidden = true;
    }
    if (section) section.hidden = true;
    root.hidden = true;
  };

  cityPostRoots.forEach((root) => {
    const section = root.closest('.wt-city-dynamic-section');
    if (section) section.hidden = true;

    root.addEventListener('click', (event) => {
      const tabButton = event.target.closest('[data-city-post-tab]');
      if (!tabButton || !root.contains(tabButton) || tabButton.hidden) return;
      event.preventDefault();
      setActiveTab(root, tabButton.getAttribute('data-city-post-tab'));
    });

    root.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      const tabButton = event.target.closest('[data-city-post-tab]');
      if (!tabButton || !root.contains(tabButton) || tabButton.hidden) return;
      event.preventDefault();
      setActiveTab(root, tabButton.getAttribute('data-city-post-tab'));
    });

    Promise.all([
      loadHotelGroup(root, 'top5_series'),
      loadHotelGroup(root, 'hotel_intro')
    ]).then((results) => updateHotelSectionVisibility(root, results));
  });

  cityTravelRoots.forEach((root) => {
    const section = root.closest('.wt-city-dynamic-section');
    if (section) section.hidden = true;
    root.hidden = true;

    root.addEventListener('click', async (event) => {
      const moreButton = event.target.closest('[data-city-travel-more]');
      if (!moreButton || moreButton.dataset.loading === '1') return;
      const destination = String(root.dataset.destinationSlug || '').trim();
      const list = root.querySelector('[data-city-travel-list]');
      const footer = root.querySelector('[data-city-travel-footer]');
      const offset = Number(moreButton.dataset.offset || 0);
      const limit = Math.max(1, Number(root.dataset.pageSize || 5) || 5);
      if (!destination || !list || !footer) return;

      moreButton.dataset.loading = '1';
      moreButton.textContent = '불러오는 중...';
      const data = await fetchJson(buildDestinationPostUrl({ destination, type: 'travel_content', offset, limit }), {
        ok: false,
        html: '',
        hasMore: false,
        nextOffset: offset
      });
      if (data && data.ok && String(data.html || '').trim()) list.insertAdjacentHTML('beforeend', data.html);
      if (data && data.hasMore) {
        footer.innerHTML = `<button class="hotel-load-more" type="button" data-city-travel-more="travel_content" data-offset="${Number(data.nextOffset || offset + limit)}">더보기</button>`;
        footer.hidden = false;
      } else {
        footer.innerHTML = '';
        footer.hidden = true;
      }
    });
    loadTravelPosts(root);
  });
})();

(function () {
  const $ = (sel) => document.querySelector(sel);
  const listEl = $('#postsList');
  const loadingEl = $('#postsLoading');
  const errorEl = $('#postsError');
  const emptyEl = $('#postsEmpty');
  const pageTitleEl = $('#postsPageTitle');
  const pageDescEl = $('#postsPageDescription');
  const postsSummaryEl = $('#postsSummary');
  const postsCategoriesEl = $('#postsCategories');
  const postsCategoriesBarEl = $('#postsCategoriesBar');
  const heroCategoryBarEl = $('#heroCategoryBar');
  const postsCategoriesToggleEl = $('#postsCategoriesToggle');
  const postsCategoriesMenuEl = $('#postsCategoriesMenu');
  const postsCategoriesCloseEl = $('#postsCategoriesClose');
  const postsPopularEl = $('#postsPopular');
  const mobileSiteCategoryBarEl = $('#mobileSiteCategoryBar');
  const indexSidebarAdEl = document.querySelector('[data-index-sidebar-ad]');

  const postsHomeHeroEl = $('#postsHomeHero');

  // 정적 도시/가이드 페이지에는 글 목록 DOM이 없을 수 있습니다.
  // 이 경우 /api/posts 호출과 목록 렌더링을 건너뛰어 null.innerHTML 오류를 방지합니다.
  const hasPostsRuntimeTarget = Boolean(
    listEl || postsHomeHeroEl || heroCategoryBarEl || postsCategoriesEl ||
    postsCategoriesBarEl || postsPopularEl || mobileSiteCategoryBarEl
  );
  if (!hasPostsRuntimeTarget) return;

  function setHomeHeroMode() {
    if (!postsHomeHeroEl) return;
    const isHomeDefault = !category && !tag && safeStatus === 'published';
    postsHomeHeroEl.classList.toggle('posts-home-hero--index', isHomeDefault);
    postsHomeHeroEl.classList.toggle('posts-home-hero--category', !isHomeDefault);

    if (pageTitleEl) {
      pageTitleEl.classList.toggle('posts-home-hero__title--editorial', isHomeDefault);
      pageTitleEl.textContent = isHomeDefault ? 'Wacky Travel' : getPageTitle();
    }

    if (pageDescEl) {
      pageDescEl.classList.toggle('posts-home-hero__desc--editorial', isHomeDefault);
      if (isHomeDefault) {
        pageDescEl.textContent = '정리된 여행지 정보와 호텔 가이드를 빠르게 살펴보세요.';
      } else {
        pageDescEl.innerHTML = getPageDescription();
      }
    }

    const kickerEl = postsHomeHeroEl.querySelector('.posts-home-hero__kicker');
    const heroCategoryWrap = postsHomeHeroEl.querySelector('.posts-home-hero__category-wrap');
    if (kickerEl) kickerEl.hidden = !isHomeDefault;
    if (heroCategoryWrap) heroCategoryWrap.hidden = false;
  }
  const loadMoreWrap = $('#postsLoadMoreWrap');
  const loadMoreBtn = $('#postsLoadMoreBtn');

  const show = (el, on) => { if (el) el.hidden = !on; };
  const escapeHtml = (s) => String(s ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
  const url = new URL(window.location.href);
  const status = String(url.searchParams.get('status') || 'published').trim().toLowerCase();
  const category = String(url.searchParams.get('category') || '').trim();
  const tag = String(url.searchParams.get('tag') || '').trim();
  const initialPage = Math.max(1, Number.parseInt(url.searchParams.get('page') || '1', 10) || 1);
  const perPage = 8;
  const safeStatus = ['published', 'draft', 'all'].includes(status) ? status : 'published';

  let currentPage = initialPage;
  let hasMore = false;
  let isLoading = false;
  let isAdmin = false;
  let siteCategories = [];

  function buildApiUrl(page) {
    const apiUrl = new URL('/api/posts', window.location.origin);
    apiUrl.searchParams.set('page', String(page));
    apiUrl.searchParams.set('per_page', String(perPage));
    if (safeStatus) apiUrl.searchParams.set('status', safeStatus);
    if (category) apiUrl.searchParams.set('category', category);
    if (tag) apiUrl.searchParams.set('tag', tag);
    return apiUrl;
  }

  function buildPostsPageUrl(page) {
    const nextUrl = new URL('/', window.location.origin);
    if (safeStatus && safeStatus !== 'published') nextUrl.searchParams.set('status', safeStatus);
    if (category) nextUrl.searchParams.set('category', category);
    if (tag) nextUrl.searchParams.set('tag', tag);
    if (page > 1) nextUrl.searchParams.set('page', String(page));
    return `${nextUrl.pathname}${nextUrl.search}`;
  }

  function getPageTitle() {
    if (safeStatus === 'draft') return '초안 글 목록';
    if (safeStatus === 'all') return '전체 글 목록';
    if (category) return `카테고리: ${category}`;
    if (tag) return `태그: #${tag}`;
    return 'Wacky Travel';
  }

  function getPageDescription() {
    if (safeStatus === 'draft') return '관리 중인 초안 글만 빠르게 확인할 수 있습니다.';
    if (safeStatus === 'all') return '발행글과 초안글을 모두 확인할 수 있습니다.';
    if (category) return `<b>${escapeHtml(category)}</b> 카테고리의 글만 모아 보여드립니다.`;
    if (tag) return `<b>#${escapeHtml(tag)}</b> 태그가 포함된 글만 모아 보여드립니다.`;
    return '정리된 여행지 정보와 호텔 가이드를 빠르게 둘러보고 필요한 글만 골라 읽어보세요.';
  }

  async function loadAdminState() {
    const state = await (window.__adminSessionPromise || fetch('/api/admin/session', { credentials: 'same-origin' }).then((res) => res.ok ? res.json() : { authenticated: false }));
    isAdmin = Boolean(state && state.authenticated);
    return state;
  }

  function renderPostsSkeleton(count = 5, append = false) {
    if (!listEl) return;
    const markup = Array.from({ length: count }).map(() => `
      <article class="card post-card post-card--row post-card--skeleton" aria-hidden="true">
        <div class="post-card__thumb post-card__thumb--row skeleton-box skeleton-box--media"></div>
        <div class="post-card__body">
          <div class="post-meta post-meta--row">
            <div class="row row--chips">
              <span class="skeleton-box skeleton-box--chip"></span>
              <span class="skeleton-box skeleton-box--chip skeleton-box--chip-short"></span>
            </div>
            <span class="skeleton-box skeleton-box--date"></span>
          </div>
          <div class="skeleton-stack">
            <span class="skeleton-box skeleton-box--title"></span>
            <span class="skeleton-box skeleton-box--text"></span>
            <span class="skeleton-box skeleton-box--text skeleton-box--text-short"></span>
          </div>
          <div class="row post-admin-actions post-admin-actions--wrap">
            <span class="skeleton-box skeleton-box--button"></span>
            <span class="skeleton-box skeleton-box--button skeleton-box--button-muted"></span>
          </div>
        </div>
      </article>
    `).join('');

    if (append) listEl.insertAdjacentHTML('beforeend', `<div class="posts-skeleton-chunk">${markup}</div>`);
    else listEl.innerHTML = markup;
  }

  function clearAppendSkeleton() {
    listEl?.querySelectorAll('.posts-skeleton-chunk').forEach((el) => el.remove());
  }

  function renderSidebarSkeleton() {
    const categorySkeleton = Array.from({ length: 8 }).map(() => '<span class="topbar-categories__chip topbar-categories__chip--skeleton skeleton-box"></span>').join('');
    if (postsCategoriesBarEl) postsCategoriesBarEl.innerHTML = categorySkeleton;
    if (heroCategoryBarEl) heroCategoryBarEl.innerHTML = categorySkeleton;
    if (mobileSiteCategoryBarEl) mobileSiteCategoryBarEl.innerHTML = categorySkeleton;
    if (postsPopularEl) {
      postsPopularEl.innerHTML = Array.from({ length: 5 }).map((_, index) => `
        <li class="post-side__popular-link post-side__popular-link--skeleton" aria-hidden="true">
          <span class="post-side__popular-rank post-side__popular-rank--skeleton">${index + 1}</span>
          <span class="skeleton-box skeleton-box--popular"></span>
        </li>
      `).join('');
    }
  }

  function formatCountLabel(count, label) {
    return `<div class="posts-summary-card"><strong>${count}</strong><span>${label}</span></div>`;
  }

  function renderSidebar(sidebarData = {}) {
    const counts = sidebarData.counts || {};
    const categories = Array.isArray(sidebarData.categories) ? sidebarData.categories : [];
    const popular = Array.isArray(sidebarData.popular) ? sidebarData.popular : [];
    const settings = sidebarData.settings || {};
    const showIndexSidebarAd = Boolean(settings.index_sidebar_ad_enabled);

    if (indexSidebarAdEl) {
      indexSidebarAdEl.hidden = !showIndexSidebarAd;
    }

    if (postsSummaryEl) {
      postsSummaryEl.innerHTML = [
        formatCountLabel(Number(counts.total || 0), safeStatus === 'draft' ? '초안 글' : '전체 글'),
        formatCountLabel(Number(counts.published || 0), '발행'),
        formatCountLabel(Number(counts.draft || 0), '초안')
      ].join('');
    }

    if (postsCategoriesEl) {
      postsCategoriesEl.innerHTML = '';
    }

    const navCategories = mergeCategoryCounts(siteCategories, categories);
    

    const categoryLinksHtml = navCategories.length
      ? navCategories.map((item) => {
          const name = String(item.name || '').trim();
          return `<a class="topbar-categories__chip" href="/?category=${encodeURIComponent(name)}">${escapeHtml(name)} <span>${Number(item.count || 0)}</span></a>`;
        }).join('')
      : '<span class="small">표시할 카테고리가 없습니다.</span>';

    const categoriesHtml = `<a class="topbar-categories__chip topbar-categories__chip--utility" href="/">ALL</a>${categoryLinksHtml}<a class="topbar-categories__chip topbar-categories__chip--utility" href="/about/">ABOUT</a>`;

    if (postsCategoriesBarEl) {
      postsCategoriesBarEl.innerHTML = categoriesHtml;
    }

    if (heroCategoryBarEl) {
      heroCategoryBarEl.innerHTML = buildPostsHeroNav(navCategories);
      applyPostsHeroActiveState(heroCategoryBarEl);
    }

    if (mobileSiteCategoryBarEl) {
      mobileSiteCategoryBarEl.innerHTML = categoriesHtml;
    }

    if (postsPopularEl) {
      postsPopularEl.innerHTML = popular.length
        ? popular.map((item, index) => `
            <li>
              <a class="post-side__popular-link" href="/post/${encodeURIComponent(String(item.slug || ''))}">
                <span class="post-side__popular-rank">${index + 1}</span>
                <span class="post-side__popular-text">${escapeHtml(String(item.title || '제목 없음'))}</span>
              </a>
            </li>
          `).join('')
        : '<li class="small">인기글이 없습니다.</li>';
    }
  }

  function renderItems(items, { append = false, pageNumber = currentPage } = {}) {
    if (!listEl) return;
    const markup = items.map((it, index) => {
      const rawTitle = String(it.title || '(제목 없음)');
      const title = escapeHtml(rawTitle);
      const categoryText = String(it.category || '').trim();
      const categoryHtml = categoryText
        ? `<a class="badge" href="/?category=${encodeURIComponent(categoryText)}">${escapeHtml(categoryText)}</a>`
        : `<span class="badge">미분류</span>`;
      const summary = escapeHtml(it.summary || '요약이 아직 없습니다.');
      const slug = String(it.slug || '');
      const updated = escapeHtml(String(it.updated_at || '').slice(0, 10));
      const cover = String(it.cover_image || '').trim();
      const itemStatus = String(it.status || 'published').trim().toLowerCase();
      const statusBadge = itemStatus === 'draft'
        ? '<span class="badge badge--draft">초안</span>'
        : '<span class="badge">발행</span>';
      const postHref = itemStatus === 'published' ? `/post/${encodeURIComponent(slug)}` : `/edit.html?slug=${encodeURIComponent(slug)}`;
      const shouldPrioritizeImage = !append && index === 0 && Number(pageNumber) === 1;
      const imageLoadingAttrs = shouldPrioritizeImage
        ? 'loading="eager" fetchpriority="high" decoding="async" width="640" height="360"'
        : 'loading="lazy" decoding="async" width="640" height="360"';


      return `
        <article class="card post-card post-card--row js-post-card" data-href="${postHref}" tabindex="0" aria-label="${title} 글로 이동">
          <div class="post-card__thumb post-card__thumb--row">
            ${cover ? `<img ${renderOptimizedImageAttrs(cover, { widths: [320, 640, 960], sizes: "(max-width: 720px) 100vw, 320px", fallbackWidth: 640, fit: "cover", quality: 82 })} alt="${title} 대표 이미지" ${imageLoadingAttrs} />` : '<div class="post-card__thumb-placeholder">대표 이미지 없음</div>'}
          </div>
          <div class="post-card__body">
            <div class="post-meta post-meta--row">
              <div class="row row--chips">
                ${categoryHtml}
                ${isAdmin ? statusBadge : ''}
              </div>
              <div class="small">${updated}</div>
            </div>
            <div class="post-card__title">${title}</div>
            <div class="post-card__summary">${summary}</div>
            <div class="row post-admin-actions post-admin-actions--wrap">
              ${itemStatus === 'published' ? `<a class="post-card__readmore" href="/post/${encodeURIComponent(slug)}"><span class="post-card__readmore-text">Read more</span><svg class="post-card__readmore-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 12h11"></path><path d="M13 7l5 5-5 5"></path></svg></a>` : ''}
              ${isAdmin ? `<span class="post-admin-actions__controls"><a class="btn" href="/edit.html?slug=${encodeURIComponent(slug)}">수정</a><button class="btn btn--danger js-delete-post" type="button" data-slug="${encodeURIComponent(slug)}" data-title="${escapeHtml(rawTitle)}">삭제</button></span>` : ''}
            </div>
          </div>
        </article>
      `;
    }).join('');

    if (append) listEl.insertAdjacentHTML('beforeend', markup);
    else listEl.innerHTML = markup;
  }

  function updateLoadMore(pagination = {}) {
    hasMore = Boolean(pagination.has_more);
    show(loadMoreWrap, hasMore);
    if (loadMoreBtn) {
      loadMoreBtn.disabled = !hasMore || isLoading;
      loadMoreBtn.textContent = isLoading ? '불러오는 중…' : '더보기';
    }
  }

  async function fetchPage(page, { append = false } = {}) {
    if (!listEl) return;
    if (isLoading) return;
    isLoading = true;
    updateLoadMore({ has_more: hasMore, next_page: page });
    show(errorEl, false);
    if (!append) {
      show(loadingEl, false);
      show(emptyEl, false);
      renderPostsSkeleton();
      renderSidebarSkeleton();
    } else {
      renderPostsSkeleton(2, true);
    }

    try {
      const res = await fetch(buildApiUrl(page).toString(), { headers: { accept: 'application/json' } });
      if (!res.ok) throw new Error('API 오류: ' + res.status);
      const data = await res.json();
      const items = Array.isArray(data?.items) ? data.items : [];
      const pagination = data?.pagination || {};
      const sidebar = data?.sidebar || {};

      clearAppendSkeleton();

      if (!items.length && !append) {
        if (listEl) listEl.innerHTML = '';
        renderSidebar(sidebar);
        show(emptyEl, true);
        if (emptyEl) {
          if (safeStatus === 'draft') emptyEl.textContent = '등록된 초안 글이 없습니다.';
          else if (category) emptyEl.textContent = `'${category}' 카테고리 글이 없습니다.`;
          else if (tag) emptyEl.textContent = `'#${tag}' 태그 글이 없습니다.`;
          else emptyEl.textContent = '등록된 글이 없습니다.';
        }
        updateLoadMore({ has_more: false, next_page: null });
        return;
      }

      renderSidebar(sidebar);
      renderItems(items, { append, pageNumber: page });
      currentPage = Number(pagination.page || page);
      updateLoadMore(pagination);

      const nextUrl = new URL(window.location.href);
      if (currentPage > 1) nextUrl.searchParams.set('page', String(currentPage));
      else nextUrl.searchParams.delete('page');
      window.history.replaceState({ page: currentPage }, '', `${nextUrl.pathname}${nextUrl.search}`);
    } catch (err) {
      clearAppendSkeleton();
      if (!append) {
        if (listEl) listEl.innerHTML = '';
        renderSidebar({ counts: { total: 0, published: 0, draft: 0 }, categories: [], popular: [] });
      }
      show(emptyEl, false);
      show(errorEl, true);
      if (errorEl) errorEl.textContent = '목록을 불러오지 못했습니다. ' + (err?.message || '');
    } finally {
      isLoading = false;
      updateLoadMore({ has_more: hasMore, next_page: currentPage + 1 });
    }
  }

  if (pageTitleEl) pageTitleEl.textContent = getPageTitle();
  if (pageDescEl) pageDescEl.innerHTML = getPageDescription();

  function closeCategoriesMenu() {
    if (!postsCategoriesMenuEl || !postsCategoriesToggleEl) return;
    postsCategoriesMenuEl.hidden = true;
    postsCategoriesToggleEl.setAttribute('aria-expanded', 'false');
  }

  function openCategoriesMenu() {
    if (!postsCategoriesMenuEl || !postsCategoriesToggleEl) return;
    postsCategoriesMenuEl.hidden = false;
    postsCategoriesToggleEl.setAttribute('aria-expanded', 'true');
  }

  postsCategoriesToggleEl?.addEventListener('click', () => {
    if (!postsCategoriesMenuEl) return;
    if (postsCategoriesMenuEl.hidden) openCategoriesMenu();
    else closeCategoriesMenu();
  });

  postsCategoriesCloseEl?.addEventListener('click', closeCategoriesMenu);

  document.addEventListener('click', (event) => {
    if (!postsCategoriesMenuEl || postsCategoriesMenuEl.hidden) return;
    const inside = event.target.closest('#postsCategoriesMenu, #postsCategoriesToggle');
    if (!inside) closeCategoriesMenu();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeCategoriesMenu();
  });

  loadMoreBtn?.addEventListener('click', () => {
    if (!hasMore || isLoading) return;
    fetchPage(currentPage + 1, { append: true });
  });

  listEl?.addEventListener('click', async (event) => {
    const deleteBtn = event.target.closest('.js-delete-post');
    if (deleteBtn) {
      const slug = decodeURIComponent(String(deleteBtn.dataset.slug || ''));
      const title = String(deleteBtn.dataset.title || slug || '이 글');
      if (!slug) return;
      const confirmed = window.confirm(`'${title}' 글을 삭제할까요? 삭제 후 되돌릴 수 없습니다.`);
      if (!confirmed) return;
      deleteBtn.disabled = true;
      deleteBtn.textContent = '삭제 중…';
      try {
        const res = await fetch(`/api/posts/${encodeURIComponent(slug)}`, { method: 'DELETE' });
        const json = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(json?.message || `삭제 실패 (${res.status})`);
        const card = deleteBtn.closest('.post-card');
        if (card) card.remove();
        if (!listEl.children.length) {
          show(emptyEl, true);
          emptyEl.textContent = '등록된 글이 없습니다.';
        }
      } catch (err) {
        alert(err?.message || '삭제 중 오류가 발생했습니다.');
        deleteBtn.disabled = false;
        deleteBtn.textContent = '삭제';
      }
      return;
    }

    const blockedTarget = event.target.closest('a, button, input, select, textarea, label');
    if (blockedTarget) return;

    const card = event.target.closest('.js-post-card');
    const href = card?.dataset.href;
    if (href) window.location.href = href;
  });

  listEl?.addEventListener('keydown', (event) => {
    const card = event.target.closest('.js-post-card');
    if (!card) return;
    if (event.key !== 'Enter' && event.key !== ' ') return;
    const href = card.dataset.href;
    if (!href) return;
    event.preventDefault();
    window.location.href = href;
  });

  Promise.all([
    loadAdminState().catch(() => ({ authenticated: false })),
    loadSiteCategories().catch(() => [])
  ]).then(([_, categoriesResult]) => {
    siteCategories = Array.isArray(categoriesResult) ? categoriesResult : [];
    if (heroCategoryBarEl && siteCategories.length) {
      heroCategoryBarEl.innerHTML = buildPostsHeroNav(siteCategories);
    }
    fetchPage(initialPage, { append: false });
  });
})();

/* WACKYTRAVEL_HOTEL_TABS_ROBUST_CONTROLLER_V1 */
(function () {
  const TAB_SELECTOR = '[data-city-post-tab]';
  const PANEL_SELECTOR = '[data-city-post-panel]';
  const ROOT_SELECTOR = '[data-city-post-root]';

  function getTabType(tab) {
    return String(tab?.getAttribute('data-city-post-tab') || '').trim();
  }

  function getRootFromElement(element) {
    return element?.closest?.(ROOT_SELECTOR) || element?.closest?.('.hotel-tabs') || null;
  }

  function isActuallyHidden(element) {
    if (!element) return true;
    if (element.hidden) return true;
    if (element.getAttribute('aria-hidden') === 'true') return true;
    if (element.dataset.cityPostDisabled === 'true') return true;
    return false;
  }

  function getVisibleTabs(root) {
    return Array.from(root?.querySelectorAll(TAB_SELECTOR) || []).filter((tab) => !isActuallyHidden(tab));
  }

  function forcePanelState(panel, active) {
    if (!panel) return;
    panel.classList.toggle('is-active', active);
    panel.hidden = !active;
    panel.setAttribute('aria-hidden', active ? 'false' : 'true');
    if (active) {
      panel.removeAttribute('hidden');
      panel.style.removeProperty('display');
    } else {
      panel.setAttribute('hidden', '');
      panel.style.display = 'none';
    }
  }

  function forceTabState(tab, active) {
    if (!tab) return;
    tab.classList.toggle('is-active', active);
    tab.setAttribute('aria-selected', active ? 'true' : 'false');
    tab.setAttribute('tabindex', active ? '0' : '-1');
  }

  function activateHotelTab(root, requestedType, options = {}) {
    if (!root) return false;
    const visibleTabs = getVisibleTabs(root);
    const fallbackType = getTabType(visibleTabs[0]);
    const type = String(requestedType || fallbackType || '').trim();
    if (!type) return false;

    const targetTab = visibleTabs.find((tab) => getTabType(tab) === type) || visibleTabs[0];
    const activeType = getTabType(targetTab) || type;

    Array.from(root.querySelectorAll(TAB_SELECTOR)).forEach((tab) => {
      forceTabState(tab, getTabType(tab) === activeType && !isActuallyHidden(tab));
    });

    Array.from(root.querySelectorAll(PANEL_SELECTOR)).forEach((panel) => {
      forcePanelState(panel, String(panel.getAttribute('data-city-post-panel') || '').trim() === activeType);
    });

    if (targetTab && options.scroll === true && typeof targetTab.scrollIntoView === 'function') {
      try {
        targetTab.scrollIntoView({ behavior: 'smooth', inline: 'nearest', block: 'nearest' });
      } catch (_) {}
    }
    return true;
  }

  function normalizeHotelTabs(root) {
    if (!root) return;
    const visibleTabs = getVisibleTabs(root);
    if (!visibleTabs.length) return;
    const current = visibleTabs.find((tab) => tab.classList.contains('is-active')) || visibleTabs[0];
    activateHotelTab(root, getTabType(current), { scroll: false });
  }

  function normalizeAllHotelTabs() {
    document.querySelectorAll(ROOT_SELECTOR).forEach(normalizeHotelTabs);
  }

  document.addEventListener('click', function (event) {
    const tab = event.target?.closest?.(TAB_SELECTOR);
    if (!tab) return;
    const root = getRootFromElement(tab);
    if (!root || !root.contains(tab) || isActuallyHidden(tab)) return;
    event.preventDefault();
    activateHotelTab(root, getTabType(tab));
  }, true);

  document.addEventListener('keydown', function (event) {
    const currentTab = event.target?.closest?.(TAB_SELECTOR);
    if (!currentTab) return;
    const root = getRootFromElement(currentTab);
    if (!root || !root.contains(currentTab) || isActuallyHidden(currentTab)) return;

    const tabs = getVisibleTabs(root);
    if (!tabs.length) return;
    const currentIndex = Math.max(0, tabs.indexOf(currentTab));
    let nextIndex = currentIndex;

    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      activateHotelTab(root, getTabType(currentTab));
      return;
    }
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') nextIndex = (currentIndex + 1) % tabs.length;
    else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
    else if (event.key === 'Home') nextIndex = 0;
    else if (event.key === 'End') nextIndex = tabs.length - 1;
    else return;

    event.preventDefault();
    tabs[nextIndex]?.focus?.();
    activateHotelTab(root, getTabType(tabs[nextIndex]));
  }, true);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', normalizeAllHotelTabs, { once: true });
  } else {
    normalizeAllHotelTabs();
  }

  window.WackyTravelHotelTabs = {
    activate: activateHotelTab,
    normalize: normalizeAllHotelTabs
  };
})();

