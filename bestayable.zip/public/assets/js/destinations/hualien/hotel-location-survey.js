/* 화렌 hotel location survey logic. Modernized with the Fukuoka V23 survey UI flow. */
const cityConfig = {
  "cityName": "화렌",
  "destinationSlug": "hualien",
  "postContentType": "top5_series",
  "areas": {
    "station": {
      "name": "화렌역·시내중심",
      "slug": "hualien-station",
      "summary": "기차로 도착해 짐을 맡기고 투어를 준비하는 동선이 단순하게 이어지는 중심에서 화렌 여행의 시작을 차분하게 정리하고 싶은 당신에게 잘 맞는 실용적인 위치입니다.",
      "lead": "화렌은 대만 서부 도시처럼 지하철로 움직이는 도시가 아닙니다. 기차역 주변에 머물면 도착 첫날과 출발일 동선이 편하고, 동대문 야시장·구시가지·치싱탄·타이루거 방향으로 이동할 때 출발점을 잡기 쉽습니다.",
      "decision": "화렌이 처음이고 기차로 들어온다면 가장 안정적인 기본 선택지입니다.",
      "chips": [
        "첫 여행",
        "기차역",
        "짐 보관",
        "투어 출발",
        "짧은 일정"
      ],
      "regionSlug": "hualien-station",
      "label": "화렌이 처음이고 기차로 들어온다면 가장 안정적인 기본 선택지입니다.",
      "leadTitle": "기차 도착과 시내 이동을 가장 단순하게 묶는 기본 선택지",
      "leadText": "화렌은 대만 서부 도시처럼 지하철로 움직이는 도시가 아닙니다. 기차역 주변에 머물면 도착 첫날과 출발일 동선이 편하고, 동대문 야시장·구시가지·치싱탄·타이루거 방향으로 이동할 때 출발점을 잡기 쉽습니다.",
      "bestFor": [
        "첫 화렌 여행",
        "짧은 일정",
        "기차 이동",
        "짐이 많은 여행",
        "타이루거 투어 출발"
      ],
      "bookingTips": [
        "역 바로 앞이라는 표현만 보지 말고 실제 출구, 택시 승하차 위치, 동대문 야시장까지의 이동 시간을 함께 확인하세요.",
        "저녁 식사와 이동 방식을 함께 확인하세요.",
        "숙소 주변의 소음과 택시 승하차 편의를 함께 보세요."
      ],
      "compareGood": "화렌이 처음이고 기차로 들어온다면 가장 안정적인 기본 선택지입니다.",
      "compareCaution": "밤 먹거리와 산책을 숙소 주변에서 바로 즐기고 싶다면 동대문 야시장·구시가지 쪽이 더 편할 수 있습니다.",
      "mismatchNote": "일정 성격이 다르다면 다른 화렌 지역도 함께 비교해보세요.",
      "links": [
        {
          "title": "화렌역·시내중심 호텔 추천 TOP5",
          "url": "/post/hualien-station-hotels/"
        },
        {
          "title": "화렌 숙소 위치 가이드",
          "url": "/destinations/hualien/hotel-guide/"
        }
      ],
      "hotels": [
        {
          "name": "카인드니스 호텔 화렌",
          "englishName": "Kindness Hotel Hualien",
          "tag": "역 접근 실용형",
          "location": "화렌역 생활권",
          "reason": "기차 도착 후 체크인과 시내 이동을 단순하게 묶고 싶은 첫 여행자에게 잘 맞습니다.",
          "meta": [
            "화렌역·시내중심",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "메씨 호텔",
          "englishName": "Meci Hotel",
          "tag": "감성 실속형",
          "location": "화렌역 주변",
          "reason": "역 주변에서 숙박비와 분위기, 기본 편의성을 함께 보고 싶을 때 비교하기 좋습니다.",
          "meta": [
            "화렌역·시내중심",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "클래식 시티 리조트",
          "englishName": "Classic City Resort",
          "tag": "안정형 시티호텔",
          "location": "화렌역 도보권",
          "reason": "기차역 접근성과 객실 안정감을 함께 챙기고 싶은 일정에 어울립니다.",
          "meta": [
            "화렌역·시내중심",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "호텔데이+ 화렌",
          "englishName": "Hotelday+ Hualien",
          "tag": "깔끔한 역세권형",
          "location": "화렌역 생활권",
          "reason": "화렌역을 기준으로 투어와 시내 이동을 계획하는 여행자가 보기 좋습니다.",
          "meta": [
            "화렌역·시내중심",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "라마다 앙코르 바이 윈덤 화렌",
          "englishName": "Ramada Encore by Wyndham Hualien",
          "tag": "브랜드 안정형",
          "location": "화렌 시내권",
          "reason": "객실 컨디션과 이동 편의를 함께 보고 싶은 가족·커플 일정에 무난합니다.",
          "meta": [
            "화렌역·시내중심",
            "화렌",
            "숙소"
          ],
          "url": "#"
        }
      ]
    },
    "dongdamen": {
      "name": "동대문 야시장·구시가지",
      "slug": "dongdamen-old-town",
      "summary": "저녁이 되면 야시장과 구시가지 골목, 로컬 음식과 작은 상점이 자연스럽게 이어지는 거리에서 화렌의 따뜻한 밤 분위기를 느끼고 싶은 당신에게 잘 어울리는 지역입니다.",
      "lead": "낮에는 치싱탄이나 타이루거처럼 외곽 자연 명소를 다녀오고, 저녁에는 동대문 야시장과 구시가지에서 식사와 산책을 이어가기 좋습니다. 화렌역 바로 앞보다 여행지 분위기가 있고, 완전 외곽보다 식사 선택지가 많아 커플·친구 여행과 재방문 일정에 잘 맞습니다.",
      "decision": "밤 먹거리와 시내 산책, 로컬 분위기를 함께 보고 싶다면 가장 균형 좋은 시내권입니다.",
      "chips": [
        "야시장",
        "구시가지",
        "먹거리",
        "카페",
        "뚜벅이"
      ],
      "regionSlug": "dongdamen-old-town",
      "label": "밤 먹거리와 시내 산책, 로컬 분위기를 함께 보고 싶다면 가장 균형 좋은 시내권입니다.",
      "leadTitle": "야시장과 구시가지를 함께 묶어 화렌의 저녁 시간을 편하게 쓰는 지역",
      "leadText": "낮에는 치싱탄이나 타이루거처럼 외곽 자연 명소를 다녀오고, 저녁에는 동대문 야시장과 구시가지에서 식사와 산책을 이어가기 좋습니다. 화렌역 바로 앞보다 여행지 분위기가 있고, 완전 외곽보다 식사 선택지가 많아 커플·친구 여행과 재방문 일정에 잘 맞습니다.",
      "bestFor": [
        "먹거리 여행",
        "야시장",
        "구시가지 산책",
        "카페",
        "커플·친구 여행"
      ],
      "bookingTips": [
        "야시장과 너무 가까운 숙소는 밤 소음이 있을 수 있습니다. 큰길 접근성과 객실 방음 후기를 함께 보세요.",
        "화렌역에서 숙소까지 이동 방식과 체크인 시간, 밤 복귀 동선을 같이 확인하세요.",
        "중산로, 동대문 야시장, 문화창의산업원구 사이의 실제 도보 시간을 지도에서 확인하면 선택이 쉬워집니다."
      ],
      "compareGood": "저녁 식사, 야시장, 카페, 구시가지 산책을 숙소 주변에서 해결하기 좋습니다.",
      "compareCaution": "기차 도착 직후 짐 이동과 투어 픽업 편의만 보면 화렌역·시내중심이 더 단순할 수 있습니다.",
      "mismatchNote": "시내 분위기보다 조용한 호텔 휴식이나 바다 풍경이 중요하다면 메이룬·항구나 치싱탄·신청도 함께 비교하세요.",
      "links": [
        {
          "title": "동대문 야시장·구시가지 호텔 추천 TOP5",
          "url": "/post/dongdamen-old-town-hotels/"
        },
        {
          "title": "화렌 숙소 위치 가이드",
          "url": "/destinations/hualien/hotel-guide/"
        }
      ],
      "hotels": [
        {
          "name": "아르스마 호텔",
          "englishName": "Arsma Hotel",
          "tag": "야시장 접근형",
          "location": "동대문 야시장 생활권",
          "reason": "밤 먹거리와 시내 산책을 숙소 가까이 두고 싶은 일정에 좋습니다.",
          "meta": [
            "동대문 야시장·구시가지",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "애저 호텔",
          "englishName": "Azure Hotel",
          "tag": "시내 균형형",
          "location": "중산로·시내 생활권",
          "reason": "중심 상권과 주요 식당 접근성을 함께 챙기기 좋은 선택지입니다.",
          "meta": [
            "동대문 야시장·구시가지",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "저스트 슬립 화렌 중정",
          "englishName": "Just Sleep Hualien Zhongzheng",
          "tag": "구시가지 균형형",
          "location": "구시가지·중정로 주변",
          "reason": "구시가지 산책과 객실 안정감을 함께 보고 싶은 여행에 어울립니다.",
          "meta": [
            "동대문 야시장·구시가지",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "파인더스 호텔 화렌 다퉁",
          "englishName": "Finders Hotel Hualien Da-Tong",
          "tag": "감성 실속형",
          "location": "문화창의산업원구 주변",
          "reason": "카페와 골목 산책을 중심에 둔 짧은 일정에 잘 맞습니다.",
          "meta": [
            "동대문 야시장·구시가지",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "풀 카인드 호텔",
          "englishName": "Full Kind Hotel",
          "tag": "도심 편의형",
          "location": "동대문 야시장·구시가지",
          "reason": "저녁 식사와 편의시설을 가까이 두고 싶은 여행자에게 어울립니다.",
          "meta": [
            "동대문 야시장·구시가지",
            "화렌",
            "숙소"
          ],
          "url": "#"
        }
      ]
    },
    "meilun": {
      "name": "메이룬·항구",
      "slug": "meilun-harbor",
      "summary": "시내 중심의 분주함에서 조금 벗어나 항구 바람과 넓은 객실, 차분한 주변 분위기 속에서 가족과 함께 여유롭게 쉬고 싶은 당신에게 잘 맞는 조용한 지역입니다.",
      "lead": "가족 여행이나 부모님 동반처럼 숙소 컨디션, 조식, 택시 이동, 조용한 주변 환경을 중요하게 본다면 메이룬 지역이 편할 수 있습니다. 도심과 완전히 떨어진 외곽은 아니지만 밤 먹거리 중심지와는 거리가 있어 이동 방식을 함께 봐야 합니다.",
      "decision": "조용함과 호텔 컨디션을 우선하면 가족 여행 만족도가 높습니다.",
      "chips": [
        "가족",
        "조용함",
        "호텔 휴식",
        "항구",
        "택시 이동"
      ],
      "regionSlug": "meilun-harbor",
      "label": "조용함과 호텔 컨디션을 우선하면 가족 여행 만족도가 높습니다.",
      "leadTitle": "조용한 분위기와 호텔 체류 만족도를 함께 보기 좋은 북쪽 시내권",
      "leadText": "가족 여행이나 부모님 동반처럼 숙소 컨디션, 조식, 택시 이동, 조용한 주변 환경을 중요하게 본다면 메이룬 지역이 편할 수 있습니다. 도심과 완전히 떨어진 외곽은 아니지만 밤 먹거리 중심지와는 거리가 있어 이동 방식을 함께 봐야 합니다.",
      "bestFor": [
        "가족 여행",
        "부모님 동반",
        "조용한 숙소",
        "호텔 휴식",
        "택시 이동"
      ],
      "bookingTips": [
        "야시장·구시가지 식당까지는 택시나 버스 이동을 고려해야 합니다. 밤 복귀 방식을 미리 정해두세요.",
        "저녁 식사와 이동 방식을 함께 확인하세요.",
        "숙소 주변의 소음과 택시 승하차 편의를 함께 보세요."
      ],
      "compareGood": "조용함과 호텔 컨디션을 우선하면 가족 여행 만족도가 높습니다.",
      "compareCaution": "뚜벅이로 매일 야시장과 구시가지를 오가면 동선이 번거롭게 느껴질 수 있습니다.",
      "mismatchNote": "일정 성격이 다르다면 다른 화렌 지역도 함께 비교해보세요.",
      "links": [
        {
          "title": "메이룬·항구 호텔 추천 TOP5",
          "url": "/post/meilun-harbor-hotels/"
        },
        {
          "title": "화렌 숙소 위치 가이드",
          "url": "/destinations/hualien/hotel-guide/"
        }
      ],
      "hotels": [
        {
          "name": "레이크쇼어 호텔 화렌",
          "englishName": "Lakeshore Hotel Hualien",
          "tag": "가족 안정형",
          "location": "메이룬 생활권",
          "reason": "차분한 주변 분위기와 객실 컨디션을 함께 보고 싶은 가족 여행에 좋습니다.",
          "meta": [
            "메이룬·항구",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "샤토 드 신 호텔 화렌",
          "englishName": "Chateau de Chine Hotel Hualien",
          "tag": "가족형 호텔",
          "location": "메이룬·항구권",
          "reason": "부모님 동반이나 아이와 함께하는 일정에서 호텔 편의성을 보기 좋습니다.",
          "meta": [
            "메이룬·항구",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "풀론 호텔 화렌",
          "englishName": "Fullon Hotel Hualien",
          "tag": "항구 휴식형",
          "location": "화렌항 주변",
          "reason": "항구 분위기와 호텔 체류를 함께 즐기고 싶은 일정에 어울립니다.",
          "meta": [
            "메이룬·항구",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "파크뷰 호텔 화렌",
          "englishName": "Parkview Hotel Hualien",
          "tag": "리조트형 휴식",
          "location": "메이룬산 주변",
          "reason": "조용한 휴식과 넓은 시설을 원하는 가족·커플 여행에 비교하기 좋습니다.",
          "meta": [
            "메이룬·항구",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "카다 호텔",
          "englishName": "Kadda Hotel",
          "tag": "감성 항구형",
          "location": "메이룬·항구 생활권",
          "reason": "차분한 분위기와 감성적인 객실을 함께 보고 싶은 여행자에게 맞습니다.",
          "meta": [
            "메이룬·항구",
            "화렌",
            "숙소"
          ],
          "url": "#"
        }
      ]
    },
    "qixingtan": {
      "name": "치싱탄·신청",
      "slug": "qixingtan-xincheng",
      "summary": "자갈 해변과 넓은 태평양, 자전거길과 타이루거 북쪽 동선이 이어지는 풍경 속에서 바다와 자연을 가까이 두고 머물고 싶은 당신에게 잘 어울리는 해안 지역입니다.",
      "lead": "화렌 시내의 편의성보다 바다와 조용한 풍경이 더 중요하다면 치싱탄 쪽을 비교해볼 만합니다. 다만 밤 식사 선택지와 대중교통은 시내보다 제한적이므로 렌터카·택시·투어 이용 여부를 함께 봐야 합니다.",
      "decision": "바다와 조용한 풍경이 여행의 핵심이라면 1박 또는 여유 일정에 좋습니다.",
      "chips": [
        "바다",
        "조용함",
        "사진",
        "자전거",
        "자연"
      ],
      "regionSlug": "qixingtan-xincheng",
      "label": "바다와 조용한 풍경이 여행의 핵심이라면 1박 또는 여유 일정에 좋습니다.",
      "leadTitle": "바다와 자연 풍경을 여행의 중심에 두는 휴식형 지역",
      "leadText": "화렌 시내의 편의성보다 바다와 조용한 풍경이 더 중요하다면 치싱탄 쪽을 비교해볼 만합니다. 다만 밤 식사 선택지와 대중교통은 시내보다 제한적이므로 렌터카·택시·투어 이용 여부를 함께 봐야 합니다.",
      "bestFor": [
        "바다 휴식",
        "조용한 숙소",
        "사진 여행",
        "자전거",
        "타이루거 접근"
      ],
      "bookingTips": [
        "식당과 편의시설이 시내보다 적습니다. 늦은 체크인이나 저녁 식사 계획을 따로 확인하세요.",
        "저녁 식사와 이동 방식을 함께 확인하세요.",
        "숙소 주변의 소음과 택시 승하차 편의를 함께 보세요."
      ],
      "compareGood": "바다와 조용한 풍경이 여행의 핵심이라면 1박 또는 여유 일정에 좋습니다.",
      "compareCaution": "첫 화렌 여행에서 전체 숙박을 이 지역에만 잡으면 시내 먹거리와 기차 이동이 번거로울 수 있습니다.",
      "mismatchNote": "일정 성격이 다르다면 다른 화렌 지역도 함께 비교해보세요.",
      "links": [
        {
          "title": "치싱탄·신청 호텔 추천 TOP5",
          "url": "/post/qixingtan-xincheng-hotels/"
        },
        {
          "title": "화렌 숙소 위치 가이드",
          "url": "/destinations/hualien/hotel-guide/"
        }
      ],
      "hotels": [
        {
          "name": "호텔 베이뷰",
          "englishName": "Hotel Bayview",
          "tag": "바다 전망형",
          "location": "치싱탄 해변 주변",
          "reason": "치싱탄 바다를 가까이 두고 조용히 쉬고 싶은 일정에 잘 맞습니다.",
          "meta": [
            "치싱탄·신청",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "스타라이즈 레저 호텔",
          "englishName": "Starrise Leisure Hotel",
          "tag": "해변 휴식형",
          "location": "치싱탄 생활권",
          "reason": "해변 산책과 여유로운 숙박을 함께 원하는 여행자에게 좋습니다.",
          "meta": [
            "치싱탄·신청",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "치싱탄 하이완 B&B",
          "englishName": "Qixingtan Hai Wan B&B",
          "tag": "소규모 감성형",
          "location": "치싱탄 주변",
          "reason": "조용한 숙소와 바다 분위기를 가까이 두고 싶을 때 비교하기 좋습니다.",
          "meta": [
            "치싱탄·신청",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "리아 백패커 유스 호스텔",
          "englishName": "Lia Backpacker Youth Hostel",
          "tag": "실속 자연형",
          "location": "신청·치싱탄 생활권",
          "reason": "가볍게 머물며 자연 명소를 중심으로 움직이는 일정에 어울립니다.",
          "meta": [
            "치싱탄·신청",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "타로코 리코 호텔",
          "englishName": "Taroko Liiko Hotels",
          "tag": "신청 거점형",
          "location": "신청역 주변",
          "reason": "신청역과 타이루거·치싱탄 접근을 함께 보고 싶은 일정에 맞습니다.",
          "meta": [
            "치싱탄·신청",
            "화렌",
            "숙소"
          ],
          "url": "#"
        }
      ]
    },
    "taroko": {
      "name": "타이루거·톈샹",
      "slug": "taroko-tianxiang",
      "summary": "협곡과 산악 풍경을 가까이 두고 하루를 길게 보내며, 타이루거 여행에 더 깊게 집중하고 싶은 당신에게 잘 맞는 특별한 위치입니다.",
      "lead": "타이루거 일정이 여행의 핵심이라면 시내 숙소만 고집하지 않아도 됩니다. 다만 타이루거는 도로·탐방로 상황이 변동될 수 있으므로 숙소 예약 전 이동 가능 구간과 운영 여부를 확인해야 합니다.",
      "decision": "타이루거가 여행의 주목적이라면 특별하지만, 일반 시내 여행과는 다른 선택입니다.",
      "chips": [
        "타이루거",
        "자연",
        "1박 분리",
        "투어",
        "여유 일정"
      ],
      "regionSlug": "taroko-tianxiang",
      "label": "타이루거가 여행의 주목적이라면 특별하지만, 일반 시내 여행과는 다른 선택입니다.",
      "leadTitle": "타이루거 일정에 하루를 길게 쓰는 여행자를 위한 자연 거점",
      "leadText": "타이루거 일정이 여행의 핵심이라면 시내 숙소만 고집하지 않아도 됩니다. 다만 타이루거는 도로·탐방로 상황이 변동될 수 있으므로 숙소 예약 전 이동 가능 구간과 운영 여부를 확인해야 합니다.",
      "bestFor": [
        "타이루거 중심 여행",
        "자연 풍경",
        "1박 분리",
        "렌터카·투어",
        "여유 일정"
      ],
      "bookingTips": [
        "도로·탐방로·버스 운행은 수시로 달라질 수 있으니 예약 전과 출발 당일 공식 공지를 확인하세요.",
        "식사·교통·운영 상황이 시내보다 제한적입니다. 숙소 자체 식사와 이동 수단, 탐방 가능 구간을 함께 확인하세요.",
        "저녁 식사와 이동 방식을 함께 확인하세요.",
        "숙소 주변의 소음과 택시 승하차 편의를 함께 보세요."
      ],
      "compareGood": "타이루거가 여행의 주목적이라면 특별하지만, 일반 시내 여행과는 다른 선택입니다.",
      "compareCaution": "야시장·구시가지 관광까지 함께 즐기는 첫 여행이라면 화렌역이나 동대문 야시장 쪽이 더 편합니다.",
      "mismatchNote": "일정 성격이 다르다면 다른 화렌 지역도 함께 비교해보세요.",
      "links": [
        {
          "title": "타이루거·톈샹 호텔 추천 TOP5",
          "url": "/post/taroko-tianxiang-hotels/"
        },
        {
          "title": "화렌 숙소 위치 가이드",
          "url": "/destinations/hualien/hotel-guide/"
        }
      ],
      "hotels": [
        {
          "name": "실크스 플레이스 타로코",
          "englishName": "Silks Place Taroko",
          "tag": "협곡 리조트형",
          "location": "톈샹 주변",
          "reason": "타이루거 안에서 숙소 체류와 자연 풍경을 함께 즐기고 싶은 일정에 어울립니다.",
          "meta": [
            "타이루거·톈샹",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "타로코 빌리지 호텔",
          "englishName": "Taroko Village Hotel",
          "tag": "자연 체험형",
          "location": "타이루거 지역",
          "reason": "자연과 원주민 문화 분위기를 함께 보고 싶은 여행에 비교하기 좋습니다.",
          "meta": [
            "타이루거·톈샹",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "리우 호텔 타로코",
          "englishName": "Liwu Hotel Taroko",
          "tag": "실속 거점형",
          "location": "타이루거 입구권",
          "reason": "타이루거 입구와 이동 편의를 함께 보고 싶은 일정에 맞습니다.",
          "meta": [
            "타이루거·톈샹",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "타이루거 톈샹 유스 액티비티 센터",
          "englishName": "Taroko Tienhsiang Youth Activity Center",
          "tag": "산악 거점형",
          "location": "톈샹 지역",
          "reason": "협곡 안쪽에 머물며 자연 일정을 크게 잡고 싶은 여행자에게 어울립니다.",
          "meta": [
            "타이루거·톈샹",
            "화렌",
            "숙소"
          ],
          "url": "#"
        },
        {
          "name": "화렌 타로코 마운틴 드림 B&B",
          "englishName": "Hualien Taroko Mountain Dream B&B",
          "tag": "소규모 자연형",
          "location": "타이루거 주변",
          "reason": "조용한 자연 숙소를 선호하는 커플·소규모 여행에 비교하기 좋습니다.",
          "meta": [
            "타이루거·톈샹",
            "화렌",
            "숙소"
          ],
          "url": "#"
        }
      ]
    }
  },
  "questions": [
    {
      "title": "화렌에 도착하는 방식은 무엇에 가깝나요?",
      "help": "첫날 짐을 들고 움직이는 방식이 숙소 위치에 큰 영향을 줍니다.",
      "options": [
        {
          "title": "기차로 도착해서 바로 체크인하고 싶어요",
          "scores": {
            "station": 6,
            "dongdamen": 2
          }
        },
        {
          "title": "저녁에 바로 야시장과 식당을 보고 싶어요",
          "scores": {
            "station": 1,
            "dongdamen": 6
          }
        },
        {
          "title": "치싱탄이나 신청 쪽 자연 일정이 중요해요",
          "scores": {
            "station": 1,
            "qixingtan": 6,
            "taroko": 2
          }
        },
        {
          "title": "타이루거 일정이 여행의 핵심이에요",
          "scores": {
            "station": 2,
            "qixingtan": 3,
            "taroko": 6
          }
        }
      ]
    },
    {
      "title": "이번 화렌 여행에서 가장 중요한 장면은 무엇인가요?",
      "help": "여행의 중심 장면을 고르면 추천 지역이 더 정확해집니다.",
      "options": [
        {
          "title": "기차역에서 이동이 쉬운 첫 여행",
          "scores": {
            "station": 5,
            "dongdamen": 2
          }
        },
        {
          "title": "동대문 야시장과 시내 먹거리",
          "scores": {
            "dongdamen": 6
          }
        },
        {
          "title": "조용한 호텔과 가족 휴식",
          "scores": {
            "station": 2,
            "meilun": 6
          }
        },
        {
          "title": "바다와 사진, 여유로운 산책",
          "scores": {
            "meilun": 2,
            "qixingtan": 6
          }
        },
        {
          "title": "협곡과 산악 자연 풍경",
          "scores": {
            "qixingtan": 2,
            "taroko": 7
          }
        }
      ]
    },
    {
      "title": "밤에는 어떤 동선이 편할까요?",
      "help": "화렌은 밤 복귀 동선에 따라 숙소 만족도가 달라집니다.",
      "options": [
        {
          "title": "야시장 가까이에서 저녁을 해결하고 싶어요",
          "scores": {
            "dongdamen": 6
          }
        },
        {
          "title": "시내 카페와 골목을 천천히 걷고 싶어요",
          "scores": {
            "dongdamen": 6
          }
        },
        {
          "title": "숙소에서 조용히 쉬는 시간이 중요해요",
          "scores": {
            "meilun": 5,
            "qixingtan": 4,
            "taroko": 2
          }
        },
        {
          "title": "다음 날 자연 일정 때문에 일찍 쉬고 싶어요",
          "scores": {
            "station": 4,
            "qixingtan": 3,
            "taroko": 3
          }
        }
      ]
    },
    {
      "title": "동행자는 누구인가요?",
      "help": "동행자에 따라 체크해야 할 숙소 조건이 달라집니다.",
      "options": [
        {
          "title": "혼자 또는 친구와 가볍게 움직여요",
          "scores": {
            "station": 4,
            "dongdamen": 3
          }
        },
        {
          "title": "커플 여행이라 분위기도 중요해요",
          "scores": {
            "dongdamen": 4,
            "qixingtan": 3
          }
        },
        {
          "title": "부모님이나 아이와 함께해요",
          "scores": {
            "station": 3,
            "meilun": 6,
            "qixingtan": 2
          }
        },
        {
          "title": "렌터카나 택시를 적극적으로 쓸 예정이에요",
          "scores": {
            "meilun": 3,
            "qixingtan": 4,
            "taroko": 4
          }
        }
      ]
    },
    {
      "title": "숙소 주변 분위기는 어떤 쪽이 좋나요?",
      "help": "같은 화렌이라도 숙소 주변 분위기는 꽤 다릅니다.",
      "options": [
        {
          "title": "역 주변처럼 이동이 쉬운 곳",
          "scores": {
            "station": 6,
            "dongdamen": 1
          }
        },
        {
          "title": "먹거리와 상점이 많은 시내",
          "scores": {
            "dongdamen": 5
          }
        },
        {
          "title": "차분한 호텔 주변 환경",
          "scores": {
            "meilun": 6,
            "qixingtan": 2
          }
        },
        {
          "title": "바다와 자연 풍경이 가까운 곳",
          "scores": {
            "qixingtan": 6,
            "taroko": 3
          }
        },
        {
          "title": "아예 자연 속에 머무는 느낌",
          "scores": {
            "qixingtan": 2,
            "taroko": 7
          }
        }
      ]
    },
    {
      "title": "예산과 호텔 컨디션은 어떻게 보고 있나요?",
      "help": "숙박비만 보지 말고 이동비와 식사 선택지도 함께 생각해보세요.",
      "options": [
        {
          "title": "이동비까지 아끼는 실속형이 좋아요",
          "scores": {
            "station": 5,
            "dongdamen": 4
          }
        },
        {
          "title": "야시장 가까운 가성비가 좋아요",
          "scores": {
            "dongdamen": 5
          }
        },
        {
          "title": "숙소 컨디션과 조용함에 더 투자해도 돼요",
          "scores": {
            "meilun": 5,
            "qixingtan": 3
          }
        },
        {
          "title": "특별한 자연 숙소라면 예산을 더 볼 수 있어요",
          "scores": {
            "qixingtan": 3,
            "taroko": 6
          }
        }
      ]
    },
    {
      "title": "가장 피하고 싶은 불편은 무엇인가요?",
      "help": "피하고 싶은 불편을 기준으로 마지막 추천을 보정합니다.",
      "options": [
        {
          "title": "짐 들고 오래 걷는 것",
          "scores": {
            "station": 6,
            "meilun": 2
          }
        },
        {
          "title": "밤 소음과 혼잡한 분위기",
          "scores": {
            "meilun": 5,
            "qixingtan": 4,
            "taroko": 2
          }
        },
        {
          "title": "저녁 식사 선택지가 부족한 것",
          "scores": {
            "station": 2,
            "dongdamen": 5
          }
        },
        {
          "title": "자연 명소까지 이동이 긴 것",
          "scores": {
            "qixingtan": 4,
            "taroko": 5
          }
        }
      ]
    }
  ]
};

const areaResultBadges = {
  "station": "타이루거 투어와 시내 이동을 준비하기 좋은 중심",
  "dongdamen": "야시장과 구시가지 산책이 가까운 중심",
  "meilun": "조용한 항구 분위기에서 여유롭게 쉬기 좋은 곳",
  "qixingtan": "자갈 해변과 태평양 풍경을 가까이 보는 곳",
  "taroko": "통제 확인이 필요한 타이루거 자연 거점"
};

const hotelAccessPresets = {
  "station": {
    "station": "화렌역·투어 픽업 접근",
    "airport": "화렌공항 차량 약 10~20분"
  },
  "dongdamen": {
    "station": "동대문야시장·구시가지 도보권",
    "airport": "화렌공항 차량 약 15~25분"
  },
  "meilun": {
    "station": "메이룬·항구 산책권",
    "airport": "화렌공항 차량 약 10~20분"
  },
  "qixingtan": {
    "station": "치싱탄·신청 해변권",
    "airport": "화렌공항 차량 약 10~20분"
  },
  "taroko": {
    "station": "타이루거·톈샹 접근",
    "airport": "화렌공항/화렌역 차량 이동 확인"
  }
};

function normalizeAreaToken(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[\s·ㆍ・&-]+/g, "");
}

function getAreaKey(area) {
  if (!area) return "";
  if (area.key && Object.prototype.hasOwnProperty.call(cityConfig.areas, area.key)) return area.key;

  return Object.keys(cityConfig.areas).find((key) => {
    const candidate = cityConfig.areas[key];
    return candidate === area || candidate.name === area.name || candidate.regionSlug === area.regionSlug;
  }) || "";
}

function getAreaDisplayName(area) {
  const displayName = String(area?.displayName || area?.name || "")
    .replace(/\s*&\s*/g, "·")
    .replace(/\s*-\s*/g, "·")
    .trim();
  return displayName || "추천 지역";
}

function uniqueItems(items) {
  return [...new Set((items || []).map((item) => String(item || "").trim()).filter(Boolean))];
}

Object.entries(cityConfig.areas || {}).forEach(([key, area]) => {
  area.key = area.key || key;
  area.displayName = getAreaDisplayName(area);
  area.resultBadge = area.resultBadge || areaResultBadges[key] || "이번 여행에 어울리는 숙소 위치";
  area.destinationLabel = area.destinationLabel || `${area.resultBadge}, ${area.displayName}`;
  area.bestFor = uniqueItems(area.bestFor || area.chips || ["일정이 짧은 여행", "위치 중심 숙소"]);
  area.notFor = uniqueItems(area.notFor || ["숙소에서만 오래 쉬는 일정", "이동보다 리조트 시설이 더 중요한 여행"]);
  area.bookingTips = uniqueItems(area.bookingTips || [
    "예약 전 최근 후기에서 소음, 청결, 주변 공사 언급을 확인하세요.",
    "공항·투어 픽업이 중요하면 호텔명보다 실제 픽업 가능 지역을 확인하세요.",
    "택시나 그랩 이동이 많은 도시라면 예상 이동비도 함께 계산하세요."
  ]);
  area.stayRange = uniqueItems(area.stayRange || [
    `${area.displayName} 안에서도 매일 갈 장소와 가장 가까운 위치`,
    "식사·편의점·마사지 등 저녁 이후 편의시설이 가까운 큰길 주변",
    "공항 이동이나 투어 픽업이 필요한 날의 동선이 단순한 숙소"
  ]);
  area.avoidRange = uniqueItems(area.avoidRange || [
    "지도상 가까워 보여도 실제 도보 길이 불편한 안쪽 골목",
    "저녁 이후 소음 후기가 반복되는 저층 객실",
    "매일 이동할 목적지와 반대 방향으로 떨어진 숙소"
  ]);
});
