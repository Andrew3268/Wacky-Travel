const $ = (id) => document.getElementById(id);

function slugify(str) {
  return String(str || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9\-가-힣]/g, "")
    .replace(/\-+/g, "-");
}

function parseTags(raw) {
  return String(raw || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function parseKeywords(raw) {
  return String(raw || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .filter((item, index, arr) => arr.indexOf(item) === index);
}

const HOTEL_HERO_BADGE_OPTIONS = Object.freeze([
  "훌륭한 위치",
  "뚜벅이 최적",
  "깔끔한 위생",
  "친절한 서비스",
  "쇼핑·맛집 중심",
  "높은 만족도",
  "공항 이동 편리",
  "전망 좋은 뷰",
  "넓고 쾌적한 객실",
  "조식 맛집",
  "아이동반 최적",
  "커플 여행 최적",
  "호캉스 최적",
]);

function normalizeHotelHeroBadges(value) {
  const source = Array.isArray(value)
    ? value
    : String(value || "").split(/[,.，、|]/);
  const selected = new Set(source.map((item) => String(item || "").trim()).filter(Boolean));
  return HOTEL_HERO_BADGE_OPTIONS.filter((item) => selected.has(item));
}

function getSelectedHotelHeroBadges() {
  const selected = new Set(
    Array.from(document.querySelectorAll('input[name="heroHotelBadge"]:checked'))
      .map((input) => String(input.value || "").trim())
      .filter(Boolean)
  );
  return HOTEL_HERO_BADGE_OPTIONS.filter((item) => selected.has(item));
}

function applySelectedHotelHeroBadges(value) {
  const selected = new Set(normalizeHotelHeroBadges(value));
  document.querySelectorAll('input[name="heroHotelBadge"]').forEach((input) => {
    input.checked = selected.has(String(input.value || "").trim());
  });
}


const HOTEL_PICK_LABELS = Object.freeze({
  editor: "에디터픽",
  value: "가성비픽"
});

function normalizeHotelPickState(hero = {}) {
  const rawType = String(hero.pick_type || "").trim().toLowerCase();
  const rawText = String(hero.pick_text || "").replace(/\s+/g, " ").trim().slice(0, 30);
  const legacyLabel = String(hero.price_level || hero.value_badge || "").replace(/\s+/g, " ").trim().slice(0, 30);

  if (rawType === "editor") return { type: "editor", text: "", label: HOTEL_PICK_LABELS.editor };
  if (rawType === "value") return { type: "value", text: "", label: HOTEL_PICK_LABELS.value };
  if (rawType === "custom") return { type: "custom", text: rawText, label: rawText };

  if (legacyLabel === "에디터픽") return { type: "editor", text: "", label: HOTEL_PICK_LABELS.editor };
  if (["가성비", "가성비픽"].includes(legacyLabel)) return { type: "value", text: "", label: HOTEL_PICK_LABELS.value };
  if (legacyLabel) return { type: "custom", text: legacyLabel, label: legacyLabel };
  return { type: "", text: "", label: "" };
}

function getSelectedHotelPickType() {
  return String(document.querySelector('input[name="heroHotelPick"]:checked')?.value || "").trim();
}

function collectHotelPickFormData() {
  const type = getSelectedHotelPickType();
  const text = type === "custom"
    ? String($("heroHotelPickCustomText")?.value || "").replace(/\s+/g, " ").trim().slice(0, 30)
    : "";
  return normalizeHotelPickState({ pick_type: type, pick_text: text });
}

function syncHotelPickCustomField() {
  const customSelected = getSelectedHotelPickType() === "custom";
  const wrap = $("heroHotelPickCustomWrap");
  const input = $("heroHotelPickCustomText");
  if (wrap) {
    wrap.hidden = !customSelected;
    wrap.setAttribute("aria-hidden", customSelected ? "false" : "true");
  }
  if (input) {
    input.disabled = !customSelected;
    input.required = customSelected;
  }
}

function applyHotelPickFormData(hero = {}) {
  const state = normalizeHotelPickState(hero);
  document.querySelectorAll('input[name="heroHotelPick"]').forEach((input) => {
    input.checked = String(input.value || "") === state.type;
  });
  if ($("heroHotelPickCustomText")) $("heroHotelPickCustomText").value = state.text || "";
  syncHotelPickCustomField();
}

function bindHotelPickControls() {
  document.querySelectorAll('input[name="heroHotelPick"]').forEach((input) => {
    input.addEventListener("change", () => {
      if (input.checked) {
        document.querySelectorAll('input[name="heroHotelPick"]').forEach((other) => {
          if (other !== input) other.checked = false;
        });
      }
      syncHotelPickCustomField();
      handleRealtimeChange();
    });
  });
  $("heroHotelPickCustomText")?.addEventListener("input", handleRealtimeChange);
  syncHotelPickCustomField();
}

function normalizeHeroLocationType(value = "") {
  const raw = String(value || "").replace(/\s+/g, " ").trim();
  const aliases = {
    "시내중심": "시내 중심",
    "도심": "시내 중심",
    "도심권": "시내 중심",
    "중심부": "시내 중심",
    "중심가": "중심가 인근",
    "관광지근처": "관광지 인근",
    "관광지 주변": "관광지 인근",
    "해변근처": "해변 근처",
    "비치 근처": "해변 근처",
    "공항근처": "공항 근처",
    "역 근처": "역세권",
    "역 주변": "역세권",
    "외각": "외곽"
  };
  return aliases[raw] || raw;
}

function setSelectValuePreservingOption(selectEl, value = "") {
  if (!selectEl) return;
  const normalized = normalizeHeroLocationType(value);
  if (!normalized) {
    selectEl.value = "";
    return;
  }
  const exists = Array.from(selectEl.options || []).some((option) => option.value === normalized);
  if (!exists) {
    const option = document.createElement("option");
    option.value = normalized;
    option.textContent = normalized;
    selectEl.appendChild(option);
  }
  selectEl.value = normalized;
}

function isHeroValueBadgeChecked(value = "") {
  const raw = String(value ?? "").trim().toLowerCase();
  return value === true || raw === "1" || raw === "true" || raw === "yes" || raw.includes("가성비");
}

function formatHeroStarRating(value = "") {
  const raw = String(value || "").trim();
  if (!raw) return "";
  if (/성급$/.test(raw)) return raw;
  return `${raw}성급`;
}

function normalizeHeroGuestRating(value = "") {
  const raw = String(value || "").trim().replace(/^평점\s*/i, "");
  const normalized = raw.match(/^(6(?:\.5)?|7(?:\.5)?|8(?:\.5)?|9(?:\.5)?)\+?$/)?.[1];
  return normalized ? `${normalized}+` : "";
}

function formatHeroGuestRating(value = "") {
  const normalized = normalizeHeroGuestRating(value);
  return normalized;
}

function collectCoverImageFormData(options = {}) {
  const utils = window.CoverImageSourceUtils;
  if (!utils) {
    const image = sanitizeImageUrlValue($("cover_image")?.value || "");
    return { ok: true, source: "r2", image, link: "", srcset: "", alt: $("cover_image_alt")?.value.trim() || "" };
  }
  return utils.collect(options);
}

function renderPreviewCoverImage(coverData, altText = "") {
  if (!coverData?.image) return "";
  const alt = escapeHtml(altText || "대표 이미지");
  if (coverData.source === "agoda") {
    const image = `<img class="preview-cover" src="${escapeHtml(coverData.image)}"${coverData.srcset ? ` srcset="${escapeHtml(coverData.srcset)}"` : ""} alt="${alt}" loading="lazy" decoding="async">`;
    return coverData.link
      ? `<a class="preview-cover-link" href="${escapeHtml(coverData.link)}" target="_blank" rel="sponsored noopener noreferrer">${image}</a>`
      : image;
  }
  return `<img class="preview-cover" ${renderOptimizedImageAttrs(coverData.image, { widths: [640, 960, 1200, 1600], sizes: "(max-width: 900px) 100vw, 960px", fallbackWidth: 960, fit: "cover", quality: 85 })} alt="${alt}" loading="lazy">`;
}


const HOTEL_KEY_POINT_OPTIONS = Object.freeze([
  { key: "attractions", label: "명소 접근성", inputId: "heroKeyPointAttractions" },
  { key: "transport", label: "대중교통", inputId: "heroKeyPointTransport" },
  { key: "airport", label: "공항 접근성", inputId: "heroKeyPointAirport" },
  { key: "dining_shopping", label: "맛집 및 쇼핑", inputId: "heroKeyPointDiningShopping" },
  { key: "signature", label: "호텔 시그니처", inputId: "heroKeyPointSignature" }
]);

function collectHotelKeyPoints() {
  return HOTEL_KEY_POINT_OPTIONS.map((item) => {
    const toggle = document.querySelector(`[data-hotel-key-point-toggle="${item.key}"]`);
    const text = $(item.inputId)?.value.trim() || "";
    return toggle?.checked && text ? { key: item.key, label: item.label, text } : null;
  }).filter(Boolean);
}

function normalizeHotelKeyPoints(value = []) {
  let source = value;
  if (!Array.isArray(source)) {
    try { source = JSON.parse(String(source || "[]")); } catch (_) { source = []; }
  }
  const byKey = new Map((Array.isArray(source) ? source : []).map((item) => [String(item?.key || "").trim(), String(item?.text || "").trim()]));
  return HOTEL_KEY_POINT_OPTIONS.map((item) => ({ ...item, text: byKey.get(item.key) || "" })).filter((item) => item.text);
}
function renderHotelKeyPointIcon(key = "") {
  switch (String(key || "").trim()) {
    case "attractions":
      return `<svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M16 28.4S25 20.2 25 11.8a9 9 0 1 0-18 0c0 8.4 9 16.6 9 16.6Z"></path><circle cx="16" cy="11.8" r="3.2"></circle></svg>`;
    case "transport":
      return `<svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M10 4.5h12a4.5 4.5 0 0 1 4.5 4.5v10a6.5 6.5 0 0 1-6.5 6.5h-8A6.5 6.5 0 0 1 5.5 19V9A4.5 4.5 0 0 1 10 4.5Z"></path><path d="M6 11.3h20M6 18.5h20M16 5v6.3"></path><circle cx="11" cy="21.8" r="1.55" fill="currentColor" stroke="none"></circle><circle cx="21" cy="21.8" r="1.55" fill="currentColor" stroke="none"></circle><path d="m11.5 25.3-4.2 4.2M20.5 25.3l4.2 4.2"></path></svg>`;
    case "airport":
      return `<svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M28 15.2 18.5 11V5.8a2.5 2.5 0 0 0-5 0V11L4 15.2v2.6l9.5-1.8v6.2l-3.2 2.1v2l5.7-1.3 5.7 1.3v-2l-3.2-2.1V16l9.5 1.8v-2.6Z"></path></svg>`;
    case "dining_shopping":
      return `<svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M7.2 11h17.6l1.45 14.2a2.55 2.55 0 0 1-2.54 2.8H8.29a2.55 2.55 0 0 1-2.54-2.8L7.2 11Z"></path><path d="M11.2 14V9.2a4.8 4.8 0 0 1 9.6 0V14"></path></svg>`;
    case "signature":
      return `<svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M16 4.2c.9 5.3 3.3 7.7 8.6 8.6-5.3.9-7.7 3.3-8.6 8.6-.9-5.3-3.3-7.7-8.6-8.6 5.3-.9 7.7-3.3 8.6-8.6Z"></path><path d="M25.2 3.8c.35 2.15 1.35 3.15 3.5 3.5-2.15.35-3.15 1.35-3.5 3.5-.35-2.15-1.35-3.15-3.5-3.5 2.15-.35 3.15-1.35 3.5-3.5Z"></path><path d="M7.2 21.2c.45 2.7 1.7 3.95 4.4 4.4-2.7.45-3.95 1.7-4.4 4.4-.45-2.7-1.7-3.95-4.4-4.4 2.7-.45 3.95-1.7 4.4-4.4Z"></path></svg>`;
    default:
      return `<svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><circle cx="16" cy="16" r="11"></circle></svg>`;
  }
}

function orderHotelKeyPointsForDisplay(items = []) {
  const order = new Map([
    ["attractions", 0],
    ["dining_shopping", 1],
    ["transport", 2],
    ["airport", 3],
    ["signature", 4]
  ]);
  return [...items].sort((a, b) => (order.get(a?.key) ?? 99) - (order.get(b?.key) ?? 99));
}


function syncHotelKeyPointInputVisibility(toggle) {
  if (!toggle) return;
  const key = String(toggle.dataset.hotelKeyPointToggle || toggle.value || "").trim();
  const wrap = document.querySelector(`[data-hotel-key-point-input="${key}"]`);
  if (!wrap) return;
  wrap.hidden = !toggle.checked;
  wrap.setAttribute("aria-hidden", toggle.checked ? "false" : "true");
}

function applyHotelKeyPoints(value = []) {
  const normalized = normalizeHotelKeyPoints(value);
  const byKey = new Map(normalized.map((item) => [item.key, item.text]));
  HOTEL_KEY_POINT_OPTIONS.forEach((item) => {
    const toggle = document.querySelector(`[data-hotel-key-point-toggle="${item.key}"]`);
    const input = $(item.inputId);
    const text = byKey.get(item.key) || "";
    if (toggle) toggle.checked = Boolean(text);
    if (input) input.value = text;
    syncHotelKeyPointInputVisibility(toggle);
  });
}

function syncHotelKeyPointsCardVisibility() {
  const shouldShow = isHotelIntroContentSelected();
  document.querySelectorAll(".editor-hotel-key-points-card").forEach((card) => {
    card.hidden = !shouldShow;
    card.setAttribute("aria-hidden", shouldShow ? "false" : "true");
  });
}

function initHotelKeyPointsEditor() {
  document.querySelectorAll("[data-hotel-key-point-toggle]").forEach((toggle) => {
    syncHotelKeyPointInputVisibility(toggle);
    toggle.addEventListener("change", () => {
      syncHotelKeyPointInputVisibility(toggle);
      handleRealtimeChange();
      if (toggle.checked) {
        const key = String(toggle.dataset.hotelKeyPointToggle || "").trim();
        const item = HOTEL_KEY_POINT_OPTIONS.find((option) => option.key === key);
        if (item) $(item.inputId)?.focus();
      }
    });
  });
  syncHotelKeyPointsCardVisibility();
  $("content_type")?.addEventListener("change", syncHotelKeyPointsCardVisibility);
}

function collectHotelHeroFormData() {
  return {
    name: $("heroHotelName")?.value.trim() || "",
    name_en: $("heroHotelNameEn")?.value.trim() || "",
    area: normalizeHeroLocationType($("heroHotelLocationType")?.value || ""),
    star_rating: $("heroHotelStarRating")?.value.trim() || "",
    guest_rating: normalizeHeroGuestRating($("heroHotelGuestRating")?.value || ""),
    pick_type: collectHotelPickFormData().type,
    pick_text: collectHotelPickFormData().text,
    price_level: "",
    badges: getSelectedHotelHeroBadges(),
    key_points: collectHotelKeyPoints(),
    price_url: $("heroHotelPriceUrl")?.value.trim() || ""
  };
}

function stripMarkdown(md) {
  return stripStyleHotelTokenLines(String(md || ""))
    .replace(/^<!--\s*[\s\S]*?\s*-->\s*$/gm, "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^\s{0,3}>\s?/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "")
    .replace(/[*_~>#|]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function shouldShowInarticleAdsInEditor() {
  const el = $("enable_inarticle_ads");
  return !!(el && el.checked);
}


const DEFAULT_TRAVEL_CONTENT_TYPES = [
  { slug: "top5_series", label: "여행 스타일별 호텔 추천", description: "여행 스타일에 맞춰 호텔을 비교해볼 수 있는 추천 콘텐츠" },
  { slug: "hotel_intro", label: "추천 호텔 리뷰", description: "호텔 하나를 차분히 살펴보는 소개 콘텐츠" },
  { slug: "travel_tip", label: "여행 꿀팁", description: "여행 준비와 이동에 도움이 되는 작은 팁" }
];

const TRAVEL_CONTENT_TYPE_ALIASES = {
  guide: "travel_tip",
  checklist: "travel_tip",
  tip: "travel_tip",
  tips: "travel_tip",
  traveltip: "travel_tip",
  traveltips: "travel_tip",
  "travel-tip": "travel_tip",
  "travel tips": "travel_tip",
  "여행팁": "travel_tip",
  "여행 팁": "travel_tip",
  "여행 꿀팁": "travel_tip",
  "여행-tip": "travel_tip",
  "여행 tip": "travel_tip",
  "여행 tips": "travel_tip",
  "여행준비": "travel_tip",
  "여행 준비": "travel_tip",
  "여행이 쉬워지는 작은 팁": "travel_tip",
  hotel_roundup: "top5_series",
  hotel_review: "hotel_intro",
  "hotel-roundup": "top5_series",
  "hotel review": "hotel_intro",
  "top5": "top5_series",
  "top5-series": "top5_series",
  "top5 시리즈": "top5_series",
  "TOP5 시리즈": "top5_series",
  "TOP 5": "top5_series",
  "여행 스타일별 호텔 추천": "top5_series",
  "개별호텔소개": "hotel_intro",
  "개별 호텔 소개": "hotel_intro",
  "개별 호텔": "hotel_intro",
  "추천 호텔 리뷰": "hotel_intro"
};

let travelContentTypeItems = [...DEFAULT_TRAVEL_CONTENT_TYPES];
let countryItems = [];
let destinationItems = [];
let regionItems = [];
let recommendationCategoryItems = [];

function normalizeContentType(value) {
  const raw = String(value || "").replace(/\s+/g, " ").trim();
  if (!raw) return "";
  const lower = raw.toLowerCase();
  const compact = lower.replace(/[\s_-]+/g, "");
  return TRAVEL_CONTENT_TYPE_ALIASES[raw]
    || TRAVEL_CONTENT_TYPE_ALIASES[lower]
    || TRAVEL_CONTENT_TYPE_ALIASES[compact]
    || raw;
}

function labelContentType(value) {
  const normalized = normalizeContentType(value);
  const found = travelContentTypeItems.find((item) => normalizeContentType(item.slug || item.value || item.label || "") === normalized);
  if (found) return found.label || found.name || normalized;
  const fallback = DEFAULT_TRAVEL_CONTENT_TYPES.find((item) => item.slug === normalized);
  return fallback?.label || normalized;
}

function isHotelIntroContentSelected() {
  return normalizeContentType($("content_type")?.value || "") === "hotel_intro";
}

function isHotelRecommendationContentSelected() {
  return normalizeContentType($("content_type")?.value || "") === "top5_series";
}

function syncHotelHeroCardVisibility() {
  const shouldShow = isHotelIntroContentSelected();
  document.querySelectorAll(".editor-hotel-hero-card").forEach((card) => {
    card.hidden = !shouldShow;
    card.setAttribute("aria-hidden", shouldShow ? "false" : "true");
  });
}

function syncRecommendationCategoryCardVisibility() {
  const shouldShow = isHotelRecommendationContentSelected();
  document.querySelectorAll(".editor-recommendation-category-card").forEach((card) => {
    card.hidden = !shouldShow;
    card.setAttribute("aria-hidden", shouldShow ? "false" : "true");
  });
}

function normalizeCountryName(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function countryToSlug(value) {
  const raw = normalizeCountryName(value);
  if (!raw) return "";
  const alias = { 베트남: "vietnam", 일본: "japan", 태국: "thailand", 필리핀: "philippines", 대만: "taiwan", 한국: "korea", 대한민국: "korea" }[raw];
  if (alias) return alias;
  return raw
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9가-힣]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

function getCountrySlugFromDestination(destination) {
  return String(destination?.country_slug || destination?.countrySlug || "").trim() || countryToSlug(destination?.country || "");
}

function getCountryNameBySlug(slug) {
  const found = countryItems.find((item) => String(item.slug || "") === String(slug || ""));
  return found?.name || normalizeCountryName(slug);
}

function getDestinationLabel(destination) {
  if (!destination) return "";
  const city = String(destination.city || destination.name || "").trim();
  const name = String(destination.name || "").trim();
  return city && name && city !== name ? `${name} (${city})` : (name || city || destination.slug || "");
}

function getSelectedDestination() {
  const slug = $("destination_slug")?.value || "";
  return destinationItems.find((item) => String(item.slug || "") === slug) || null;
}

function getRegionDestinationSlug(region) {
  return String(region?.destination_slug || region?.destinationSlug || "").trim();
}

function getRegionCountrySlug(region) {
  return String(region?.country_slug || region?.countrySlug || "").trim();
}

function getRegionLabel(region) {
  return String(region?.name || region?.slug || "").trim();
}

function getRecommendationCategoryLabel(category) {
  return String(category?.name || category?.slug || "").trim();
}

function getRecommendationCategoryDescription(category) {
  return String(category?.description || "").trim();
}

function getRecommendationCategoryDestinationSlug(category) {
  return String(category?.destination_slug || category?.destinationSlug || "").trim();
}

function getSelectedRegion() {
  const slug = $("region_slug")?.value || "";
  const destinationSlug = $("destination_slug")?.value || "";
  return regionItems.find((item) => String(item.slug || "") === slug && (!destinationSlug || getRegionDestinationSlug(item) === destinationSlug)) || null;
}

function getSelectedRecommendationCategory() {
  const slug = $("recommendationCategorySlug")?.value || "";
  return recommendationCategoryItems.find((item) => String(item.slug || "") === slug) || null;
}

function renderContentTypeOptions(selectedValue = "") {
  const selectEl = $("content_type");
  if (!selectEl) return;
  const normalized = normalizeContentType(selectedValue || selectEl.value);
  const activeItems = travelContentTypeItems.filter((item) => Number(item.is_active ?? 1) !== 0);
  const selectedExists = activeItems.some((item) => normalizeContentType(item.slug || item.value || item.label || "") === normalized);
  const selectedItem = travelContentTypeItems.find((item) => normalizeContentType(item.slug || item.value || item.label || "") === normalized);
  const items = selectedItem && !selectedExists ? [selectedItem, ...activeItems] : activeItems;
  selectEl.innerHTML = [
    '<option value="">글 종류 선택</option>',
    ...items.map((item) => `<option value="${escapeHtml(normalizeContentType(item.slug || item.value || item.label || ""))}">${escapeHtml(item.label || item.name || item.slug || "")}</option>`)
  ].join("");
  selectEl.value = normalized || "";
  syncHotelHeroCardVisibility();
  syncHotelKeyPointsCardVisibility();
  syncHotelCurationCardVisibility();
  syncRecommendationCategoryCardVisibility();
  window.StyleHotelEditor?.syncVisibility(normalized || "");
}

function renderCountryOptions(selectedValue = "") {
  const selectEl = $("country");
  if (!selectEl) return;
  const current = String(selectedValue || selectEl.value || "").trim();
  const activeCountries = countryItems.filter((item) => Number(item.is_active ?? 1) !== 0);
  const selectedExists = activeCountries.some((item) => String(item.slug || "") === current);
  const selectedCountry = countryItems.find((item) => String(item.slug || "") === current);
  const items = selectedCountry && !selectedExists ? [selectedCountry, ...activeCountries] : activeCountries;
  selectEl.innerHTML = [
    '<option value="">나라 선택</option>',
    ...items.map((country) => `<option value="${escapeHtml(country.slug || "")}">${escapeHtml(country.name || country.slug || "")}</option>`)
  ].join("");
  selectEl.value = current || "";
}

function renderDestinationOptions(selectedValue = "") {
  const selectEl = $("destination_slug");
  if (!selectEl) return;
  const selectedSlug = String(selectedValue || selectEl.value || "").trim();
  const selectedCountrySlug = String($("country")?.value || "").trim();
  const selectedDestination = destinationItems.find((item) => String(item.slug || "") === selectedSlug) || null;
  const filtered = destinationItems
    .filter((item) => Number(item.is_active ?? 1) !== 0)
    .filter((item) => !selectedCountrySlug || getCountrySlugFromDestination(item) === selectedCountrySlug)
    .sort((a, b) => getDestinationLabel(a).localeCompare(getDestinationLabel(b), "ko"));

  if (selectedDestination && !filtered.some((item) => String(item.slug || "") === selectedSlug)) {
    filtered.unshift(selectedDestination);
  }

  selectEl.innerHTML = [
    '<option value="">도시 선택</option>',
    ...filtered.map((item) => `<option value="${escapeHtml(item.slug || "")}">${escapeHtml(getDestinationLabel(item))}</option>`)
  ].join("");
  selectEl.value = selectedSlug && filtered.some((item) => String(item.slug || "") === selectedSlug) ? selectedSlug : "";
}

function renderRegionOptions(selectedValue = "") {
  const selectEl = $("region_slug");
  if (!selectEl) return;
  const selectedSlug = String(selectedValue || selectEl.value || "").trim();
  const selectedCountrySlug = String($("country")?.value || "").trim();
  const selectedDestinationSlug = String($("destination_slug")?.value || "").trim();
  const selectedRegion = regionItems.find((item) => String(item.slug || "") === selectedSlug && (!selectedDestinationSlug || getRegionDestinationSlug(item) === selectedDestinationSlug)) || null;
  const filtered = regionItems
    .filter((item) => Number(item.is_active ?? 1) !== 0)
    .filter((item) => !selectedCountrySlug || !getRegionCountrySlug(item) || getRegionCountrySlug(item) === selectedCountrySlug)
    .filter((item) => !selectedDestinationSlug || getRegionDestinationSlug(item) === selectedDestinationSlug)
    .sort((a, b) => getRegionLabel(a).localeCompare(getRegionLabel(b), "ko"));

  if (selectedRegion && !filtered.some((item) => String(item.slug || "") === selectedSlug && getRegionDestinationSlug(item) === getRegionDestinationSlug(selectedRegion))) {
    filtered.unshift(selectedRegion);
  }

  selectEl.innerHTML = [
    '<option value="">지역 선택</option>',
    ...filtered.map((item) => `<option value="${escapeHtml(item.slug || "")}">${escapeHtml(getRegionLabel(item))}</option>`)
  ].join("");
  selectEl.value = selectedSlug && filtered.some((item) => String(item.slug || "") === selectedSlug) ? selectedSlug : "";
  selectEl.disabled = !selectedDestinationSlug || filtered.length === 0;
}

function renderRecommendationCategoryOptions(selectedValue = "") {
  const selectEl = $("recommendationCategorySlug");
  const descriptionEl = $("recommendationCategoryDescription");
  if (!selectEl) return;
  const selectedSlug = String(selectedValue || selectEl.value || "").trim();
  const selectedCategory = recommendationCategoryItems.find((item) => String(item.slug || "") === selectedSlug) || null;
  const filtered = recommendationCategoryItems
    .filter((item) => Number(item.is_active ?? 1) !== 0)
    .sort((a, b) => getRecommendationCategoryLabel(a).localeCompare(getRecommendationCategoryLabel(b), "ko"));

  if (selectedCategory && !filtered.some((item) => String(item.slug || "") === selectedSlug)) {
    filtered.unshift(selectedCategory);
  }

  selectEl.innerHTML = [
    '<option value="">추천 카테고리 선택</option>',
    ...filtered.map((item) => `<option value="${escapeHtml(item.slug || "")}">${escapeHtml(getRecommendationCategoryLabel(item))}</option>`)
  ].join("");
  selectEl.value = selectedSlug && filtered.some((item) => String(item.slug || "") === selectedSlug) ? selectedSlug : "";
  selectEl.disabled = filtered.length === 0;
  if (descriptionEl) {
    const category = getSelectedRecommendationCategory();
    descriptionEl.textContent = getRecommendationCategoryDescription(category) || "카테고리를 선택하면 설명이 표시됩니다.";
  }
}

function updateTravelPlacementStatus() {
  const statusEl = $("travelPlacementStatus");
  if (!statusEl) return;
  const contentTypeLabel = labelContentType($("content_type")?.value || "");
  const destination = getSelectedDestination();
  const countryName = getCountryNameBySlug($("country")?.value || getCountrySlugFromDestination(destination));
  const destinationLabel = getDestinationLabel(destination);
  const region = getSelectedRegion();
  const regionLabel = getRegionLabel(region);

  if (!contentTypeLabel || !countryName || !destinationLabel) {
    statusEl.textContent = "글 종류, 나라, 도시를 모두 선택하면 어느 섹션에 노출되는지 확인할 수 있습니다.";
    return;
  }

  const regionText = regionLabel ? ` · ${regionLabel}` : "";
  statusEl.textContent = `${countryName} · ${destinationLabel}${regionText} 페이지의 '${contentTypeLabel}' 섹션에 노출됩니다.`;
}

async function requestTravelSettingsApi(method = "GET", payload = null) {
  const options = {
    method,
    credentials: "same-origin",
    cache: "no-store",
    headers: { Accept: "application/json" }
  };
  if (payload && method !== "GET") {
    options.headers["content-type"] = "application/json";
    options.body = JSON.stringify(payload);
  }
  const res = await fetch(`/api/travel-settings?ts=${Date.now()}`, options);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.message || "여행 노출 설정 요청에 실패했습니다.");
  return json;
}

async function loadTravelSettings(selectedDestinationSlug = "", selectedContentType = "", selectedRegionSlug = "", selectedRecommendationCategorySlug = "") {
  try {
    const json = await requestTravelSettingsApi("GET");
    travelContentTypeItems = Array.isArray(json.content_types) && json.content_types.length ? json.content_types : [...DEFAULT_TRAVEL_CONTENT_TYPES];
    countryItems = Array.isArray(json.countries) ? json.countries : [];
    destinationItems = Array.isArray(json.destinations) ? json.destinations : [];
    regionItems = Array.isArray(json.regions) ? json.regions : [];
    recommendationCategoryItems = Array.isArray(json.recommendation_categories) ? json.recommendation_categories : [];

    const selectedDestination = destinationItems.find((item) => String(item.slug || "") === String(selectedDestinationSlug || ""));
    const selectedCountrySlug = selectedDestination ? getCountrySlugFromDestination(selectedDestination) : String($("country")?.value || "").trim();
    renderContentTypeOptions(selectedContentType || $("content_type")?.value || "");
    renderCountryOptions(selectedCountrySlug);
    renderDestinationOptions(selectedDestinationSlug);
    renderRegionOptions(selectedRegionSlug || $("region_slug")?.value || "");
    renderRecommendationCategoryOptions(selectedRecommendationCategorySlug || $("recommendationCategorySlug")?.value || "");
    renderTravelSettingsManager();
    updateTravelPlacementStatus();
    syncHotelHeroCardVisibility();
    syncRecommendationCategoryCardVisibility();
    renderPreview();
  } catch (error) {
    const statusEl = $("travelPlacementStatus");
    if (statusEl) statusEl.textContent = error.message || "여행 노출 설정을 불러오지 못했습니다.";
  }
}

async function loadDestinations(selectedDestinationSlug = "") {
  await loadTravelSettings(selectedDestinationSlug, $("content_type")?.value || "", $("region_slug")?.value || "", $("recommendationCategorySlug")?.value || "");
}

function bindTravelPlacementEvents() {
  renderContentTypeOptions($("content_type")?.value || "");
  $("content_type")?.addEventListener("change", () => {
    syncHotelHeroCardVisibility();
    syncRecommendationCategoryCardVisibility();
    updateTravelPlacementStatus();
    handleRealtimeChange();
  });
  $("country")?.addEventListener("change", () => {
    renderDestinationOptions("");
    renderRegionOptions("");
    renderRecommendationCategoryOptions($("recommendationCategorySlug")?.value || "");
    updateTravelPlacementStatus();
    handleRealtimeChange();
  });
  $("destination_slug")?.addEventListener("change", () => {
    renderRegionOptions("");
    renderRecommendationCategoryOptions($("recommendationCategorySlug")?.value || "");
    updateTravelPlacementStatus();
    handleRealtimeChange();
  });
  $("region_slug")?.addEventListener("change", () => {
    updateTravelPlacementStatus();
    handleRealtimeChange();
  });
  $("recommendationCategorySlug")?.addEventListener("change", () => {
    renderRecommendationCategoryOptions($("recommendationCategorySlug")?.value || "");
    updateTravelPlacementStatus();
    handleRealtimeChange();
  });
}

function setTravelSettingsStatus(message = "", isError = false) {
  const statusEl = $("travelSettingsManagerStatus");
  if (!statusEl) return;
  statusEl.textContent = message;
  statusEl.style.color = isError ? "#b91c1c" : "";
}

function renderTravelSettingsManager() {
  renderTravelContentTypeManager();
  renderCountryManager();
  renderDestinationManager();
}

function renderTravelContentTypeManager() {
  const listEl = $("travelContentTypeList");
  if (!listEl) return;
  listEl.innerHTML = travelContentTypeItems.length
    ? travelContentTypeItems.map((item) => `
      <div class="category-manager__item">
        <div>
          <div class="category-manager__name">${escapeHtml(item.label || item.slug)}</div>
          <div class="small">slug: ${escapeHtml(item.slug || "")} ${Number(item.is_active ?? 1) === 0 ? " · 미사용" : ""}</div>
          ${item.description ? `<div class="small">${escapeHtml(item.description)}</div>` : ""}
        </div>
        <div class="category-manager__actions">
          <button class="btn" type="button" data-travel-edit-content-type="${escapeHtml(item.slug || "")}">수정</button>
          <button class="btn" type="button" data-travel-delete-content-type="${escapeHtml(item.slug || "")}">삭제</button>
        </div>
      </div>`).join("")
    : '<div class="category-manager__empty small">등록된 글 종류가 없습니다.</div>';
}

function renderCountryManager() {
  const listEl = $("travelCountryList");
  if (!listEl) return;
  listEl.innerHTML = countryItems.length
    ? countryItems.map((item) => `
      <div class="category-manager__item">
        <div>
          <div class="category-manager__name">${escapeHtml(item.name || item.slug)}</div>
          <div class="small">slug: ${escapeHtml(item.slug || "")} ${Number(item.is_active ?? 1) === 0 ? " · 미사용" : ""}</div>
        </div>
        <div class="category-manager__actions">
          <button class="btn" type="button" data-travel-edit-country="${escapeHtml(item.slug || "")}">수정</button>
          <button class="btn" type="button" data-travel-delete-country="${escapeHtml(item.slug || "")}">삭제</button>
        </div>
      </div>`).join("")
    : '<div class="category-manager__empty small">등록된 나라가 없습니다.</div>';

  const selectEl = $("newDestinationCountry");
  if (selectEl) {
    selectEl.innerHTML = [
      '<option value="">나라 선택</option>',
      ...countryItems.map((country) => `<option value="${escapeHtml(country.slug || "")}">${escapeHtml(country.name || country.slug || "")}</option>`)
    ].join("");
  }
}

function renderDestinationManager() {
  const listEl = $("travelDestinationList");
  if (!listEl) return;
  listEl.innerHTML = destinationItems.length
    ? destinationItems.map((item) => `
      <div class="category-manager__item">
        <div>
          <div class="category-manager__name">${escapeHtml(getDestinationLabel(item))}</div>
          <div class="small">${escapeHtml(item.country || getCountryNameBySlug(getCountrySlugFromDestination(item)) || "나라 미지정")} · slug: ${escapeHtml(item.slug || "")} ${Number(item.is_active ?? 1) === 0 ? " · 미사용" : ""}</div>
        </div>
        <div class="category-manager__actions">
          <button class="btn" type="button" data-travel-edit-destination="${escapeHtml(item.slug || "")}">수정</button>
          <button class="btn" type="button" data-travel-delete-destination="${escapeHtml(item.slug || "")}">삭제</button>
        </div>
      </div>`).join("")
    : '<div class="category-manager__empty small">등록된 도시가 없습니다.</div>';
}

function openTravelSettingsModal() {
  const modal = $("travelSettingsModal");
  const backdrop = $("travelSettingsModalBackdrop");
  const openBtn = $("openTravelSettingsModalBtn");
  if (!modal || !backdrop || !openBtn) return;
  backdrop.hidden = false;
  modal.classList.add("is-open");
  modal.setAttribute("aria-hidden", "false");
  openBtn.setAttribute("aria-expanded", "true");
  document.body.classList.add("has-preview-open");
  setTravelSettingsStatus("");
  renderTravelSettingsManager();
}

function closeTravelSettingsModal() {
  const modal = $("travelSettingsModal");
  const backdrop = $("travelSettingsModalBackdrop");
  const openBtn = $("openTravelSettingsModalBtn");
  if (!modal || !backdrop || !openBtn) return;
  modal.classList.remove("is-open");
  modal.setAttribute("aria-hidden", "true");
  backdrop.hidden = true;
  openBtn.setAttribute("aria-expanded", "false");
  document.body.classList.remove("has-preview-open");
}

async function afterTravelSettingsChanged(message, selectedDestinationSlug = $("destination_slug")?.value || "", selectedContentType = $("content_type")?.value || "") {
  await loadTravelSettings(selectedDestinationSlug, selectedContentType, $("region_slug")?.value || "", $("recommendationCategorySlug")?.value || "");
  setTravelSettingsStatus(message);
  handleRealtimeChange();
}

async function addTravelContentType() {
  const label = normalizeCountryName($("newContentTypeLabel")?.value || "");
  const slug = slugify($("newContentTypeSlug")?.value || label);
  const description = normalizeCountryName($("newContentTypeDescription")?.value || "");
  if (!label || !slug) return setTravelSettingsStatus("글 종류 이름과 slug를 입력해 주세요.", true);
  try {
    await requestTravelSettingsApi("POST", { entity: "content_type", slug, label, description });
    ["newContentTypeLabel", "newContentTypeSlug", "newContentTypeDescription"].forEach((id) => { if ($(id)) $(id).value = ""; });
    await afterTravelSettingsChanged("글 종류가 추가되었습니다.", $("destination_slug")?.value || "", slug);
  } catch (error) {
    setTravelSettingsStatus(error.message || "글 종류 추가에 실패했습니다.", true);
  }
}

async function editTravelContentType(slug) {
  const item = travelContentTypeItems.find((entry) => String(entry.slug || "") === String(slug || ""));
  if (!item) return;
  const nextLabel = window.prompt("글 종류 이름", item.label || "");
  if (nextLabel === null) return;
  const nextSlug = window.prompt("글 종류 slug", item.slug || "");
  if (nextSlug === null) return;
  const nextDescription = window.prompt("설명", item.description || "");
  if (nextDescription === null) return;
  try {
    await requestTravelSettingsApi("PUT", { entity: "content_type", current_slug: item.slug, slug: slugify(nextSlug), label: normalizeCountryName(nextLabel), description: normalizeCountryName(nextDescription), is_active: Number(item.is_active ?? 1) });
    await afterTravelSettingsChanged("글 종류가 수정되었습니다.", $("destination_slug")?.value || "", slugify(nextSlug));
  } catch (error) {
    setTravelSettingsStatus(error.message || "글 종류 수정에 실패했습니다.", true);
  }
}

async function deleteTravelContentType(slug) {
  const item = travelContentTypeItems.find((entry) => String(entry.slug || "") === String(slug || ""));
  const ok = window.confirm(`'${item?.label || slug}' 글 종류를 삭제할까요?\n기존 글의 값은 보존되며, 선택 목록에서만 제거됩니다.`);
  if (!ok) return;
  try {
    await requestTravelSettingsApi("DELETE", { entity: "content_type", slug });
    await afterTravelSettingsChanged("글 종류가 삭제되었습니다.", $("destination_slug")?.value || "", $("content_type")?.value === slug ? "" : $("content_type")?.value || "");
  } catch (error) {
    setTravelSettingsStatus(error.message || "글 종류 삭제에 실패했습니다.", true);
  }
}

async function addTravelCountry() {
  const name = normalizeCountryName($("newCountryName")?.value || "");
  const slug = slugify($("newCountrySlug")?.value || name);
  if (!name || !slug) return setTravelSettingsStatus("나라 이름과 slug를 입력해 주세요.", true);
  try {
    await requestTravelSettingsApi("POST", { entity: "country", slug, name });
    ["newCountryName", "newCountrySlug"].forEach((id) => { if ($(id)) $(id).value = ""; });
    await afterTravelSettingsChanged("나라가 추가되었습니다.");
  } catch (error) {
    setTravelSettingsStatus(error.message || "나라 추가에 실패했습니다.", true);
  }
}

async function editTravelCountry(slug) {
  const item = countryItems.find((entry) => String(entry.slug || "") === String(slug || ""));
  if (!item) return;
  const nextName = window.prompt("나라 이름", item.name || "");
  if (nextName === null) return;
  const nextSlug = window.prompt("나라 slug", item.slug || "");
  if (nextSlug === null) return;
  try {
    await requestTravelSettingsApi("PUT", { entity: "country", current_slug: item.slug, slug: slugify(nextSlug), name: normalizeCountryName(nextName), is_active: Number(item.is_active ?? 1) });
    await afterTravelSettingsChanged("나라가 수정되었습니다.");
  } catch (error) {
    setTravelSettingsStatus(error.message || "나라 수정에 실패했습니다.", true);
  }
}

async function deleteTravelCountry(slug) {
  const item = countryItems.find((entry) => String(entry.slug || "") === String(slug || ""));
  const ok = window.confirm(`'${item?.name || slug}' 나라를 삭제할까요?\n도시 데이터는 삭제되지 않지만 선택 목록에서는 제외됩니다.`);
  if (!ok) return;
  try {
    await requestTravelSettingsApi("DELETE", { entity: "country", slug });
    await afterTravelSettingsChanged("나라가 삭제되었습니다.");
  } catch (error) {
    setTravelSettingsStatus(error.message || "나라 삭제에 실패했습니다.", true);
  }
}

async function addTravelDestination() {
  const countrySlug = $("newDestinationCountry")?.value || "";
  const countryName = getCountryNameBySlug(countrySlug);
  const name = normalizeCountryName($("newDestinationName")?.value || "");
  const city = normalizeCountryName($("newDestinationCity")?.value || name);
  const slug = slugify($("newDestinationSlug")?.value || name);
  if (!countrySlug || !name || !slug) return setTravelSettingsStatus("나라, 도시명, slug를 입력해 주세요.", true);
  try {
    await requestTravelSettingsApi("POST", { entity: "destination", slug, name, city, country_slug: countrySlug, country: countryName, status: "published" });
    ["newDestinationName", "newDestinationCity", "newDestinationSlug"].forEach((id) => { if ($(id)) $(id).value = ""; });
    await afterTravelSettingsChanged("도시가 추가되었습니다.", slug);
  } catch (error) {
    setTravelSettingsStatus(error.message || "도시 추가에 실패했습니다.", true);
  }
}

async function editTravelDestination(slug) {
  const item = destinationItems.find((entry) => String(entry.slug || "") === String(slug || ""));
  if (!item) return;
  const nextName = window.prompt("도시 표시 이름", item.name || "");
  if (nextName === null) return;
  const nextSlug = window.prompt("도시 slug", item.slug || "");
  if (nextSlug === null) return;
  const nextCity = window.prompt("도시명", item.city || item.name || "");
  if (nextCity === null) return;
  const currentCountrySlug = getCountrySlugFromDestination(item);
  const nextCountrySlug = window.prompt("나라 slug", currentCountrySlug);
  if (nextCountrySlug === null) return;
  const countryName = getCountryNameBySlug(nextCountrySlug);
  try {
    await requestTravelSettingsApi("PUT", { entity: "destination", current_slug: item.slug, slug: slugify(nextSlug), name: normalizeCountryName(nextName), city: normalizeCountryName(nextCity), country_slug: nextCountrySlug, country: countryName, status: item.status || "published" });
    await afterTravelSettingsChanged("도시가 수정되었습니다.", slugify(nextSlug));
  } catch (error) {
    setTravelSettingsStatus(error.message || "도시 수정에 실패했습니다.", true);
  }
}

async function deleteTravelDestination(slug) {
  const item = destinationItems.find((entry) => String(entry.slug || "") === String(slug || ""));
  const ok = window.confirm(`'${item?.name || slug}' 도시를 삭제할까요?\n이 도시와 연결된 글의 도시 연결값은 비워집니다.`);
  if (!ok) return;
  try {
    await requestTravelSettingsApi("DELETE", { entity: "destination", slug });
    await afterTravelSettingsChanged("도시가 삭제되었습니다.", $("destination_slug")?.value === slug ? "" : $("destination_slug")?.value || "");
  } catch (error) {
    setTravelSettingsStatus(error.message || "도시 삭제에 실패했습니다.", true);
  }
}

function bindTravelSettingsManagerEvents() {
  $("openTravelSettingsModalBtn")?.addEventListener("click", openTravelSettingsModal);
  $("closeTravelSettingsModalBtn")?.addEventListener("click", closeTravelSettingsModal);
  $("travelSettingsModalBackdrop")?.addEventListener("click", closeTravelSettingsModal);
  $("addContentTypeBtn")?.addEventListener("click", addTravelContentType);
  $("addCountryBtn")?.addEventListener("click", addTravelCountry);
  $("addDestinationBtn")?.addEventListener("click", addTravelDestination);
  ["newContentTypeLabel", "newContentTypeSlug", "newContentTypeDescription", "newCountryName", "newCountrySlug", "newDestinationName", "newDestinationCity", "newDestinationSlug"].forEach((id) => {
    $(id)?.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      if (id.startsWith("newContentType")) addTravelContentType();
      else if (id.startsWith("newCountry")) addTravelCountry();
      else addTravelDestination();
    });
  });
  $("travelSettingsModal")?.addEventListener("click", (event) => {
    const target = event.target.closest("button");
    if (!target) return;
    if (target.dataset.travelEditContentType) return editTravelContentType(target.dataset.travelEditContentType);
    if (target.dataset.travelDeleteContentType) return deleteTravelContentType(target.dataset.travelDeleteContentType);
    if (target.dataset.travelEditCountry) return editTravelCountry(target.dataset.travelEditCountry);
    if (target.dataset.travelDeleteCountry) return deleteTravelCountry(target.dataset.travelDeleteCountry);
    if (target.dataset.travelEditDestination) return editTravelDestination(target.dataset.travelEditDestination);
    if (target.dataset.travelDeleteDestination) return deleteTravelDestination(target.dataset.travelDeleteDestination);
  });
}


const TOC_TOKEN_RE = /^\[\[TOC(?::(h2|h2,h3))?\]\]$/i;

const INLINE_IMAGE_LIMIT = 7;
const AGODA_INLINE_IMAGE_LIMIT = 6;
const INLINE_IMAGE_TOKEN_RE = /^\[\[(POST_IMAGE_([1-7]))\s+(.+?)\]\]$/i;
const AGODA_INLINE_IMAGE_TOKEN_RE = /^\[\[(POST_AGODA_IMAGE_([1-6]))\s+(.+?)\]\]$/i;
const AFFILIATE_TOKEN_RE = /^\[\[(POST_AFFILIATE_(?:[1-5]))\s+(.+?)\]\]$/i;
const AFFILIATE_CTA_TOKEN_RE = /^\[\[POST_AFFILIATE_CTA\s+(.+?)\]\]$/i;

function parseTokenAttributes(raw = "") {
  const attrs = {};
  const re = /(\w+)="([^"]*)"/g;
  let match;
  while ((match = re.exec(String(raw || ""))) !== null) {
    attrs[match[1]] = match[2];
  }
  return attrs;
}

function decodeInlineTokenValue(value = "") {
  const raw = String(value || "");
  try { return decodeURIComponent(raw); } catch (_) { return raw; }
}

function encodeInlineTokenValue(value = "") {
  return encodeURIComponent(String(value || "").trim());
}

function defaultInlineImagePosition(index = 1) {
  if (index === 1) return 3;
  if (index === 2) return 5;
  return Math.max(1, Math.min(INLINE_IMAGE_LIMIT, parseInt(index || "1", 10) || 1));
}

function clampInlineImagePosition(value, index = 1) {
  const fallback = defaultInlineImagePosition(index);
  return Math.max(1, Math.min(INLINE_IMAGE_LIMIT, parseInt(value || String(fallback), 10) || fallback));
}

function normalizeInlineImagePlacement(value = "before") {
  return String(value || "").trim().toLowerCase() === "after" ? "after" : "before";
}

function createInlineImageMeta(index = 1) {
  return {
    enabled: false,
    source: "r2",
    key: `POST_IMAGE_${index}`,
    index,
    url: "",
    alt: "",
    caption: "",
    position: defaultInlineImagePosition(index),
    placement: "before"
  };
}

function createAgodaInlineImageMeta(index = 1) {
  return {
    enabled: false,
    source: "agoda",
    key: `POST_AGODA_IMAGE_${index}`,
    index,
    url: "",
    srcset: "",
    link: "",
    alt: "",
    caption: "",
    position: defaultInlineImagePosition(index),
    placement: "before"
  };
}

function getInlineImageItems(meta = {}) {
  const sourceItems = Array.isArray(meta.items)
    ? meta.items
    : [
        ...Array.from({ length: INLINE_IMAGE_LIMIT }, (_, offset) => meta[`image${offset + 1}`]),
        ...Array.from({ length: AGODA_INLINE_IMAGE_LIMIT }, (_, offset) => meta[`agodaImage${offset + 1}`])
      ];
  return sourceItems
    .filter(Boolean)
    .map((item, offset) => {
      const isAgoda = item?.source === "agoda" || String(item?.key || "").startsWith("POST_AGODA_IMAGE_");
      const fallbackIndex = isAgoda
        ? Math.max(1, Math.min(AGODA_INLINE_IMAGE_LIMIT, parseInt(item?.index || "1", 10) || 1))
        : Math.max(1, Math.min(INLINE_IMAGE_LIMIT, parseInt(item?.index || String(offset + 1), 10) || offset + 1));
      return {
        ...(isAgoda ? createAgodaInlineImageMeta(fallbackIndex) : createInlineImageMeta(fallbackIndex)),
        ...(item || {}),
        source: isAgoda ? "agoda" : "r2",
        index: fallbackIndex,
        key: item?.key || (isAgoda ? `POST_AGODA_IMAGE_${fallbackIndex}` : `POST_IMAGE_${fallbackIndex}`),
        position: clampInlineImagePosition(item?.position, fallbackIndex),
        placement: normalizeInlineImagePlacement(item?.placement)
      };
    })
    .filter((item) => item.enabled && (item.url || item.id));
}

function parseInlineImageToken(line = "") {
  const source = String(line || "").trim();
  const agodaMatch = source.match(AGODA_INLINE_IMAGE_TOKEN_RE);
  if (agodaMatch) {
    const index = Math.max(1, Math.min(AGODA_INLINE_IMAGE_LIMIT, parseInt(agodaMatch[2] || "1", 10) || 1));
    const attrs = parseTokenAttributes(agodaMatch[3]);
    return {
      key: agodaMatch[1].toUpperCase(),
      source: "agoda",
      index,
      url: decodeInlineTokenValue(attrs.image || attrs.url || attrs.src || ""),
      srcset: decodeInlineTokenValue(attrs.srcset || ""),
      link: decodeInlineTokenValue(attrs.link || attrs.href || ""),
      alt: decodeInlineTokenValue(attrs.alt || ""),
      caption: decodeInlineTokenValue(attrs.caption || ""),
      position: clampInlineImagePosition(attrs.position, index),
      placement: normalizeInlineImagePlacement(attrs.placement || attrs.place)
    };
  }

  const match = source.match(INLINE_IMAGE_TOKEN_RE);
  if (!match) return null;
  const index = Math.max(1, Math.min(INLINE_IMAGE_LIMIT, parseInt(match[2] || "1", 10) || 1));
  const attrs = parseTokenAttributes(match[3]);
  return {
    key: match[1].toUpperCase(),
    source: "r2",
    index,
    url: String(attrs.url || attrs.id || "").trim(),
    alt: String(attrs.alt || "").trim(),
    caption: String(attrs.caption || "").trim(),
    position: clampInlineImagePosition(attrs.position, index),
    placement: (attrs.placement || attrs.place) ? normalizeInlineImagePlacement(attrs.placement || attrs.place) : "after"
  };
}

function stripInlineImageTokenLines(md = "") {
  return String(md || "")
    .split("\n")
    .filter((line) => !parseInlineImageToken(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function parseInlineImageMetaFromMarkdown(md = "") {
  const result = { items: [] };
  for (let index = 1; index <= INLINE_IMAGE_LIMIT; index += 1) {
    const item = createInlineImageMeta(index);
    result[`image${index}`] = item;
    result.items.push(item);
  }
  for (let index = 1; index <= AGODA_INLINE_IMAGE_LIMIT; index += 1) {
    const item = createAgodaInlineImageMeta(index);
    result[`agodaImage${index}`] = item;
    result.items.push(item);
  }
  String(md || "").split("\n").forEach((line) => {
    const token = parseInlineImageToken(line);
    if (!token) return;
    const target = token.source === "agoda"
      ? result[`agodaImage${token.index}`]
      : result[`image${token.index}`];
    if (!target) return;
    Object.assign(target, token, { enabled: !!token.url });
  });
  return result;
}

function buildInlineImageToken(key, data) {
  if (!data || !data.enabled || !String((data.url || data.id || "")).trim()) return "";
  const isAgoda = data.source === "agoda" || String(key || "").startsWith("POST_AGODA_IMAGE_");
  if (isAgoda) {
    const index = Math.max(1, Math.min(AGODA_INLINE_IMAGE_LIMIT, parseInt(String(key).replace("POST_AGODA_IMAGE_", ""), 10) || 1));
    const safePosition = clampInlineImagePosition(data.position, index);
    const safePlacement = normalizeInlineImagePlacement(data.placement);
    return `[[POST_AGODA_IMAGE_${index} image="${encodeInlineTokenValue(data.url)}" srcset="${encodeInlineTokenValue(data.srcset)}" link="${encodeInlineTokenValue(data.link)}" alt="${encodeInlineTokenValue(data.alt)}" caption="${encodeInlineTokenValue(data.caption)}" position="${safePosition}" placement="${safePlacement}"]]`;
  }

  const safeUrl = sanitizeImageUrlValue(data.url || data.id || "").replace(/"/g, "&quot;");
  const safeAlt = String(data.alt || "").trim().replace(/"/g, "&quot;");
  const safeCaption = String(data.caption || "").trim().replace(/"/g, "&quot;");
  const index = Math.max(1, Math.min(INLINE_IMAGE_LIMIT, parseInt(String(key).replace("POST_IMAGE_", ""), 10) || 1));
  const safePosition = clampInlineImagePosition(data.position, index);
  const safePlacement = normalizeInlineImagePlacement(data.placement);
  return `[[POST_IMAGE_${index} url="${safeUrl}" alt="${safeAlt}" caption="${safeCaption}" position="${safePosition}" placement="${safePlacement}"]]`;
}

function collectR2InlineImageFormData() {
  const result = { items: [] };
  for (let index = 1; index <= INLINE_IMAGE_LIMIT; index += 1) {
    const item = {
      ...createInlineImageMeta(index),
      enabled: !!($(`enableInlineImage${index}`)?.checked),
      url: sanitizeImageUrlValue($(`inlineImage${index}Id`)?.value || ""),
      alt: $(`inlineImage${index}Alt`)?.value.trim() || "",
      caption: $(`inlineImage${index}Caption`)?.value.trim() || "",
      position: clampInlineImagePosition($(`inlineImage${index}Position`)?.value, index),
      placement: normalizeInlineImagePlacement($(`inlineImage${index}Placement`)?.value)
    };
    result[`image${index}`] = item;
    result.items.push(item);
  }
  return result;
}

function setAgodaInlineImageStatus(index, message = "", state = "") {
  const status = $(`agodaInlineImage${index}Status`);
  if (!status) return;
  status.textContent = message;
  status.dataset.state = state;
}

function collectAgodaInlineImageFormData({ validate = false } = {}) {
  const result = { items: [], ok: true, error: "", invalidIndex: 0 };
  const utils = window.CoverImageSourceUtils;
  for (let index = 1; index <= AGODA_INLINE_IMAGE_LIMIT; index += 1) {
    const enabled = !!($(`enableAgodaInlineImage${index}`)?.checked);
    const rawHtml = $(`agodaInlineImage${index}Html`)?.value || "";
    const base = {
      ...createAgodaInlineImageMeta(index),
      enabled,
      alt: $(`agodaInlineImage${index}Alt`)?.value.trim() || "",
      caption: $(`agodaInlineImage${index}Caption`)?.value.trim() || "",
      position: clampInlineImagePosition($(`agodaInlineImage${index}Position`)?.value, index),
      placement: normalizeInlineImagePlacement($(`agodaInlineImage${index}Placement`)?.value)
    };

    if (!enabled) {
      setAgodaInlineImageStatus(index, "", "");
      result[`agodaImage${index}`] = base;
      result.items.push(base);
      continue;
    }

    const parsed = utils?.parseAgodaHtml
      ? utils.parseAgodaHtml(rawHtml)
      : { ok: false, error: "아고다 이미지 파서가 준비되지 않았습니다." };
    if (!parsed.ok) {
      const message = parsed.error || `아고다 이미지 ${index} 정보를 확인해 주세요.`;
      setAgodaInlineImageStatus(index, message, "error");
      if (result.ok) {
        result.ok = false;
        result.error = message;
        result.invalidIndex = index;
      }
      result[`agodaImage${index}`] = base;
      result.items.push(base);
      continue;
    }

    const item = { ...base, url: parsed.image, srcset: parsed.srcset || "", link: parsed.link || "" };
    setAgodaInlineImageStatus(index, "아고다 링크와 이미지 주소를 확인했습니다.", "success");
    result[`agodaImage${index}`] = item;
    result.items.push(item);
  }
  return result;
}

function collectInlineImageFormData(options = {}) {
  const r2 = collectR2InlineImageFormData();
  const agoda = collectAgodaInlineImageFormData(options);
  return {
    ...r2,
    ...Object.fromEntries(Object.entries(agoda).filter(([key]) => key.startsWith("agodaImage"))),
    items: [...r2.items, ...agoda.items],
    ok: agoda.ok,
    error: agoda.error,
    invalidIndex: agoda.invalidIndex
  };
}

function applyInlineImageFormData(meta = {}) {
  for (let index = 1; index <= INLINE_IMAGE_LIMIT; index += 1) {
    const image = meta[`image${index}`] || {};
    if ($(`enableInlineImage${index}`)) $(`enableInlineImage${index}`).checked = !!image.enabled;
    if ($(`inlineImage${index}Id`)) $(`inlineImage${index}Id`).value = sanitizeImageUrlValue(image.url || image.id || "");
    if ($(`inlineImage${index}Alt`)) $(`inlineImage${index}Alt`).value = image.alt || "";
    if ($(`inlineImage${index}Caption`)) $(`inlineImage${index}Caption`).value = image.caption || "";
    if ($(`inlineImage${index}Position`)) $(`inlineImage${index}Position`).value = String(clampInlineImagePosition(image.position, index));
    if ($(`inlineImage${index}Placement`)) $(`inlineImage${index}Placement`).value = normalizeInlineImagePlacement(image.placement);
  }

  const utils = window.CoverImageSourceUtils;
  for (let index = 1; index <= AGODA_INLINE_IMAGE_LIMIT; index += 1) {
    const image = meta[`agodaImage${index}`] || {};
    if ($(`enableAgodaInlineImage${index}`)) $(`enableAgodaInlineImage${index}`).checked = !!image.enabled;
    if ($(`agodaInlineImage${index}Html`)) {
      $(`agodaInlineImage${index}Html`).value = image.enabled && utils?.buildAgodaHtml
        ? utils.buildAgodaHtml({ link: image.link, image: image.url || image.id, srcset: image.srcset })
        : "";
    }
    if ($(`agodaInlineImage${index}Alt`)) $(`agodaInlineImage${index}Alt`).value = image.alt || "";
    if ($(`agodaInlineImage${index}Caption`)) $(`agodaInlineImage${index}Caption`).value = image.caption || "";
    if ($(`agodaInlineImage${index}Position`)) $(`agodaInlineImage${index}Position`).value = String(clampInlineImagePosition(image.position, index));
    if ($(`agodaInlineImage${index}Placement`)) $(`agodaInlineImage${index}Placement`).value = normalizeInlineImagePlacement(image.placement);
  }
  const hasR2Images = Array.from({ length: INLINE_IMAGE_LIMIT }, (_, offset) => meta[`image${offset + 1}`]).some((item) => item?.enabled);
  const hasAgodaImages = Array.from({ length: AGODA_INLINE_IMAGE_LIMIT }, (_, offset) => meta[`agodaImage${offset + 1}`]).some((item) => item?.enabled);
  if (hasAgodaImages && !hasR2Images) {
    const agodaSourceInput = document.querySelector('input[name="inlineImageEditorSource"][value="agoda"]');
    if (agodaSourceInput) agodaSourceInput.checked = true;
  }
  syncInlineImageVisibility();
}

function getSelectedInlineImageEditorSource() {
  return String(document.querySelector('input[name="inlineImageEditorSource"]:checked')?.value || "r2") === "agoda"
    ? "agoda"
    : "r2";
}

function syncInlineImageSourcePanels() {
  const source = getSelectedInlineImageEditorSource();
  const r2Panel = $("r2InlineImagePanel");
  const agodaPanel = $("agodaInlineImagePanel");
  if (r2Panel) r2Panel.hidden = source !== "r2";
  if (agodaPanel) agodaPanel.hidden = source !== "agoda";
  document.querySelectorAll(".inline-image-source-option").forEach((label) => {
    const input = label.querySelector('input[name="inlineImageEditorSource"]');
    label.classList.toggle("is-active", !!input?.checked);
  });
}

function syncInlineImageVisibility() {
  for (let index = 1; index <= INLINE_IMAGE_LIMIT; index += 1) {
    const toggle = $(`enableInlineImage${index}`);
    const field = $(`inlineImage${index}Fields`);
    if (!toggle || !field) continue;
    field.hidden = !toggle.checked;
  }
  for (let index = 1; index <= AGODA_INLINE_IMAGE_LIMIT; index += 1) {
    const toggle = $(`enableAgodaInlineImage${index}`);
    const field = $(`agodaInlineImage${index}Fields`);
    if (!toggle || !field) continue;
    field.hidden = !toggle.checked;
  }
  syncInlineImageSourcePanels();
}

function buildContentWithInlineImageTokens(md = "") {
  const cleanMd = stripInlineImageTokenLines(md);
  const meta = collectInlineImageFormData();
  const tokens = meta.items.map((item) => buildInlineImageToken(item.key, item)).filter(Boolean);
  return [...tokens, cleanMd].filter(Boolean).join("\n\n").trim();
}

function renderInlineImageFigure(data = {}, index = 1, extraClass = "") {
  const imageUrl = String(data.url || data.id || "").trim();
  if (!imageUrl) return "";
  const alt = String(data.alt || `본문 이미지 ${index}`).trim();
  const caption = String(data.caption || "").trim();
  const isAgoda = data.source === "agoda";
  const figureClass = ["preview-inline-image", isAgoda ? "preview-inline-image--agoda" : "", String(extraClass || "").trim()].filter(Boolean).join(" ");
  const imageHtml = isAgoda
    ? `<img src="${escapeHtml(imageUrl)}"${data.srcset ? ` srcset="${escapeHtml(data.srcset)}"` : ""} sizes="(max-width: 760px) 100vw, 760px" alt="${escapeHtml(alt)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" />`
    : `<img ${renderOptimizedImageAttrs(imageUrl, { widths: [480, 768, 960, 1200], sizes: "(max-width: 760px) 100vw, 760px", fallbackWidth: 960, fit: "scale-down", quality: 85 })} alt="${escapeHtml(alt)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" />`;
  const linkedImage = isAgoda && data.link
    ? `<a class="preview-inline-image__link" href="${escapeHtml(data.link)}" target="_blank" rel="sponsored noopener noreferrer">${imageHtml}</a>`
    : imageHtml;
  return `
    <figure class="${figureClass}">
      ${linkedImage}
      ${caption ? `<figcaption>${escapeHtml(caption)}</figcaption>` : ""}
    </figure>
  `;
}

function markPreviewSectionLabelAfterImageHtml(html = "") {
  const source = String(html || "");
  if (/^<p\s+class=/i.test(source.trim())) {
    return source.replace(/^<p\s+class="([^"]*)"/i, '<p class="$1 preview-section-label preview-section-label--after-image"');
  }
  return source.replace(/^<p>/i, '<p class="preview-section-label preview-section-label--after-image">');
}


function parseAffiliateToken(line = "") {
  const match = String(line || "").trim().match(AFFILIATE_TOKEN_RE);
  if (!match) return null;
  const attrs = parseTokenAttributes(match[2]);
  return {
    key: match[1].toUpperCase(),
    imageUrl: String(attrs.image || attrs.imageUrl || "").trim(),
    linkUrl: String(attrs.link || attrs.linkUrl || "").trim(),
    productName: String(attrs.name || attrs.productName || "").trim(),
    currentPrice: String(attrs.current || attrs.currentPrice || "").trim(),
    salePrice: String(attrs.sale || attrs.salePrice || "").trim(),
    discountRate: String(attrs.discount || attrs.discountRate || "").trim(),
    buttonText: String(attrs.button || attrs.buttonText || "상품 보기").trim() || "상품 보기",
    position: Math.max(1, parseInt(attrs.position || attrs.h2 || "1", 10) || 1)
  };
}

function clampAffiliateCtaPosition(value = 1) {
  return Math.max(1, Math.min(10, parseInt(value || "1", 10) || 1));
}

function normalizeAffiliateCtaItem(data = {}) {
  const buttonText = String(data.buttonText || data.button || data.text || "예약 가능 날짜 확인하기").trim() || "예약 가능 날짜 확인하기";
  const linkUrl = String(data.linkUrl || data.link || data.url || "").trim();
  const position = clampAffiliateCtaPosition(data.position || data.h2 || 1);
  return {
    enabled: data.enabled !== false && !!(buttonText || linkUrl),
    buttonText,
    linkUrl,
    position
  };
}

function normalizeAffiliateCtaMeta(meta = {}) {
  const rawItems = Array.isArray(meta?.items)
    ? meta.items
    : (meta && (meta.enabled || meta.buttonText || meta.linkUrl) ? [meta] : []);
  const items = rawItems
    .map((item) => normalizeAffiliateCtaItem(item))
    .filter((item) => item.enabled && (item.buttonText || item.linkUrl));
  return {
    enabled: meta?.enabled !== false && items.length > 0,
    items: items.length ? items : [{ enabled: true, buttonText: "예약 가능 날짜 확인하기", linkUrl: "", position: 1 }]
  };
}

function getDefaultAffiliateCtaMeta() {
  return {
    enabled: false,
    items: [{ enabled: true, buttonText: "예약 가능 날짜 확인하기", linkUrl: "", position: 1 }]
  };
}

function buildAffiliateCtaPositionOptions(selected = 1) {
  const current = clampAffiliateCtaPosition(selected);
  return Array.from({ length: 10 }, (_, index) => {
    const value = index + 1;
    return `<option value="${value}"${value === current ? " selected" : ""}>${value}번 H2 섹션 끝</option>`;
  }).join("");
}

function parseAffiliateCtaToken(line = "") {
  const match = String(line || "").trim().match(AFFILIATE_CTA_TOKEN_RE);
  if (!match) return null;
  const attrs = parseTokenAttributes(match[1]);
  return normalizeAffiliateCtaItem(attrs);
}

function stripAffiliateCtaTokenLines(md = "") {
  return String(md || "")
    .split("\n")
    .filter((line) => !parseAffiliateCtaToken(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function parseAffiliateCtaMetaFromMarkdown(md = "") {
  const items = [];
  String(md || "").split("\n").forEach((line) => {
    const token = parseAffiliateCtaToken(line);
    if (!token) return;
    items.push(token);
  });
  if (!items.length) return getDefaultAffiliateCtaMeta();
  return { enabled: true, items };
}

function buildAffiliateCtaToken(data = {}) {
  const item = normalizeAffiliateCtaItem(data);
  if (!item.enabled || !(item.buttonText || item.linkUrl)) return "";
  const esc = (value) => String(value || "").trim().replace(/"/g, "&quot;");
  const safePosition = clampAffiliateCtaPosition(item.position || 1);
  return `[[POST_AFFILIATE_CTA button="${esc(item.buttonText)}" link="${esc(item.linkUrl)}" position="${safePosition}"]]`;
}

function buildAffiliateCtaTokens(meta = {}) {
  const normalized = normalizeAffiliateCtaMeta(meta);
  if (!normalized.enabled) return [];
  return normalized.items.map((item) => buildAffiliateCtaToken(item)).filter(Boolean);
}

function renderAffiliateCtaEditorRows(items = []) {
  const list = $("affiliateCtaList");
  if (!list) return;
  const safeItems = Array.isArray(items) && items.length ? items : getDefaultAffiliateCtaMeta().items;
  list.innerHTML = safeItems.map((item, index) => {
    const normalized = normalizeAffiliateCtaItem(item);
    return `
      <div class="affiliate-cta-editor-item" data-affiliate-cta-item>
        <div class="affiliate-cta-editor-item__head">
          <strong>CTA ${index + 1}</strong>
          <button class="btn btn--ghost affiliate-cta-editor-item__remove" type="button" data-remove-affiliate-cta>삭제</button>
        </div>
        <div class="grid grid--2 affiliate-cta-editor-item__fields" style="gap:12px;">
          <input class="input" data-affiliate-cta-button-text placeholder="버튼 이름" value="${escapeHtml(normalized.buttonText)}" />
          <input class="input" data-affiliate-cta-link-url placeholder="제휴 링크 URL" value="${escapeHtml(normalized.linkUrl)}" />
          <select class="input" data-affiliate-cta-position>${buildAffiliateCtaPositionOptions(normalized.position)}</select>
        </div>
      </div>
    `;
  }).join("");
}

function collectAffiliateCtaFormData() {
  const enabled = !!($("enableAffiliateCta")?.checked);
  const rows = Array.from(document.querySelectorAll("[data-affiliate-cta-item]"));
  const items = rows.map((row) => ({
    enabled: true,
    buttonText: row.querySelector("[data-affiliate-cta-button-text]")?.value.trim() || "예약 가능 날짜 확인하기",
    linkUrl: row.querySelector("[data-affiliate-cta-link-url]")?.value.trim() || "",
    position: clampAffiliateCtaPosition(row.querySelector("[data-affiliate-cta-position]")?.value || 1)
  })).filter((item) => item.buttonText || item.linkUrl);
  return {
    enabled,
    items: items.length ? items : getDefaultAffiliateCtaMeta().items
  };
}

function applyAffiliateCtaFormData(meta = {}) {
  const normalized = normalizeAffiliateCtaMeta(meta);
  const enabled = !!meta.enabled && normalized.items.some((item) => item.buttonText || item.linkUrl);
  if ($("enableAffiliateCta")) $("enableAffiliateCta").checked = enabled;
  renderAffiliateCtaEditorRows(normalized.items);
  syncAffiliateCtaVisibility();
}

function syncAffiliateCtaVisibility() {
  const field = $("affiliateCtaFields");
  if (field) field.hidden = !($("enableAffiliateCta")?.checked);
  if (!document.querySelector("[data-affiliate-cta-item]")) {
    renderAffiliateCtaEditorRows(getDefaultAffiliateCtaMeta().items);
  }
}

function addAffiliateCtaEditorRow() {
  const meta = collectAffiliateCtaFormData();
  meta.items.push({ enabled: true, buttonText: "예약 가능 날짜 확인하기", linkUrl: "", position: Math.min(10, meta.items.length + 1) });
  renderAffiliateCtaEditorRows(meta.items);
  handleRealtimeChange();
}

function removeAffiliateCtaEditorRow(button) {
  const row = button?.closest("[data-affiliate-cta-item]");
  if (row) row.remove();
  if (!document.querySelector("[data-affiliate-cta-item]")) {
    renderAffiliateCtaEditorRows(getDefaultAffiliateCtaMeta().items);
  }
  handleRealtimeChange();
}

function renderAffiliateCtaPreviewButton(data = {}) {
  const cta = normalizeAffiliateCtaItem(data);
  if (!cta.enabled || !(cta.buttonText || cta.linkUrl)) return "";
  const buttonText = String(cta.buttonText || "예약 가능 날짜 확인하기").trim() || "예약 가능 날짜 확인하기";
  return `
    <div class="preview-affiliate-cta" aria-label="제휴 마케팅 CTA">
      ${cta.linkUrl ? `<a class="preview-affiliate-cta__button" href="${escapeHtml(cta.linkUrl)}" target="_blank" rel="nofollow sponsored noopener noreferrer">${escapeHtml(buttonText)}</a>` : `<span class="preview-affiliate-cta__button is-disabled">${escapeHtml(buttonText)}</span>`}
    </div>
  `;
}

function stripAffiliateTokenLines(md = "") {
  return String(md || "")
    .split("\n")
    .filter((line) => !parseAffiliateToken(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function parseAffiliateMetaFromMarkdown(md = "") {
  const items = Array.from({ length: 5 }, (_, index) => ({
    enabled: false,
    imageUrl: "",
    linkUrl: "",
    productName: "",
    currentPrice: "",
    salePrice: "",
    discountRate: "",
    buttonText: "상품 보기",
    position: index + 1
  }));

  String(md || "").split("\n").forEach((line) => {
    const token = parseAffiliateToken(line);
    if (!token) return;
    const match = token.key.match(/(\d+)$/);
    const idx = match ? Math.max(0, Math.min(4, parseInt(match[1], 10) - 1)) : 0;
    items[idx] = {
      enabled: !!(token.imageUrl || token.linkUrl || token.productName),
      imageUrl: token.imageUrl,
      linkUrl: token.linkUrl,
      productName: token.productName,
      currentPrice: token.currentPrice,
      salePrice: token.salePrice,
      discountRate: token.discountRate,
      buttonText: token.buttonText || "상품 보기",
      position: token.position
    };
  });

  return {
    enabled: items.some((item) => item.enabled),
    items
  };
}

function buildAffiliateToken(index, data = {}) {
  if (!data || !data.enabled) return "";
  const hasContent = [data.imageUrl, data.linkUrl, data.productName, data.currentPrice, data.salePrice, data.discountRate, data.buttonText]
    .some((value) => String(value || "").trim());
  if (!hasContent) return "";
  const esc = (value) => String(value || "").trim().replace(/"/g, '&quot;');
  const safePosition = Math.max(1, parseInt(data.position || index || 1, 10) || index || 1);
  return `[[POST_AFFILIATE_${index} image="${esc(sanitizeImageUrlValue(data.imageUrl))}" link="${esc(data.linkUrl)}" name="${esc(data.productName)}" current="${esc(data.currentPrice)}" sale="${esc(data.salePrice)}" discount="${esc(data.discountRate)}" button="${esc(data.buttonText || "상품 보기")}" position="${safePosition}"]]`;
}

function collectAffiliateFormData() {
  const enabled = !!($("enableAffiliateLinks")?.checked);
  const items = Array.from({ length: 5 }, (_, index) => {
    const no = index + 1;
    return {
      enabled,
      imageUrl: sanitizeImageUrlValue($("affiliateImageUrl" + no)?.value || ""),
      linkUrl: $("affiliateLinkUrl" + no)?.value.trim() || "",
      productName: $("affiliateProductName" + no)?.value.trim() || "",
      currentPrice: $("affiliateCurrentPrice" + no)?.value.trim() || "",
      salePrice: $("affiliateSalePrice" + no)?.value.trim() || "",
      discountRate: $("affiliateDiscountRate" + no)?.value.trim() || "",
      buttonText: $("affiliateButtonText" + no)?.value.trim() || "상품 보기",
      position: Math.max(1, parseInt($("affiliatePosition" + no)?.value || String(no), 10) || no)
    };
  });
  return { enabled, items };
}

function getVisibleAffiliateItemCount() {
  return document.querySelectorAll('.affiliate-item-card:not([hidden])').length;
}

function syncAffiliateSectionVisibility() {
  const enabled = !!($("enableAffiliateLinks")?.checked);
  const section = $("affiliateLinksFields");
  if (section) section.hidden = !enabled;
  const addBtn = $("addAffiliateItemBtn");
  if (addBtn) addBtn.hidden = !enabled || getVisibleAffiliateItemCount() >= 5;
}

function applyAffiliateFormData(meta = {}) {
  const items = Array.isArray(meta.items) ? meta.items : [];
  const enabled = !!(meta.enabled || items.some((item) => item && item.enabled));
  if ($("enableAffiliateLinks")) $("enableAffiliateLinks").checked = enabled;
  document.querySelectorAll('.affiliate-item-card').forEach((card) => { card.hidden = true; });
  let visible = 0;
  items.forEach((item, index) => {
    if (!item || !item.enabled) return;
    const no = index + 1;
    visible = Math.max(visible, no);
    const card = $("affiliateItem" + no);
    if (card) card.hidden = false;
    if ($("affiliateImageUrl" + no)) $("affiliateImageUrl" + no).value = sanitizeImageUrlValue(item.imageUrl || "");
    if ($("affiliateLinkUrl" + no)) $("affiliateLinkUrl" + no).value = item.linkUrl || "";
    if ($("affiliateProductName" + no)) $("affiliateProductName" + no).value = item.productName || "";
    if ($("affiliateCurrentPrice" + no)) $("affiliateCurrentPrice" + no).value = item.currentPrice || "";
    if ($("affiliateSalePrice" + no)) $("affiliateSalePrice" + no).value = item.salePrice || "";
    if ($("affiliateDiscountRate" + no)) $("affiliateDiscountRate" + no).value = item.discountRate || "";
    if ($("affiliateButtonText" + no)) $("affiliateButtonText" + no).value = item.buttonText || "상품 보기";
    if ($("affiliatePosition" + no)) $("affiliatePosition" + no).value = String(Math.max(1, parseInt(item.position || no, 10) || no));
  });
  if (enabled && visible === 0) visible = 1;
  if (!enabled) visible = 0;
  for (let i = 1; i <= visible; i += 1) {
    const card = $("affiliateItem" + i);
    if (card) card.hidden = false;
  }
  syncAffiliateSectionVisibility();
}

function addAffiliateItemCard() {
  const current = getVisibleAffiliateItemCount();
  if (current >= 5) return;
  const next = $("affiliateItem" + (current + 1));
  if (next) next.hidden = false;
  syncAffiliateSectionVisibility();
}

function removeAffiliateItemCard(no) {
  const card = $("affiliateItem" + no);
  if (card) card.hidden = true;
  ["affiliateImageUrl", "affiliateLinkUrl", "affiliateProductName", "affiliateCurrentPrice", "affiliateSalePrice", "affiliateDiscountRate", "affiliateButtonText"].forEach((prefix) => {
    const el = $(prefix + no);
    if (el) el.value = "";
  });
  const posEl = $("affiliatePosition" + no);
  if (posEl) posEl.value = String(no);
  if (getVisibleAffiliateItemCount() === 0 && $("enableAffiliateLinks")) {
    $("enableAffiliateLinks").checked = false;
  }
  syncAffiliateSectionVisibility();
}


function encodeKeywordTokenValue(value = "") {
  return String(value || "").replace(/"/g, "&quot;").trim();
}

function parseSeoKeywordsToken(line = "") {
  const raw = String(line || "").trim();
  return raw.match(/^\[\[POST_SEO\s+.+\]\]$/);
}

function buildSeoKeywordsToken({ focus = "", longtail = [], lsi = [] } = {}) {
  const safeFocus = encodeKeywordTokenValue(focus);
  const safeLongtail = (Array.isArray(longtail) ? longtail : [])
    .map(encodeKeywordTokenValue)
    .filter(Boolean)
    .join("||");
  const safeLsi = (Array.isArray(lsi) ? lsi : [])
    .map(encodeKeywordTokenValue)
    .filter(Boolean)
    .join("||");
  if (!safeFocus && !safeLongtail && !safeLsi) return "";
  return `[[POST_SEO focus="${safeFocus}" longtail="${safeLongtail}" lsi="${safeLsi}"]]`;
}

function parseLsiKeywordsToken(line = "") {
  const match = String(line || "").trim().match(/^\[\[POST_LSI\s+keywords="([^"]*)"\]\]$/);
  if (!match) return null;
  const raw = String(match[1] || "").replace(/&quot;/g, '"').trim();
  const keywords = raw
    ? raw.split("||").map((item) => item.trim()).filter(Boolean)
    : [];
  return { keywords };
}

function stripLsiKeywordsTokenLines(md = "") {
  return String(md || "")
    .split("\n")
    .filter((line) => !parseLsiKeywordsToken(line) && !parseSeoKeywordsToken(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function buildLsiKeywordsToken(keywords = []) {
  const items = Array.isArray(keywords)
    ? keywords.map((item) => String(item || "").trim()).filter(Boolean)
    : [];
  if (!items.length) return "";
  const safe = items.map((item) => item.replace(/"/g, "&quot;")).join("||");
  return `[[POST_LSI keywords="${safe}"]]`;
}

function applyLsiKeywordsFromMarkdown(md = "") {
  let lsiKeywords = [];
  let foundToken = false;
  String(md || "").split("\n").forEach((line) => {
    const token = parseLsiKeywordsToken(line);
    if (!token) return;
    foundToken = true;
    lsiKeywords = token.keywords || [];
  });
  if (foundToken && $("lsiKeywords")) {
    $("lsiKeywords").value = Array.isArray(lsiKeywords) ? lsiKeywords.join(", ") : "";
  }
}

function buildContentWithMetaTokens(md = "") {
  const cleanMd = stripLsiKeywordsTokenLines(stripAffiliateCtaTokenLines(stripAffiliateTokenLines(stripInlineImageTokenLines(md))));
  const imageMeta = collectInlineImageFormData();
  const affiliateMeta = collectAffiliateFormData();
  const affiliateCtaMeta = collectAffiliateCtaFormData();
  const focusKeyword = $("focusKeyword")?.value.trim() || "";
  const longtailKeywords = parseKeywords($("longtailKeywords")?.value || "");
  const lsiKeywords = parseKeywords($("lsiKeywords")?.value || "");
  const seoToken = buildSeoKeywordsToken({ focus: focusKeyword, longtail: longtailKeywords, lsi: lsiKeywords });
  const lsiToken = buildLsiKeywordsToken(lsiKeywords);
  const imageTokens = imageMeta.items.map((item) => buildInlineImageToken(item.key, item)).filter(Boolean);
  const affiliateTokens = affiliateMeta.enabled
    ? affiliateMeta.items.map((item, index) => buildAffiliateToken(index + 1, item)).filter(Boolean)
    : [];
  const affiliateCtaTokens = buildAffiliateCtaTokens(affiliateCtaMeta);
  return [seoToken, lsiToken, ...imageTokens, ...affiliateTokens, ...affiliateCtaTokens, cleanMd].filter(Boolean).join("\n\n").trim();
}

function renderAffiliatePreviewCard(data = {}, index = 1) {
  if (!data || !(data.imageUrl || data.linkUrl || data.productName)) return "";
  const buttonText = String(data.buttonText || "상품 보기").trim() || "상품 보기";
  return `
    <article class="preview-affiliate-card">
      <div class="preview-affiliate-card__media">
        ${data.imageUrl ? `<img ${renderOptimizedImageAttrs(data.imageUrl, { widths: [180, 240, 320, 480], sizes: "(max-width: 720px) 110px, 180px", fallbackWidth: 320, fit: "cover", quality: 85 })} alt="${escapeHtml(data.productName || `제휴 상품 ${index}`)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" />` : `<div class="preview-affiliate-card__placeholder">상품 이미지</div>`}
      </div>
      <div class="preview-affiliate-card__content">
        ${data.productName ? `<h3 class="preview-affiliate-card__title">${escapeHtml(data.productName)}</h3>` : ""}
        <div class="preview-affiliate-card__prices">
          ${data.currentPrice ? `<span class="preview-affiliate-card__price-label">현재가</span><strong>${escapeHtml(data.currentPrice)}</strong>` : ""}
          ${data.salePrice ? `<span class="preview-affiliate-card__sale">할인가 ${escapeHtml(data.salePrice)}</span>` : ""}
          ${data.discountRate ? `<span class="preview-affiliate-card__discount">${escapeHtml(data.discountRate)}</span>` : ""}
        </div>
        ${data.linkUrl ? `<a class="preview-affiliate-card__button" href="${escapeHtml(data.linkUrl)}" target="_blank" rel="noopener noreferrer nofollow sponsored">${escapeHtml(buttonText)}</a>` : `<span class="preview-affiliate-card__button is-disabled">${escapeHtml(buttonText)}</span>`}
      </div>
    </article>
  `;
}


function parseTocModeFromLine(line) {
  const match = String(line || "").trim().match(TOC_TOKEN_RE);
  return match ? (match[1] || "h2").toLowerCase() : null;
}

function stripTocTokenLines(md) {
  return String(md || "")
    .split("\n")
    .filter((line) => !parseTocModeFromLine(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function buildHeadingSlug(text, slugCounts) {
  const base = String(text || "")
    .trim()
    .toLowerCase()
    .replace(/<[^>]+>/g, "")
    .replace(/[^a-z0-9\-가-힣\s]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "") || "section";
  const currentCount = slugCounts.get(base) || 0;
  slugCounts.set(base, currentCount + 1);
  return currentCount ? `${base}-${currentCount + 1}` : base;
}

function extractTocItems(md, mode = "h2") {
  const includeH3 = mode === "h2,h3";
  const lines = String(md || "").replace(/\r/g, "").split("\n");
  const slugCounts = new Map();
  const items = [];
  for (const rawLine of lines) {
    const trimmed = rawLine.trim();
    const headingMatch = trimmed.match(/^(#{2,3})\s+(.+)$/);
    if (!headingMatch) continue;
    const level = headingMatch[1].length;
    if (level === 3 && !includeH3) continue;
    const textValue = headingMatch[2].trim();
    const id = buildHeadingSlug(textValue, slugCounts);
    items.push({ level, text: textValue, id });
  }
  return items;
}

function renderTocHtml(items, mode = "h2", options = {}) {
  if (!items.length) return "";
  const includeH3 = mode === "h2,h3";
  const numbered = options.numbered !== false;
  let h2Count = 0;
  let h3Count = 0;
  const numberedItems = items.map((item) => {
    if (!numbered) return { ...item, indexLabel: "" };
    if (item.level === 2) {
      h2Count += 1;
      h3Count = 0;
      return { ...item, indexLabel: `${h2Count}.` };
    }
    h3Count += 1;
    return { ...item, indexLabel: `${Math.max(h2Count, 1)}.${h3Count}` };
  });
  const listTag = numbered ? "ol" : "ul";

  return `
    <details class="post-toc${numbered ? "" : " post-toc--plain"}">
      <summary class="post-toc__summary">
        <span class="post-toc__summary-main">
          <span class="post-toc__title">목차</span>
        </span>
        <span class="post-toc__summary-meta" aria-hidden="true"></span>
      </summary>
      <div class="post-toc__body">
        <${listTag} class="post-toc__list${includeH3 ? " post-toc__list--with-h3" : ""}${numbered ? "" : " post-toc__list--plain"}">
          ${numberedItems.map((item) => `
            <li class="post-toc__item post-toc__item--h${item.level}">
              <a href="#${escapeHtml(item.id)}">
                ${numbered ? `<span class="post-toc__index">${escapeHtml(item.indexLabel)}</span>` : ""}
                <span class="post-toc__text">${escapeHtml(item.text)}</span>
              </a>
            </li>
          `).join("")}
        </${listTag}>
      </div>
    </details>
  `;
}

function getSelectedTocMode() {
  return $("includeTocH3")?.checked ? "h2,h3" : "h2";
}

function renderPreviewTocPlaceholder(mode = "h2") {
  const label = mode === "h2,h3" ? "H2 + H3 포함" : "H2만 포함";
  return `<div class="preview-toc-placeholder"><span>목차가 여기에 표시됩니다</span><span class="preview-toc-placeholder__meta">${label}</span></div>`;
}

function insertTocTokenAtIdealPosition(md, mode = "h2") {
  const token = `[[TOC:${mode}]]`;
  const clean = stripTocTokenLines(md || "");
  if (!clean) return `${token}\n\n`;

  const lines = clean.replace(/\r/g, "").split("\n");
  const firstH2Index = lines.findIndex((line) => /^##\s+/.test(line.trim()));

  if (firstH2Index > -1) {
    const before = lines.slice(0, firstH2Index).join("\n").replace(/\s+$/, "");
    const after = lines.slice(firstH2Index).join("\n").replace(/^\s+/, "");
    return `${before}\n\n${token}\n\n${after}`.replace(/^\n+/, "").replace(/\n{3,}/g, "\n\n");
  }

  const blocks = clean.split(/\n\s*\n/).map((block) => block.trim()).filter(Boolean);
  if (blocks.length <= 1) return `${token}\n\n${clean}`;
  return `${blocks[0]}\n\n${token}\n\n${blocks.slice(1).join("\n\n")}`.replace(/\n{3,}/g, "\n\n");
}

function applyTocControls() {
  const contentEl = $("content_md");
  const statusEl = $("tocStatus");
  const enableTocEl = $("enableToc");
  if (!contentEl || !enableTocEl) return;

  if (window.StyleHotelEditor?.isActive()) {
    if (!enableTocEl.checked) {
      window.StyleHotelEditor.setTocMode(null);
      if (statusEl) statusEl.textContent = "목차가 제거되었습니다.";
      handleRealtimeChange();
      return;
    }
    const mode = getSelectedTocMode();
    const result = window.StyleHotelEditor.setTocMode(mode);
    if (!result.ok) {
      enableTocEl.checked = false;
      if (statusEl) statusEl.textContent = mode === "h2,h3" ? "호텔 본문에 H2 또는 H3 소제목이 있어야 목차를 만들 수 있습니다." : "호텔 본문에 H2 소제목이 있어야 목차를 만들 수 있습니다.";
      handleRealtimeChange();
      return;
    }
    if (statusEl) statusEl.textContent = `목차가 적용되었습니다. (${mode === "h2,h3" ? "H2 + H3" : "H2만"})`;
    handleRealtimeChange();
    return;
  }

  if (!enableTocEl.checked) {
    contentEl.value = stripTocTokenLines(contentEl.value || "");
    if (statusEl) statusEl.textContent = "목차가 제거되었습니다.";
    handleRealtimeChange();
    return;
  }

  const mode = getSelectedTocMode();
  const items = extractTocItems(contentEl.value || "", mode);
  if (!items.length) {
    enableTocEl.checked = false;
    if (statusEl) statusEl.textContent = mode === "h2,h3" ? "H2 또는 H3 소제목이 있어야 목차를 만들 수 있습니다." : "H2 소제목이 있어야 목차를 만들 수 있습니다.";
    handleRealtimeChange();
    return;
  }

  contentEl.value = insertTocTokenAtIdealPosition(contentEl.value || "", mode);
  if (statusEl) statusEl.textContent = `목차가 적용되었습니다. (${mode === "h2,h3" ? "H2 + H3" : "H2만"})`;
  handleRealtimeChange();
}

function syncTocControlsFromContent() {
  const contentEl = $("content_md");
  const enableTocEl = $("enableToc");
  const includeTocH3El = $("includeTocH3");
  if (!contentEl || !enableTocEl || !includeTocH3El) return;
  const mode = String(contentEl.value || "")
    .replace(/\r/g, "")
    .split("\n")
    .map((line) => parseTocModeFromLine(line))
    .find(Boolean) || null;
  enableTocEl.checked = !!mode;
  includeTocH3El.checked = mode === "h2,h3";
}

function parseFaqMarkdown(raw) {
  const lines = String(raw || "").replace(/\r/g, "").split("\n");
  const items = [];
  let current = null;

  const pushCurrent = () => {
    if (!current || !current.question || !current.answerLines.some((entry) => entry.trim())) return;
    items.push({
      question: current.question.trim(),
      answerMd: current.answerLines.join("\n").trim()
    });
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();
    const trimmed = line.trim();
    const prefixedQuestionMatch = trimmed.match(/^(?:#{1,6}\s*)?(?:Q|질문)\s*[.:：]?\s*(.+)$/i);
    const markdownHeadingMatch = trimmed.match(/^#{1,6}\s+(.+)$/);
    const questionText = prefixedQuestionMatch?.[1] || markdownHeadingMatch?.[1] || "";

    if (questionText) {
      pushCurrent();
      current = {
        question: String(questionText).replace(/^(?:Q|질문)\s*[.:：]?\s*/i, "").trim(),
        answerLines: []
      };
      continue;
    }

    if (!current) continue;

    // 기존 Q:/A: 입력 방식도 지원하되 A:/답변: 표식은 실제 답변에 노출하지 않는다.
    if (!current.answerLines.some((entry) => entry.trim())) {
      const answerPrefixMatch = line.match(/^\s*(?:A|답변)\s*[.:：]\s*(.*)$/i);
      if (answerPrefixMatch) {
        current.answerLines.push(answerPrefixMatch[1]);
        continue;
      }
    }

    current.answerLines.push(line);
  }

  pushCurrent();
  return items.slice(0, 8);
}

function countText(value) {
  return String(value || "").length;
}

function countTextWithoutSpaces(value) {
  return String(value || "").replace(/\s/g, "").length;
}

function setCountState(outputEl, value, min, max) {
  if (!outputEl) return;
  outputEl.classList.remove("is-good", "is-warn", "is-bad");
  if (!value) {
    outputEl.classList.add("is-bad");
    return;
  }
  if (value >= min && value <= max) {
    outputEl.classList.add("is-good");
    return;
  }
  outputEl.classList.add(value >= Math.max(1, Math.floor(min * 0.7)) ? "is-warn" : "is-bad");
}

function updateCount(inputId, outputId) {
  const inputEl = $(inputId);
  const outputEl = $(outputId);
  if (!inputEl || !outputEl) return;
  const countSource = inputId === "summary"
    ? stripMarkdown(inputEl.value)
    : (inputId === "content_md" && window.StyleHotelEditor?.isActive()
      ? window.StyleHotelEditor.getCountSource()
      : inputEl.value);
  const includedValue = countText(countSource);
  const excludedValue = countTextWithoutSpaces(countSource);
  outputEl.textContent = `공백 포함 ${includedValue}자 / 제외 ${excludedValue}자`;

  if (outputId === "titleCount") setCountState(outputEl, excludedValue, 20, 60);
  else if (outputId === "metaDescriptionCount") setCountState(outputEl, excludedValue, 70, 160);
  else outputEl.classList.remove("is-good", "is-warn", "is-bad");
}

function updateAllCounts() {
  updateCount("title", "titleCount");
  updateCount("meta_description", "metaDescriptionCount");
  updateCount("summary", "summaryCount");
  updateCount("content_md", "contentCount");
  updateCount("faq_md", "faqCount");
}

function updateSlugPreview() {
  const title = $("title").value.trim();
  $("slugPreview").value = title ? slugify(title) : "";
}

function normalizeText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function unwrapCfImageUrl(src = "") {
  const value = String(src || "").trim();
  if (!value || !value.includes("/cdn-cgi/image/")) return value;

  const marker = "/cdn-cgi/image/";
  const markerIndex = value.indexOf(marker);
  if (markerIndex < 0) return value;

  const afterMarker = value.slice(markerIndex + marker.length);
  const optionEnd = afterMarker.indexOf("/");
  if (optionEnd < 0) return value;

  const embedded = afterMarker.slice(optionEnd + 1);
  if (!embedded) return value;
  return embedded;
}

function absolutizeImageUrl(src = "") {
  const unwrapped = unwrapCfImageUrl(src);
  const value = String(unwrapped || "").trim();
  if (!value) return "";
  if (/^(data|blob):/i.test(value)) return value;
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith("//")) return `https:${value}`;
  try {
    return new URL(value, window.location.origin).toString();
  } catch (_) {
    return value;
  }
}

function sanitizeImageUrlValue(src = "") {
  return unwrapCfImageUrl(src).trim();
}

function getImageHostname(url = "") {
  try { return new URL(url).hostname.toLowerCase(); } catch (_) { return ""; }
}

function getImageBaseDomain(hostname = "") {
  const parts = String(hostname || "").toLowerCase().split(".").filter(Boolean);
  if (parts.length <= 2) return parts.join(".");
  return parts.slice(-2).join(".");
}

function isLocalImageOrigin(origin = "") {
  const host = getImageHostname(origin);
  return host === "localhost" || host === "127.0.0.1" || host.endsWith(".localhost");
}


function isImageProxyUrl(url = "") {
  const value = String(url || "").trim();
  if (!value) return false;
  try {
    const parsed = new URL(value, window.location.origin);
    return parsed.pathname.startsWith("/img/");
  } catch (_) {
    return value.startsWith("/img/") || value.includes("/img/");
  }
}

function isR2DevImageUrl(url = "") {
  const raw = String(url || "").toLowerCase();
  const normalized = unwrapCfImageUrl(raw).toLowerCase();
  const host = getImageHostname(normalized);
  return raw.includes(".r2.dev") || normalized.includes(".r2.dev") || host.endsWith(".r2.dev") || host === "r2.dev";
}

function encodeImageBase64Url(value = "") {
  const bytes = new TextEncoder().encode(String(value || ""));
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function buildImageProxyUrl(src = "") {
  const absolute = absolutizeImageUrl(src);
  if (!absolute || /^(data|blob):/i.test(absolute)) return absolute;
  if (!isR2DevImageUrl(absolute)) return absolute;
  return `${window.location.origin}/img/${encodeImageBase64Url(absolute)}`;
}

function canUseCloudflareImageTransform(absolute = "") {
  const normalized = unwrapCfImageUrl(absolute);

  // /img/*는 R2 이미지 캐시용 Pages Function 프록시 경로입니다.
  // 이 경로를 /cdn-cgi/image 원본으로 다시 넣으면 배포 환경에서 404가 발생할 수 있어
  // R2 이미지는 프록시 캐시만 사용하고 Cloudflare 이미지 변환은 적용하지 않습니다.
  if (isImageProxyUrl(normalized)) return false;

  const srcHost = getImageHostname(normalized);
  const originHost = getImageHostname(window.location.origin);
  if (!srcHost || !originHost) return false;
  if (isLocalImageOrigin(window.location.origin)) return false;
  if (srcHost === originHost) return true;
  return getImageBaseDomain(srcHost) === getImageBaseDomain(originHost);
}

function buildCfImageUrl(src = "", options = {}) {
  const raw = String(src || "").trim();
  const absolute = absolutizeImageUrl(raw);
  if (!absolute) return "";
  if (/^(data|blob):/i.test(absolute)) return absolute;
  const deliveryUrl = buildImageProxyUrl(absolute);
  if (!deliveryUrl) return "";
  if (!canUseCloudflareImageTransform(deliveryUrl)) return deliveryUrl;
  const config = { format: "auto", quality: 82, ...options };
  const params = Object.entries(config)
    .filter(([, value]) => value !== null && value !== undefined && value !== "")
    .map(([key, value]) => `${key}=${value}`)
    .join(",");
  return `/cdn-cgi/image/${params}/${deliveryUrl}`;
}

function buildImageAttrs(src = "", config = {}) {
  const widths = Array.isArray(config.widths) && config.widths.length ? config.widths : [320, 640, 960, 1200];
  const normalized = [...new Set(widths.map((value) => Math.max(1, parseInt(value, 10) || 0)).filter(Boolean))].sort((a, b) => a - b);
  const baseOptions = { fit: config.fit || "scale-down", format: config.format || "auto", quality: config.quality || 82 };
  const absolute = absolutizeImageUrl(src);
  const deliveryUrl = buildImageProxyUrl(absolute);
  const transformed = canUseCloudflareImageTransform(deliveryUrl);
  const srcset = transformed ? normalized.map((width) => `${buildCfImageUrl(src, { ...baseOptions, width })} ${width}w`).join(", ") : "";
  const fallbackWidth = config.fallbackWidth || normalized[Math.min(1, normalized.length - 1)] || 640;
  return {
    src: buildCfImageUrl(src, { ...baseOptions, width: fallbackWidth }),
    srcset,
    sizes: config.sizes || "100vw",
    original: deliveryUrl || absolute,
    directOriginal: absolute
  };
}

function renderOptimizedImageAttrs(src = "", config = {}) {
  const image = buildImageAttrs(src, config);
  const fallbackSrc = image.original || absolutizeImageUrl(src);
  const directFallbackSrc = image.directOriginal && image.directOriginal !== fallbackSrc ? image.directOriginal : "";
  return `src="${escapeHtml(image.src)}"${image.srcset ? ` srcset="${escapeHtml(image.srcset)}"` : ""} sizes="${escapeHtml(image.sizes)}" data-original-src="${escapeHtml(fallbackSrc)}"${directFallbackSrc ? ` data-direct-src="${escapeHtml(directFallbackSrc)}"` : ""} onerror="this.onerror=null;this.removeAttribute('srcset');this.src=this.dataset.originalSrc || this.dataset.directSrc;"`;
}
function getHeadings(md = "", level = 2) {
  const targetLevel = Math.min(6, Math.max(1, parseInt(level, 10) || 2));
  const re = new RegExp(`^\\s{0,3}#{${targetLevel}}\\s+(.+?)\\s*#*\\s*$`, "gm");
  const headings = [];
  let match;
  while ((match = re.exec(String(md || ""))) !== null) {
    headings.push(String(match[1] || "").replace(/\[([^\]]+)\]\([^)]*\)/g, "$1").replace(/[*_`~]/g, "").trim());
  }
  return headings.filter(Boolean);
}

function getLinks(md = "") {
  const links = [];
  const re = /(?!!)?\[[^\]]*\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g;
  let match;
  while ((match = re.exec(String(md || ""))) !== null) {
    const href = String(match[1] || "").trim();
    if (href) links.push(href);
  }
  return links;
}

function getImages(md = "") {
  const images = [];
  const re = /!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g;
  let match;
  while ((match = re.exec(String(md || ""))) !== null) {
    images.push({ alt: String(match[1] || "").trim(), src: String(match[2] || "").trim() });
  }
  return images;
}

function getFirstParagraph(md = "") {
  const blocks = String(md || "")
    .replace(/\r/g, "")
    .split(/\n\s*\n/)
    .map((block) => block.trim())
    .filter(Boolean)
    .filter((block) => !/^\s{0,3}#{1,6}\s+/.test(block))
    .filter((block) => !/^\s*\[\[(?:TOC|POST_|AFFILIATE_|STYLE_HOTEL_)/i.test(block))
    .filter((block) => !/^\s*```/.test(block));
  return stripMarkdown(blocks[0] || "");
}

function normalizeKeywordText(value = "") {
  return String(value || "").toLowerCase().replace(/[\s\-_/]+/g, "").trim();
}

function containsKeyword(text = "", keyword = "") {
  const normalizedText = normalizeKeywordText(text);
  const normalizedKeyword = normalizeKeywordText(keyword);
  return !!normalizedKeyword && normalizedText.includes(normalizedKeyword);
}

function escapeRegExp(value = "") {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function countKeywordOccurrences(text = "", keyword = "") {
  const rawKeyword = String(keyword || "").trim();
  if (!rawKeyword) return 0;
  const source = String(text || "");
  const compactSource = normalizeKeywordText(source);
  const compactKeyword = normalizeKeywordText(rawKeyword);
  if (!compactKeyword) return 0;

  let count = 0;
  let index = 0;
  while ((index = compactSource.indexOf(compactKeyword, index)) !== -1) {
    count += 1;
    index += compactKeyword.length;
  }
  return count;
}

function evaluateLongtailKeywords(textParts = [], keywords = []) {
  const source = Array.isArray(textParts) ? textParts.join("\n") : String(textParts || "");
  const items = Array.isArray(keywords) ? keywords.filter(Boolean) : [];
  const included = items.filter((keyword) => containsKeyword(source, keyword));
  const missing = items.filter((keyword) => !containsKeyword(source, keyword));
  return { total: items.length, count: included.length, included, missing };
}

function evaluateStuffing(keyword = "", plainContent = "") {
  const keywordCount = countKeywordOccurrences(plainContent, keyword);
  const contentLength = countTextWithoutSpaces(plainContent);
  const estimatedWords = Math.max(1, Math.round(contentLength / 3));
  const density = keywordCount ? (keywordCount / estimatedWords) * 100 : 0;
  let status = "good";
  if (density > 3.5 || keywordCount > 16) status = "bad";
  else if (density > 2.2 || keywordCount > 12) status = "warn";
  else if (keywordCount < 2) status = "warn";

  return {
    status,
    detail: `본문 내 ${keywordCount}회 언급 · 추정 밀도 ${density.toFixed(1)}% · 권장 1~2% 내외`
  };
}

function evaluateOtherKeywordStuffing(focusKeyword = "", plainContent = "") {
  const stopwords = new Set([
    "그리고", "그러나", "하지만", "또한", "그래서", "때문", "경우", "정도", "부분", "사용", "방법", "확인", "관리", "여행", "호텔", "오늘", "본문", "키워드", "있습니다", "합니다", "됩니다", "하면", "있는", "없는", "위해", "보다", "까지", "에서", "으로", "처럼", "이런", "저런", "대한", "관련"
  ]);
  const focus = normalizeKeywordText(focusKeyword);
  const words = String(plainContent || "")
    .replace(/[A-Za-z0-9_가-힣]+/g, (word) => ` ${word} `)
    .split(/[^A-Za-z0-9_가-힣]+/)
    .map((word) => word.trim())
    .filter((word) => word.length >= 2)
    .filter((word) => !stopwords.has(word))
    .filter((word) => normalizeKeywordText(word) !== focus);

  const counts = new Map();
  words.forEach((word) => counts.set(word, (counts.get(word) || 0) + 1));
  const top = [...counts.entries()]
    .filter(([, count]) => count >= 4)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  if (!top.length) {
    return { status: "good", detail: "반복 가능 키워드가 발견되지 않았습니다." };
  }

  const maxCount = top[0][1];
  return {
    status: maxCount >= 12 ? "bad" : maxCount >= 7 ? "warn" : "good",
    detail: `Top5: ${top.map(([word, count]) => `${word} ${count}회`).join(" | ")}`
  };
}

function getImageSeoData(contentMd, coverImage, coverImageAlt, focusKeyword, inlineImages = {}) {
  const bodyImages = [
    ...getImages(contentMd),
    ...getInlineImageItems(inlineImages).map((item) => ({ url: item.url || item.id || "", alt: item.alt || "" })),
    ...(window.StyleHotelEditor?.isActive() ? window.StyleHotelEditor.getImages() : [])
  ];
  const bodyImagesWithoutAlt = bodyImages.filter((img) => !img.alt).length;
  const bodyAlts = bodyImages.map((img) => img.alt).filter(Boolean);
  const hasCoverImage = !!String(coverImage || "").trim();
  const hasCoverAlt = !!String(coverImageAlt || "").trim();
  const allAlts = [
    ...(hasCoverAlt ? [String(coverImageAlt).trim()] : []),
    ...bodyAlts
  ];
  const totalImages = bodyImages.length + (hasCoverImage ? 1 : 0);
  const missingAltCount = bodyImagesWithoutAlt + (hasCoverImage && !hasCoverAlt ? 1 : 0);
  const keywordIncludedInAlt = focusKeyword
    ? allAlts.some((alt) => containsKeyword(alt, focusKeyword))
    : false;

  let status = "warn";
  let detail = "대표 이미지나 본문 이미지가 없습니다.";
  if (totalImages > 0) {
    status = missingAltCount === 0 ? "good" : "bad";
    detail = `대표 이미지 ${hasCoverImage ? 1 : 0}개${hasCoverImage ? ` · ALT ${hasCoverAlt ? "입력 완료" : "누락"}` : ""} · 본문 이미지 ${bodyImages.length}개 · ALT 누락 ${bodyImagesWithoutAlt}개`;
  }

  return {
    totalImages,
    hasCoverImage,
    hasCoverAlt,
    bodyImages,
    bodyImagesWithoutAlt,
    keywordIncludedInAlt,
    status,
    detail
  };
}

function groupSeoChecks(checks) {
  const order = ["basic", "keywords", "structure", "media"];
  const grouped = {
    basic: [],
    keywords: [],
    structure: [],
    media: []
  };

  checks.forEach((item) => {
    const key = grouped[item.group] ? item.group : "basic";
    grouped[key].push(item);
  });

  return order
    .map((key) => {
      const items = grouped[key];
      const baseLabel = key === "basic" ? "기본" : key === "keywords" ? "키워드" : key === "structure" ? "구조/링크" : "이미지/FAQ";
      const hasPassingItem = items.some((item) => item.status === "good");
      return {
        key,
        label: hasPassingItem ? baseLabel : `${baseLabel} !`,
        items
      };
    })
    .filter((group) => group.items.length);
}

function evaluateSeo() {
  const title = $("title").value.trim();
  const slug = $("slugPreview").value.trim();
  const metaDescription = $("meta_description").value.trim();
  const summary = $("summary").value.trim();
  const plainSummary = stripMarkdown(summary);
  const contentMd = stripLsiKeywordsTokenLines($("content_md").value || "");
  const inlineImages = collectInlineImageFormData();
  const affiliateMeta = collectAffiliateFormData();
  const affiliateCtaMeta = collectAffiliateCtaFormData();
  const contentLengthWithoutSpaces = countTextWithoutSpaces(contentMd);
  const showPreviewAds = shouldShowInarticleAdsInEditor();
  const previewAdPositions = showPreviewAds ? getPreviewAdInsertPositions(contentMd, contentLengthWithoutSpaces) : [];
  const faqMd = $("faq_md")?.value || "";
  const faqItems = parseFaqMarkdown(faqMd);
  const focusKeyword = $("focusKeyword")?.value.trim() || "";
  const longtailKeywords = parseKeywords($("longtailKeywords")?.value || "");
  const lsiKeywords = parseKeywords($("lsiKeywords")?.value || "");
  const coverData = collectCoverImageFormData();
  const coverImage = coverData.ok ? coverData.image : "";
  const coverImageAlt = $("cover_image_alt")?.value.trim() || "";

  const plainContent = stripMarkdown(contentMd);
  const titleLen = countText(title);
  const metaLen = countText(metaDescription);
  const summaryLen = countText(plainSummary);
  const contentLen = countText(plainContent);
  const bodyH1List = getHeadings(contentMd, 1);
  const h2List = getHeadings(contentMd, 2);
  const h3List = getHeadings(contentMd, 3);
  const links = getLinks(contentMd);
  const internalLinks = links.filter((href) => href.startsWith("/")).length;
  const externalLinks = links.filter((href) => /^https?:\/\//.test(href)).length;
  const imageSeo = getImageSeoData(contentMd, coverImage, coverImageAlt, focusKeyword, inlineImages);
  const firstParagraph = getFirstParagraph(contentMd);
  const keywordInTitle = focusKeyword ? containsKeyword(title, focusKeyword) : false;
  const keywordInMeta = focusKeyword ? containsKeyword(metaDescription, focusKeyword) : false;
  const keywordInSummary = focusKeyword ? containsKeyword(plainSummary, focusKeyword) : false;
  const keywordInSlug = focusKeyword ? containsKeyword(slug, slugify(focusKeyword)) : false;
  const keywordInFirstParagraph = focusKeyword ? containsKeyword(firstParagraph, focusKeyword) : false;
  const h2KeywordCount = focusKeyword ? h2List.filter((h) => containsKeyword(h, focusKeyword)).length : 0;
  const h3KeywordCount = focusKeyword ? h3List.filter((h) => containsKeyword(h, focusKeyword)).length : 0;
  const keywordInH2 = h2KeywordCount > 0;
  const keywordCount = focusKeyword ? countKeywordOccurrences(plainContent, focusKeyword) : 0;
  const longtailResult = evaluateLongtailKeywords(
    [plainContent],
    longtailKeywords
  );
  const lsiResult = evaluateLongtailKeywords(
    [plainContent],
    lsiKeywords
  );
  const stuffingResult = evaluateStuffing(focusKeyword, plainContent);
  const otherStuffingResult = evaluateOtherKeywordStuffing(focusKeyword, plainContent);

  const checks = [
    {
      key: "titleLength",
      group: "basic",
      label: "제목 길이",
      status: titleLen >= 20 && titleLen <= 60 ? "good" : titleLen >= 14 ? "warn" : "bad",
      detail: `현재 ${titleLen}자 · 권장 20~60자`
    },
    {
      key: "metaLength",
      group: "basic",
      label: "메타 디스크립션 길이",
      status: metaLen >= 70 && metaLen <= 160 ? "good" : metaLen >= 40 ? "warn" : "bad",
      detail: `현재 ${metaLen}자 · 권장 70~160자`
    },
    {
      key: "summaryLength",
      group: "basic",
      label: "요약문 길이",
      status: summaryLen >= 40 && summaryLen <= 140 ? "good" : summaryLen >= 20 ? "warn" : "bad",
      detail: `현재 ${summaryLen}자 · 권장 40~140자`
    },
    {
      key: "contentLength",
      group: "basic",
      label: "본문 길이",
      status: contentLen >= 1200 ? "good" : contentLen >= 500 ? "warn" : "bad",
      detail: `현재 ${contentLen}자 · 권장 1,200자 이상`
    },
    {
      key: "h1Count",
      group: "structure",
      label: "H1 구조",
      status: title ? (bodyH1List.length === 0 ? "good" : "warn") : "bad",
      detail: title
        ? bodyH1List.length === 0
          ? "제목 입력값이 공개 페이지의 H1로 사용됩니다. 본문 내 추가 H1이 없어 좋습니다."
          : `제목이 H1로 사용되며, 본문에 H1이 ${bodyH1List.length}개 더 있어 보완이 필요합니다.`
        : "제목이 비어 있어 공개 페이지 H1이 없습니다."
    },
    {
      key: "h2Count",
      group: "structure",
      label: "H2 소제목 구조",
      status: h2List.length >= 2 ? "good" : h2List.length === 1 ? "warn" : "bad",
      detail: `현재 ${h2List.length}개 · 권장 2개 이상`
    },
    {
      key: "h3Count",
      group: "structure",
      label: "H3 소제목 구조",
      status: h3List.length >= 2 ? "good" : "warn",
      detail: `현재 ${h3List.length}개 · 세부 구조 정리에 도움`
    },
    {
      key: "faqCount",
      group: "media",
      label: "FAQ 입력 여부",
      status: faqItems.length >= 4 ? "good" : faqItems.length >= 1 ? "warn" : "warn",
      detail: faqItems.length
        ? `FAQ ${faqItems.length}개 인식됨 · 입력된 FAQ만 공개 페이지와 FAQPage JSON-LD에 반영됩니다.`
        : "FAQ를 입력하지 않으면 FAQ 섹션과 FAQPage JSON-LD가 생성되지 않습니다."
    },
    {
      key: "imageAlt",
      group: "media",
      label: "이미지 ALT 텍스트",
      status: imageSeo.status,
      detail: imageSeo.detail
    }
  ];

  if (!focusKeyword) {
    checks.push(
      {
        key: "focusKeywordMissing",
        group: "keywords",
        label: "메인 키워드 설정",
        status: "bad",
        detail: "메인 키워드를 입력해야 핵심 SEO 점검이 활성화됩니다."
      },
      {
        key: "otherKeywordStuffing",
        group: "keywords",
        label: "메인 키워드 제외 스터핑 키워드",
        status: otherStuffingResult.status,
        detail: otherStuffingResult.detail
      }
    );
  } else {
    checks.push(
      {
        key: "keywordTitle",
        group: "keywords",
        label: "메인 키워드 - 제목 포함",
        status: keywordInTitle ? "good" : "bad",
        detail: keywordInTitle ? "제목에 메인 키워드가 포함되어 있습니다." : "제목에 메인 키워드를 포함하세요."
      },
      {
        key: "keywordMeta",
        group: "keywords",
        label: "메인 키워드 - 메타 디스크립션 포함",
        status: keywordInMeta ? "good" : "warn",
        detail: keywordInMeta ? "메타 디스크립션에 메인 키워드가 포함되어 있습니다." : "메타 디스크립션에 메인 키워드를 넣어보세요."
      },
      {
        key: "keywordSummary",
        group: "keywords",
        label: "메인 키워드 - 요약문 포함",
        status: keywordInSummary ? "good" : "warn",
        detail: keywordInSummary ? "요약문에 메인 키워드가 포함되어 있습니다." : "요약문에도 메인 키워드를 자연스럽게 넣어보세요."
      },
      {
        key: "keywordSlug",
        group: "keywords",
        label: "메인 키워드 - 슬러그 포함",
        status: keywordInSlug ? "good" : "warn",
        detail: keywordInSlug ? "슬러그에도 키워드가 반영되어 있습니다." : "슬러그에 키워드가 드러나면 더 좋습니다."
      },
      {
        key: "keywordIntro",
        group: "keywords",
        label: "메인 키워드 - 첫 문단 포함",
        status: keywordInFirstParagraph ? "good" : "bad",
        detail: keywordInFirstParagraph ? "첫 문단에 메인 키워드가 포함되어 있습니다." : "첫 문단 초반에 메인 키워드를 포함하세요."
      },
      {
        key: "keywordH2",
        group: "keywords",
        label: "메인 키워드 - 소제목 포함",
        status: keywordInH2 ? "good" : "warn",
        detail: keywordInH2 ? "H2 소제목에 키워드가 반영되어 있습니다." : "H2 소제목 중 하나에 키워드를 포함하면 좋습니다."
      },
      {
        key: "keywordHeadingCoverage",
        group: "structure",
        label: "H2/H3 메인 키워드 포함 수",
        status: (h2KeywordCount + h3KeywordCount) >= 2 ? "good" : (h2KeywordCount + h3KeywordCount) >= 1 ? "warn" : "bad",
        detail: `H2 ${h2List.length}개 중 ${h2KeywordCount}개 · H3 ${h3List.length}개 중 ${h3KeywordCount}개에 메인 키워드가 포함되어 있습니다.`
      },
      {
        key: "keywordDensityStuffing",
        group: "keywords",
        label: "메인 키워드 밀도 및 키워드 스터핑",
        status: keywordCount >= 3 && keywordCount <= 12
          ? stuffingResult.status
          : (keywordCount >= 1 ? (stuffingResult.status === "bad" ? "bad" : "warn") : "bad"),
        detail: `${keywordCount}회 언급 · ${stuffingResult.detail.replace(/^본문 내\s*/, "")}`
      },
      {
        key: "otherKeywordStuffing",
        group: "keywords",
        label: "메인 키워드 제외 스터핑 키워드",
        status: otherStuffingResult.status,
        detail: otherStuffingResult.detail
      }
    );
  }

  if (!longtailKeywords.length) {
    checks.push({
      key: "longtailKeywords",
      group: "keywords",
      label: "롱테일 키워드 설정",
      status: "warn",
      detail: "롱테일 키워드를 콤마로 입력하면 포함 여부를 함께 점검합니다."
    });
  } else {
    checks.push({
      key: "longtailCoverage",
      group: "keywords",
      label: "롱테일 키워드 본문 포함 여부",
      status: longtailResult.count === longtailResult.total ? "good" : longtailResult.count >= 1 ? "warn" : "bad",
      detail: longtailResult.count === longtailResult.total
        ? `${longtailResult.total}개 모두 본문에 포함되었습니다.`
        : `총 ${longtailResult.total}개 중 ${longtailResult.count}개 포함 · 미포함: ${longtailResult.missing.join(", ")}`
    });
  }

  if (!lsiKeywords.length) {
    checks.push({
      key: "lsiKeywords",
      group: "keywords",
      label: "LSI 키워드 설정",
      status: "warn",
      detail: "LSI 키워드를 콤마로 입력하면 본문 포함 개수를 함께 점검합니다."
    });
  } else {
    checks.push({
      key: "lsiCoverage",
      group: "keywords",
      label: "LSI 키워드 본문 포함 개수",
      status: lsiResult.count === lsiResult.total ? "good" : lsiResult.count >= 1 ? "warn" : "bad",
      detail: lsiResult.count === lsiResult.total
        ? `총 ${lsiResult.total}개 중 ${lsiResult.count}개 포함되었습니다.`
        : `총 ${lsiResult.total}개 중 ${lsiResult.count}개 포함 · 미포함: ${lsiResult.missing.join(", ")}`
    });
  }

  return checks;
}

function getScoreSummary(checks) {
  const weights = { good: 10, warn: 6, bad: 0 };
  const total = checks.reduce((sum, item) => sum + (weights[item.status] || 0), 0);
  const max = checks.length * 10 || 10;
  const score = Math.round((total / max) * 100);

  let grade = "점검 필요";
  if (score >= 85) grade = "매우 좋음";
  else if (score >= 70) grade = "좋음";
  else if (score >= 50) grade = "보통";

  return { score, grade };
}

function getSeoStatusLabel(status) {
  return status === "good" ? "통과" : status === "warn" ? "보완" : "부족";
}

function getSeoDetailModel(item) {
  const detail = String(item?.detail || "").trim();
  const label = String(item?.label || "");

  const makeTextList = (parts) => ({
    lines: parts.filter(Boolean).map((part) => ({ text: part }))
  });

  if (!detail) return makeTextList(["결과 없음"]);

  if (label === "메인 키워드 밀도 및 키워드 스터핑") {
    const countMatch = detail.match(/(\d+)회 언급/);
    const densityMatch = detail.match(/추정 밀도\s*([\d.]+%)/);
    const rangeMatch = detail.match(/(권장\s*[^·]+)/);
    return {
      lines: [
        countMatch ? { text: `메인 키워드 언급 횟수: ${countMatch[1]}회` } : null,
        densityMatch ? { text: `추정 밀도: ${densityMatch[1]}` } : null,
        rangeMatch ? { text: rangeMatch[1] } : null
      ].filter(Boolean)
    };
  }

  if (label === "메인 키워드 제외 스터핑 키워드") {
    if (/없음|발견되지 않았습니다/.test(detail)) {
      return makeTextList(["반복 키워드 Top 5 없음"]);
    }

    const raw = detail.replace(/^Top5:\s*/, "").trim();
    const items = raw
      .split(/\s*\|\s*|\s*·\s*/g)
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => {
        const match = part.match(/(.+?)\s+(\d+)회$/);
        return match ? { keyword: match[1].trim(), count: match[2] } : null;
      })
      .filter(Boolean);

    return {
      lines: [{ text: "반복 키워드 Top 5" }],
      topKeywords: items
    };
  }

  if (label === "롱테일 키워드 본문 포함 여부" || label === "LSI 키워드 본문 포함 개수") {
    if (!detail.includes("미포함:")) {
      return makeTextList([detail]);
    }

    const [summary, missingPart] = detail.split("미포함:");
    const missing = String(missingPart || "")
      .split(",")
      .map((part) => part.trim())
      .filter(Boolean);

    return {
      lines: [{ text: summary.replace(/·\s*$/, "").trim() }],
      missingTitle: "미포함 키워드",
      missing
    };
  }

  return makeTextList([detail]);
}

function renderSeoDetailList(item) {
  const model = getSeoDetailModel(item);
  const lines = Array.isArray(model?.lines) ? model.lines : [];
  const topKeywords = Array.isArray(model?.topKeywords) ? model.topKeywords : [];
  const missing = Array.isArray(model?.missing) ? model.missing : [];
  const missingTitle = model?.missingTitle || "";

  const baseList = lines.length
    ? `<ul class="seo-check__summary-list">${lines.map((row) => `<li>${escapeHtml(row.text || "")}</li>`).join("")}</ul>`
    : "";

  const topKeywordHtml = topKeywords.length
    ? `
      <div class="seo-check__subsection">
        <ul class="seo-check__summary-list seo-check__summary-list--nested">
          ${topKeywords.map((item) => `<li>${escapeHtml(item.keyword)} · ${escapeHtml(String(item.count))}회</li>`).join("")}
        </ul>
      </div>
    `
    : "";

  const missingHtml = missing.length
    ? `
      <div class="seo-check__subsection">
        <div class="seo-check__subheading">${escapeHtml(missingTitle)}</div>
        <ul class="seo-check__summary-list seo-check__summary-list--nested">
          ${missing.map((keyword) => `<li>${escapeHtml(keyword)}</li>`).join("")}
        </ul>
      </div>
    `
    : "";

  return `${baseList}${topKeywordHtml}${missingHtml}`;
}

function renderSeoKeywordChecklist(items) {
  const keywordGroups = [];
  const standaloneItems = [];
  const map = new Map();

  items.forEach((item) => {
    const parts = String(item.label || "").split(" - ");
    if (parts.length >= 2) {
      const title = parts[0].trim();
      const subLabel = parts.slice(1).join(" - ").trim();
      if (!map.has(title)) {
        const group = { title, rows: [] };
        map.set(title, group);
        keywordGroups.push(group);
      }
      map.get(title).rows.push({
        label: subLabel,
        status: item.status,
        detail: item.detail
      });
      return;
    }
    standaloneItems.push(item);
  });

  const groupHtml = keywordGroups.map((group) => `
    <div class="seo-check seo-check--grouped">
      <div class="seo-check__head seo-check__head--stacked">
        <strong>${group.title}</strong>
      </div>
      <div class="seo-check__rows">
        ${group.rows.map((row) => `
          <div class="seo-check__row seo-check__row--${row.status}">
            <span class="seo-check__row-label">- ${row.label}</span>
            <span class="seo-check__row-status seo-check__row-status--${row.status}">${getSeoStatusLabel(row.status)}</span>
          </div>
        `).join("")}
      </div>
    </div>
  `).join("");

  const standaloneHtml = standaloneItems.map((item) => `
    <div class="seo-check seo-check--${item.status}">
      <div class="seo-check__head">
        <strong>${item.label}</strong>
        <span class="seo-pill seo-pill--${item.status}">${getSeoStatusLabel(item.status)}</span>
      </div>
      <div class="seo-check__summary">${renderSeoDetailList(item)}</div>
    </div>
  `).join("");

  return groupHtml + standaloneHtml;
}

function renderSeoChecklist(activeGroupKey) {
  const tabsWrap = $("seoTabs");
  const wrap = $("seoChecklist");
  const scoreEl = $("seoScore");
  const gradeEl = $("seoGrade");
  if (!wrap || !scoreEl || !gradeEl) return;

  const checks = evaluateSeo();
  const groups = groupSeoChecks(checks);
  const selectedGroup = groups.find((group) => group.key === activeGroupKey) || groups[0];
  const { score, grade } = getScoreSummary(checks);

  scoreEl.textContent = String(score);
  gradeEl.textContent = grade;
  scoreEl.dataset.grade = grade;

  if (tabsWrap) {
    tabsWrap.innerHTML = groups.map((group) => `
      <button class="seo-tab ${selectedGroup && selectedGroup.key === group.key ? "is-active" : ""}" type="button" data-seo-group="${group.key}">${group.label}</button>
    `).join("");

    tabsWrap.querySelectorAll("[data-seo-group]").forEach((button) => {
      button.addEventListener("click", () => renderSeoChecklist(button.dataset.seoGroup || "basic"));
    });
  }

  if ((selectedGroup?.key || "") === "keywords") {
    wrap.innerHTML = renderSeoKeywordChecklist(selectedGroup?.items || []);
    return;
  }

  wrap.innerHTML = (selectedGroup?.items || checks).map((item) => {
    const icon = getSeoStatusLabel(item.status);
    return `
      <div class="seo-check seo-check--${item.status}">
        <div class="seo-check__head">
          <strong>${item.label}</strong>
          <span class="seo-pill seo-pill--${item.status}">${icon}</span>
        </div>
        <div class="small">${item.detail}</div>
      </div>
    `;
  }).join("");
}

function inlineFormat(text) {
  return escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, "<code>$1</code>")
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}

function normalizeArticleHeadingText(level, text = "") {
  const raw = String(text || "").trim();
  if (level === 2 || level === 3) {
    return raw.replace(/^\d{1,2}[.)]\s+/, "");
  }
  return raw;
}

function renderHeadingText(level, text = "") {
  const normalized = normalizeArticleHeadingText(level, text);
  if (level !== 2) return inlineFormat(normalized);

  const raw = normalized;
  const match = raw.match(/^([^:：]{1,30}[:：])\s*(.+)$/);
  if (!match) {
    return `<span class="post-h2-text">${inlineFormat(raw)}</span>`;
  }

  return `<span class="post-h2-prefix">${inlineFormat(match[1])}</span><span class="post-h2-text">${inlineFormat(match[2])}</span>`;
}


function splitMarkdownTableRow(row = "") {
  let value = String(row || "").trim();
  if (value.startsWith("|")) value = value.slice(1);
  if (value.endsWith("|")) value = value.slice(0, -1);
  return value.split("|").map((cell) => cell.trim());
}

function isMarkdownTableSeparatorRow(row = "") {
  const cells = splitMarkdownTableRow(row);
  if (!cells.length) return false;
  return cells.every((cell) => /^:?-+:?$/.test(cell));
}

function getMarkdownTableAlignments(row = "") {
  return splitMarkdownTableRow(row).map((cell) => {
    const left = cell.startsWith(":");
    const right = cell.endsWith(":");
    if (left && right) return "center";
    if (right) return "right";
    if (left) return "left";
    return "";
  });
}

function renderMarkdownTableFromLines(lines = []) {
  if (lines.length < 2) return "";
  const headerCells = splitMarkdownTableRow(lines[0]);
  const alignments = getMarkdownTableAlignments(lines[1]);
  const bodyRows = lines.slice(2).map((line) => splitMarkdownTableRow(line));

  const thead = `<thead><tr>${headerCells.map((cell, index) => {
    const align = alignments[index] || "";
    const alignClass = align ? ` table-cell--${align}` : "";
    return `<th class="table-cell${alignClass}">${inlineFormat(cell)}</th>`;
  }).join("")}</tr></thead>`;

  const tbody = bodyRows.length
    ? `<tbody>${bodyRows.map((row) => `<tr>${headerCells.map((_, index) => {
        const align = alignments[index] || "";
        const alignClass = align ? ` table-cell--${align}` : "";
        const cell = row[index] ?? "";
        return `<td class="table-cell${alignClass}">${inlineFormat(cell)}</td>`;
      }).join("")}</tr>`).join("")}</tbody>`
    : "";

  return `<div class="table-wrap"><table>${thead}${tbody}</table></div>`;
}

function isMarkdownTableBodyRow(line = "") {
  const value = String(line || "").trim();
  if (!value || !value.includes("|")) return false;
  if (/^(#{1,6})\s+/.test(value)) return false;
  if (/^>\s?/.test(value)) return false;
  if (/^[-*]\s+/.test(value)) return false;
  if (/^\d+\.\s+/.test(value)) return false;
  if (parseTocModeFromLine(value)) return false;
  if (/^!\[[^\]]*\]\([^)]+\)$/.test(value)) return false;
  if (parseInlineImageToken(value) || parseAffiliateToken(value)) return false;
  return true;
}

function getPreviewAdInsertPositions(md, contentLengthWithoutSpaces) {
  const lines = String(md || '').replace(/\r/g, '').split('\n');
  const h2Lines = [];
  let nonEmptyCount = 0;
  lines.forEach((line, index) => {
    const trimmed = line.trim();
    if (!trimmed) return;
    nonEmptyCount += 1;
    if (/^##\s+/.test(trimmed)) h2Lines.push(index);
  });

  const positions = [];
  if (h2Lines.length) {
    positions.push(h2Lines[0]);
    if (contentLengthWithoutSpaces >= 2000 && h2Lines.length >= 3) positions.push(h2Lines[2]);
    return positions;
  }

  if (nonEmptyCount > 0) {
    positions.push(Math.max(1, Math.floor(nonEmptyCount * 0.42)));
    if (contentLengthWithoutSpaces >= 2000) positions.push(Math.max(2, Math.floor(nonEmptyCount * 0.74)));
  }
  return positions;
}

function renderPreviewAdBox(index) {
  return `
    <div class="post-ad post-ad--inline post-ad--placeholder" aria-label="본문 광고 ${index + 1}">
      <div class="post-ad__placeholder-title">본문 광고 ${index + 1}</div>
      <div class="small">실제 페이지에서는 화면 근처에서만 지연 로드됩니다.</div>
    </div>
  `;
}

function isHotelReviewSectionLabelHtml(html = "") {
  const match = String(html || "").trim().match(/^<p>\s*<strong>([\s\S]+?)<\/strong>\s*<\/p>$/i);
  if (!match) return false;
  const labelText = match[1]
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/gi, " ")
    .trim();
  return /^\d{1,2}[.)]\s+.{1,80}$/.test(labelText);
}


const STYLE_HOTEL_IMAGE_TOKEN_RE = /^\[\[STYLE_HOTEL_IMAGE\s+(.+?)\]\]$/i;
const STYLE_HOTEL_BUTTON_TOKEN_RE = /^\[\[STYLE_HOTEL_BUTTON\s+(.+?)\]\]$/i;
const STYLE_HOTEL_ENDING_TOKEN_RE = /^\[\[STYLE_HOTEL_ENDING\]\]$/i;

function parseStyleHotelTokenAttributes(raw = "") {
  const attrs = {};
  const re = /(\w+)="([^"]*)"/g;
  let match;
  while ((match = re.exec(String(raw || ""))) !== null) attrs[match[1]] = match[2];
  return attrs;
}

function decodeStyleHotelTokenValue(value = "") {
  try { return decodeURIComponent(String(value || "")); } catch (_) { return String(value || ""); }
}

function parseStyleHotelImageToken(line = "") {
  const match = String(line || "").trim().match(STYLE_HOTEL_IMAGE_TOKEN_RE);
  if (!match) return null;
  const attrs = parseStyleHotelTokenAttributes(match[1]);
  return {
    source: String(attrs.source || "r2").toLowerCase() === "agoda" ? "agoda" : "r2",
    image: decodeStyleHotelTokenValue(attrs.image || attrs.url || ""),
    srcset: decodeStyleHotelTokenValue(attrs.srcset || ""),
    link: decodeStyleHotelTokenValue(attrs.link || ""),
    alt: decodeStyleHotelTokenValue(attrs.alt || ""),
    starRating: decodeStyleHotelTokenValue(attrs.star || ""),
    guestRating: decodeStyleHotelTokenValue(attrs.rating || ""),
    badge: decodeStyleHotelTokenValue(attrs.badge || ""),
    imageBadge: decodeStyleHotelTokenValue(attrs.image_badge || attrs.imageBadge || "")
  };
}

function parseStyleHotelButtonToken(line = "") {
  const match = String(line || "").trim().match(STYLE_HOTEL_BUTTON_TOKEN_RE);
  if (!match) return null;
  const attrs = parseStyleHotelTokenAttributes(match[1]);
  return {
    buttonText: decodeStyleHotelTokenValue(attrs.text || attrs.button || "예약 가능 객실 확인"),
    linkUrl: decodeStyleHotelTokenValue(attrs.link || attrs.url || "")
  };
}

function stripStyleHotelTokenLines(md = "") {
  return String(md || "")
    .split("\n")
    .filter((line) => !STYLE_HOTEL_IMAGE_TOKEN_RE.test(line.trim()) && !STYLE_HOTEL_BUTTON_TOKEN_RE.test(line.trim()) && !STYLE_HOTEL_ENDING_TOKEN_RE.test(line.trim()))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function normalizeStyleHotelPreviewBadges(raw = "") {
  return Array.from(new Set(
    String(raw || "")
      .split(/[,，]/)
      .map((item) => item.replace(/\s+/g, " ").trim().slice(0, 40))
      .filter(Boolean)
  )).slice(0, 8);
}

function renderStyleHotelPreviewMeta(data = {}) {
  const star = ["3", "4", "5"].includes(String(data.starRating || "").trim())
    ? `${String(data.starRating).trim()}성급`
    : "";
  const rating = /^(?:6\.5|7\.0|7\.5|8\.0|8\.5|9\.0|9\.5)\+$/.test(String(data.guestRating || "").trim())
    ? String(data.guestRating).trim()
    : "";
  const items = [];
  if (star) items.push(`<span class="preview-style-hotel-meta__item preview-style-hotel-meta__item--star">${escapeHtml(star)}</span>`);
  if (star && rating) items.push('<span class="preview-style-hotel-meta__separator" aria-hidden="true">|</span>');
  if (rating) items.push(`<span class="preview-style-hotel-meta__item preview-style-hotel-meta__item--rating"><span aria-hidden="true">★</span>${escapeHtml(rating)}</span>`);
  return items.length ? `<div class="preview-style-hotel-meta" aria-label="호텔 성급 및 평점">${items.join("")}</div>` : "";
}

function renderStyleHotelPreviewBadges(data = {}) {
  const badges = normalizeStyleHotelPreviewBadges(data.badge);
  if (!badges.length) return "";
  return `<p class="preview-style-hotel-badges" aria-label="호텔 특징">${badges.map((badge) => escapeHtml(badge)).join('<span class="preview-style-hotel-badges__separator" aria-hidden="true">|</span>')}</p>`;
}

function renderStyleHotelPreviewImageBadge(data = {}) {
  const text = String(data.imageBadge || "").replace(/\s+/g, " ").trim().slice(0, 40);
  return text ? `<span class="preview-style-hotel-image-badge">${escapeHtml(text)}</span>` : "";
}

function renderStyleHotelPreviewImage(data = {}) {
  const imageUrl = String(data.image || "").trim();
  if (!imageUrl) return "";
  const alt = String(data.alt || "호텔 이미지").trim();
  if (data.source === "agoda") {
    const image = `<img src="${escapeHtml(imageUrl)}"${data.srcset ? ` srcset="${escapeHtml(data.srcset)}"` : ""} sizes="(max-width: 760px) 100vw, 760px" alt="${escapeHtml(alt)}" loading="lazy" decoding="async">`;
    const linked = data.link
      ? `<a class="preview-inline-image__link" href="${escapeHtml(data.link)}" target="_blank" rel="sponsored noopener noreferrer">${image}</a>`
      : image;
    return `<figure class="preview-inline-image preview-inline-image--agoda style-hotel-preview-image">${linked}${renderStyleHotelPreviewImageBadge(data)}</figure>${renderStyleHotelPreviewMeta(data)}`;
  }
  return `<figure class="preview-inline-image style-hotel-preview-image"><img ${renderOptimizedImageAttrs(imageUrl, { widths: [480, 768, 960, 1200], sizes: "(max-width: 760px) 100vw, 760px", fallbackWidth: 960, fit: "scale-down", quality: 85 })} alt="${escapeHtml(alt)}" loading="lazy" decoding="async">${renderStyleHotelPreviewImageBadge(data)}</figure>${renderStyleHotelPreviewMeta(data)}`;
}

function markdownToHtml(md, options = {}) {
  const inlineImages = options.inlineImages || parseInlineImageMetaFromMarkdown(md);
  const affiliates = options.affiliates || parseAffiliateMetaFromMarkdown(md);
  const affiliateCta = normalizeAffiliateCtaMeta(options.affiliateCta || parseAffiliateCtaMetaFromMarkdown(md));
  const sourceMd = stripAffiliateCtaTokenLines(stripAffiliateTokenLines(stripInlineImageTokenLines(String(md || "").replace(/\r/g, ""))));
  const lines = sourceMd.split("\n");
  const tocModeInContent = lines.map((line) => parseTocModeFromLine(line)).find(Boolean) || null;
  const tocItems = tocModeInContent ? extractTocItems(sourceMd, tocModeInContent) : [];
  const htmlParts = [];
  let inUl = false;
  let inOl = false;
  let inBlockquote = false;
  const slugCounts = new Map();
  const adPositions = Array.isArray(options.adPositions) ? [...options.adPositions] : [];
  let contentBlockCount = 0;
  let adPointer = 0;
  let h2Count = 0;
  const useHotelSectionLabelAnchor = options.hotelReviewSectionImageAnchor === true;
  let activeAffiliateCtaItems = [];
  let pendingStyleHotelHeadingData = null;
  let skipStyleHotelLeadList = false;
  let styleHotelEndingOpen = false;

  function maybeInsertAd() {
    while (options.showAds && adPointer < adPositions.length && adPositions[adPointer] === contentBlockCount) {
      htmlParts.push(renderPreviewAdBox(adPointer));
      adPointer += 1;
    }
  }

  function closeLists() {
    if (inUl) {
      htmlParts.push("</ul>");
      inUl = false;
    }
    if (inOl) {
      htmlParts.push("</ol>");
      inOl = false;
    }
  }

  function closeQuote() {
    if (inBlockquote) {
      htmlParts.push("</blockquote>");
      inBlockquote = false;
    }
  }

  function pushContentBlock(html) {
    maybeInsertAd();
    htmlParts.push(html);
    contentBlockCount += 1;
  }

  function maybeInsertAffiliateCtaAtSectionEnd() {
    if (!activeAffiliateCtaItems.length) return;
    activeAffiliateCtaItems.forEach((item) => {
      const ctaHtml = renderAffiliateCtaPreviewButton(item);
      if (ctaHtml) pushContentBlock(ctaHtml);
    });
    activeAffiliateCtaItems = [];
  }

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const rawLine = lines[lineIndex];
    const line = rawLine.trim();

    if (!line) {
      closeLists();
      closeQuote();
      continue;
    }

    if (skipStyleHotelLeadList && /^[-*]\s+(.+)$/.test(line)) {
      closeLists();
      closeQuote();
      continue;
    }
    if (skipStyleHotelLeadList) skipStyleHotelLeadList = false;

    const styleHotelImage = parseStyleHotelImageToken(line);
    if (styleHotelImage) {
      closeLists();
      closeQuote();
      pendingStyleHotelHeadingData = styleHotelImage;
      skipStyleHotelLeadList = false;
      const imageHtml = renderStyleHotelPreviewImage(styleHotelImage);
      if (imageHtml) pushContentBlock(imageHtml);
      continue;
    }

    const styleHotelButton = parseStyleHotelButtonToken(line);
    if (styleHotelButton) {
      closeLists();
      closeQuote();
      const buttonHtml = renderAffiliateCtaPreviewButton({ ...styleHotelButton, enabled: true, position: 1 });
      if (buttonHtml) pushContentBlock(buttonHtml);
      continue;
    }

    if (STYLE_HOTEL_ENDING_TOKEN_RE.test(line)) {
      closeLists();
      closeQuote();
      if (!styleHotelEndingOpen) {
        htmlParts.push('<section class="preview-style-hotel-ending">');
        styleHotelEndingOpen = true;
      }
      continue;
    }

    const tocMode = parseTocModeFromLine(line);
    if (tocMode) {
      closeLists();
      closeQuote();
      pushContentBlock(tocItems.length ? renderTocHtml(tocItems, tocMode, { numbered: ($("content_type")?.value || "") !== "travel_tip" }) : renderPreviewTocPlaceholder(tocMode));
      continue;
    }

    const imageMatch = line.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
    if (imageMatch) {
      closeLists();
      closeQuote();
      pushContentBlock(`<figure class="preview-figure"><img ${renderOptimizedImageAttrs(imageMatch[2], { widths: [480, 768, 960, 1200], sizes: "(max-width: 760px) 100vw, 760px", fallbackWidth: 960, fit: "scale-down", quality: 85 })} alt="${escapeHtml(imageMatch[1])}" loading="lazy"></figure>`);
      continue;
    }

    if (
      line.includes("|") &&
      lineIndex + 1 < lines.length &&
      isMarkdownTableSeparatorRow(String(lines[lineIndex + 1] || "").trim())
    ) {
      closeLists();
      closeQuote();

      const tableLines = [line, String(lines[lineIndex + 1] || "").trim()];
      let rowIndex = lineIndex + 2;
      while (rowIndex < lines.length) {
        const rowLine = String(lines[rowIndex] || "").trim();
        if (!isMarkdownTableBodyRow(rowLine)) break;
        tableLines.push(rowLine);
        rowIndex += 1;
      }

      pushContentBlock(renderMarkdownTableFromLines(tableLines));
      lineIndex = rowIndex - 1;
      continue;
    }

    const headingMatch = line.match(/^(#{2,6})\s+(.+)$/);
    if (headingMatch) {
      closeLists();
      closeQuote();
      const level = Math.min(6, headingMatch[1].length);
      if (level === 2) {
        maybeInsertAffiliateCtaAtSectionEnd();
        h2Count += 1;
        const beforeInlineItems = getInlineImageItems(inlineImages)
          .filter((item) => item.placement === "before" && item.position === h2Count);
        if (beforeInlineItems.length && useHotelSectionLabelAnchor && isHotelReviewSectionLabelHtml(htmlParts[htmlParts.length - 1])) {
          const sectionLabelHtml = htmlParts.pop();
          contentBlockCount = Math.max(0, contentBlockCount - 1);
          beforeInlineItems.forEach((item) => {
            pushContentBlock(renderInlineImageFigure(item, item.index, "preview-inline-image--before-section-label"));
          });
          pushContentBlock(markPreviewSectionLabelAfterImageHtml(sectionLabelHtml));
        } else {
          beforeInlineItems.forEach((item) => {
            pushContentBlock(renderInlineImageFigure(item, item.index));
          });
        }
      }
      const headingText = normalizeArticleHeadingText(level, headingMatch[2].trim());
      const headingId = buildHeadingSlug(headingText, slugCounts);
      const hotelMagazineH3Line = level === 3 && (
        options.styleHotelSeries === true || options.hotelReviewSectionImageAnchor === true
      )
        ? '<span class="post-style-hotel-h3-line" aria-hidden="true"></span>'
        : "";
      pushContentBlock(`<h${level} id="${escapeHtml(headingId)}">${hotelMagazineH3Line}${renderHeadingText(level, headingText)}</h${level}>`);
      if (level === 2 && pendingStyleHotelHeadingData) {
        const badgesHtml = renderStyleHotelPreviewBadges(pendingStyleHotelHeadingData);
        if (badgesHtml) pushContentBlock(badgesHtml);
        skipStyleHotelLeadList = true;
        pendingStyleHotelHeadingData = null;
      }
      if (level === 2) {
        getInlineImageItems(inlineImages)
          .filter((item) => item.placement === "after" && item.position === h2Count)
          .forEach((item) => {
            pushContentBlock(renderInlineImageFigure(item, item.index));
          });
        (affiliates.items || []).forEach((item, index) => {
          const target = Math.max(1, parseInt(item?.position || index + 1, 10) || index + 1);
          if (item?.enabled && h2Count === target) {
            pushContentBlock(renderAffiliatePreviewCard(item, index + 1));
          }
        });
        activeAffiliateCtaItems = affiliateCta?.enabled
          ? (affiliateCta.items || []).filter((item) => item?.enabled !== false && clampAffiliateCtaPosition(item?.position || 1) === h2Count)
          : [];
      }
      continue;
    }

    if (/^>\s?/.test(line)) {
      closeLists();
      if (!inBlockquote) {
        maybeInsertAd();
        htmlParts.push("<blockquote>");
        inBlockquote = true;
      }
      htmlParts.push(`<p>${inlineFormat(line.replace(/^>\s?/, ""))}</p>`);
      contentBlockCount += 1;
      continue;
    }

    const ulMatch = line.match(/^[-*]\s+(.+)$/);
    if (ulMatch) {
      closeQuote();
      if (!inUl) {
        closeLists();
        maybeInsertAd();
        htmlParts.push("<ul>");
        inUl = true;
      }
      htmlParts.push(`<li>${inlineFormat(ulMatch[1])}</li>`);
      contentBlockCount += 1;
      continue;
    }

    const olMatch = line.match(/^\d+\.\s+(.+)$/);
    if (olMatch) {
      closeQuote();
      if (!inOl) {
        closeLists();
        maybeInsertAd();
        htmlParts.push("<ol>");
        inOl = true;
      }
      htmlParts.push(`<li>${inlineFormat(olMatch[1])}</li>`);
      contentBlockCount += 1;
      continue;
    }

    closeLists();
    closeQuote();
    pushContentBlock(`<p>${inlineFormat(line)}</p>`);
  }

  closeLists();
  closeQuote();
  maybeInsertAffiliateCtaAtSectionEnd();
  if (styleHotelEndingOpen) {
    htmlParts.push("</section>");
  }

  while (options.showAds && adPointer < adPositions.length) {
    htmlParts.push(renderPreviewAdBox(adPointer));
    adPointer += 1;
  }

  const html = htmlParts.join("");
  return html || '<p class="preview-empty">본문을 입력하면 여기에 미리보기가 표시됩니다.</p>';
}


function renderPreviewHotelKeyPoints(value = []) {
  const items = orderHotelKeyPointsForDisplay(normalizeHotelKeyPoints(value));
  if (!items.length) return "";
  return `
    <section class="preview-hotel-key-points" aria-label="핵심 포인트 요약">
      <h2>핵심 포인트 요약</h2>
      <div class="preview-hotel-key-points__grid">
        ${items.map((item) => `<div class="preview-hotel-key-point" aria-label="${escapeHtml(item.label)}: ${escapeHtml(item.text)}"><span class="preview-hotel-key-point__icon" aria-hidden="true">${renderHotelKeyPointIcon(item.key)}</span><span class="preview-hotel-key-point__sr-only">${escapeHtml(item.label)}</span><span class="preview-hotel-key-point__text">${escapeHtml(item.text)}</span></div>`).join("")}
      </div>
    </section>
  `;
}

function renderPreview() {
  const previewEl = $("previewContent");
  if (!previewEl) return;

  const title = $("title").value.trim() || "제목을 입력해 주세요";
  const contentTypeLabel = labelContentType($("content_type")?.value || "");
  const destination = getSelectedDestination();
  const destinationMeta = [destination?.country, getDestinationLabel(destination)].filter(Boolean).join(" · ");
  const summary = $("summary").value.trim();
  const plainSummary = stripMarkdown(summary);
  const metaDescription = $("meta_description").value.trim();
  const coverData = collectCoverImageFormData();
  const coverImage = coverData.ok ? coverData.image : "";
  const coverImageAlt = $("cover_image_alt")?.value.trim() || "";
  const affiliateDisclosure = $("affiliate_disclosure")?.value.trim() || "";
  const contentMd = stripLsiKeywordsTokenLines($("content_md").value || "");
  const inlineImages = collectInlineImageFormData();
  const affiliateMeta = collectAffiliateFormData();
  const affiliateCtaMeta = collectAffiliateCtaFormData();
  const contentLengthWithoutSpaces = countTextWithoutSpaces(contentMd);
  const showPreviewAds = shouldShowInarticleAdsInEditor();
  const previewAdPositions = showPreviewAds ? getPreviewAdInsertPositions(contentMd, contentLengthWithoutSpaces) : [];
  const faqMd = $("faq_md")?.value || "";
  const faqItems = parseFaqMarkdown(faqMd);
  const tags = parseTags($("tags").value);
  const hotelHero = isHotelIntroContentSelected()
    ? collectHotelHeroFormData()
    : { name: "", name_en: "", area: "", star_rating: "", guest_rating: "", pick_type: "", pick_text: "", price_level: "", badges: [], price_url: "" };
  const hotelBadges = normalizeHotelHeroBadges(hotelHero.badges);
  const hotelTitleMeta = [
    normalizeHotelPickState(hotelHero).label,
    hotelHero.area || "",
    formatHeroStarRating(hotelHero.star_rating),
    formatHeroGuestRating(hotelHero.guest_rating)
  ].filter(Boolean);
  const slug = $("slugPreview").value.trim();
  const snippetUrl = slug ? `${window.location.origin}/post/${encodeURIComponent(slug)}/` : `${window.location.origin}/post/slug-example/`;

  previewEl.innerHTML = `
    <article class="preview-article">
      <section class="preview-snippet" aria-label="SEO 스니펫 미리보기">
        <div class="small preview-snippet__label">SEO 스니펫 미리보기</div>
        <div class="preview-snippet__title">${escapeHtml(title)}</div>
        <div class="preview-snippet__url">${escapeHtml(snippetUrl)}</div>
        <div class="preview-snippet__desc">${escapeHtml(metaDescription || plainSummary || '메타디스크립션을 입력하면 검색 결과 설명이 여기에 표시됩니다.')}</div>
      </section>

      <div class="preview-post-card">
      ${coverImage ? renderPreviewCoverImage(coverData, coverImageAlt || `${title} 대표 이미지`) : ""}
      ${affiliateDisclosure ? `<p class="post-affiliate-disclosure preview-affiliate-disclosure">${escapeHtml(affiliateDisclosure)}</p>` : ""}
      ${isHotelIntroContentSelected() ? renderPreviewHotelKeyPoints(hotelHero.key_points || []) : ""}
      <header class="preview-article__head">
        <div class="row" style="justify-content:space-between;align-items:flex-start;gap:10px">
          <div class="row" style="gap:6px;flex-wrap:wrap;">
            ${contentTypeLabel ? `<span class="badge">${escapeHtml(contentTypeLabel)}</span>` : ""}
            ${destinationMeta ? `<span class="badge">${escapeHtml(destinationMeta)}</span>` : ""}
            ${!contentTypeLabel && !destinationMeta ? '<span class="badge">여행 노출 미설정</span>' : ""}
          </div>
          <span class="small">${new Date().toISOString().slice(0, 10)}</span>
        </div>
        ${hotelTitleMeta.length ? `<div class="preview-hotel-title-meta">${hotelTitleMeta.map((item, index) => `<span${index === hotelTitleMeta.length - 1 && hotelHero.guest_rating ? ' class="preview-hotel-title-rating"' : ''}>${index === hotelTitleMeta.length - 1 && hotelHero.guest_rating ? '<span aria-hidden="true">★</span> ' : ''}${escapeHtml(item)}</span>`).join("")}</div>` : ""}
        <h1 class="preview-title">${escapeHtml(title)}</h1>
        ${hotelBadges.length ? `<div class="preview-hotel-feature-badges">${hotelBadges.map((badge) => `<span>${escapeHtml(badge)}</span>`).join("")}</div>` : ""}
        ${summary ? `<div class="preview-summary preview-summary--markdown">${markdownToHtml(summary)}</div>` : ""}
        ${tags.length ? `<div class="row">${tags.map((tag) => `<span class="tag-chip">#${escapeHtml(tag)}</span>`).join("")}</div>` : ""}
      </header>
      <section class="preview-body${($("content_type")?.value || "") === "top5_series" ? " preview-body--top5-series" : ""}${($("content_type")?.value || "") === "travel_tip" ? " preview-body--travel-tip" : ""}">${markdownToHtml(contentMd, { adPositions: previewAdPositions, showAds: showPreviewAds, inlineImages, affiliates: affiliateMeta, affiliateCta: affiliateCtaMeta, hotelReviewSectionImageAnchor: ($("content_type")?.value || "") === "hotel_intro", styleHotelSeries: ($("content_type")?.value || "") === "top5_series" })}</section>
      ${faqItems.length ? `
        <section class="preview-faq" aria-label="자주 묻는 질문">
          <h2>자주 묻는 질문</h2>
          <div class="preview-faq__list">
            ${faqItems.map((item) => `
              <details class="preview-faq__item">
                <summary class="preview-faq__question"><span>${escapeHtml(item.question)}</span></summary>
                <div class="preview-faq__answer">${markdownToHtml(item.answerMd)}</div>
              </details>
            `).join("")}
          </div>
        </section>
      ` : ""}
    </div>
    </article>
  `;
}

function openPreview() {
  const drawer = $("previewDrawer");
  const backdrop = $("previewBackdrop");
  const openBtn = $("previewOpenBtn");
  if (!drawer || !backdrop || !openBtn) return;
  renderPreview();
  backdrop.hidden = false;
  drawer.classList.add("is-open");
  drawer.setAttribute("aria-hidden", "false");
  openBtn.setAttribute("aria-expanded", "true");
  document.body.classList.add("has-preview-open");
}

function closePreview() {
  const drawer = $("previewDrawer");
  const backdrop = $("previewBackdrop");
  const openBtn = $("previewOpenBtn");
  if (!drawer || !backdrop || !openBtn) return;
  drawer.classList.remove("is-open");
  drawer.setAttribute("aria-hidden", "true");
  backdrop.hidden = true;
  openBtn.setAttribute("aria-expanded", "false");
  document.body.classList.remove("has-preview-open");
}

function setPreviewDevice(device) {
  const stage = $("previewStage");
  const frame = $("previewFrame");
  if (!stage || !frame) return;
  stage.dataset.device = device;
  frame.classList.remove("preview-frame--pc", "preview-frame--tablet", "preview-frame--mobile");
  frame.classList.add(`preview-frame--${device}`);
  document.querySelectorAll("[data-preview-width]").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.previewWidth === device);
  });
}


function broadcastPostSaved(payload = {}, slug = "") {
  try {
    localStorage.setItem("beStayablePostUpdated", JSON.stringify({
      slug,
      destination_slug: payload.destination_slug || "",
      region_slug: payload.region_slug || "",
      content_type: payload.content_type || "",
      status: payload.status || "published",
      ts: Date.now()
    }));
  } catch (_) {}
}

async function save() {
  const statusEl = $("saveStatus");
  statusEl.textContent = "저장 중…";

  const title = $("title").value.trim();
  const slug = slugify(title);

  const normalizedContentType = normalizeContentType($("content_type")?.value || "");
  const shouldSaveHotelHero = normalizedContentType === "hotel_intro";
  const shouldSaveRecommendationCategory = normalizedContentType === "top5_series";
  const selectedRecommendationCategory = getSelectedRecommendationCategory();
  const selectedHotelPick = shouldSaveHotelHero ? collectHotelPickFormData() : { type: "", text: "", label: "" };

  if (selectedHotelPick.type === "custom" && !selectedHotelPick.text) {
    statusEl.textContent = "기타 픽 라벨 문구를 입력해 주세요.";
    $("heroHotelPickCustomText")?.focus();
    return;
  }

  const coverData = collectCoverImageFormData({ validate: true });
  if (!coverData.ok) {
    statusEl.textContent = coverData.error || "대표 이미지 정보를 확인해 주세요.";
    if (window.CoverImageSourceUtils?.getSelectedSource() === "agoda") $("agoda_image_html")?.focus();
    else $("cover_image")?.focus();
    return;
  }

  if (normalizedContentType === "top5_series" && window.StyleHotelEditor?.isActive()) {
    const styleHotelValidation = window.StyleHotelEditor.validateAndSync();
    if (!styleHotelValidation.ok) {
      statusEl.textContent = styleHotelValidation.error || "호텔별 본문 입력 내용을 확인해 주세요.";
      styleHotelValidation.focus?.focus();
      return;
    }
  }

  const inlineImageValidation = collectInlineImageFormData({ validate: true });
  if (!inlineImageValidation.ok) {
    statusEl.textContent = inlineImageValidation.error || "아고다 본문 이미지 정보를 확인해 주세요.";
    const invalidIndex = inlineImageValidation.invalidIndex || 1;
    document.querySelector('input[name="inlineImageEditorSource"][value="agoda"]')?.click();
    $(`agodaInlineImage${invalidIndex}Html`)?.focus();
    return;
  }

  const payload = {
    slug,
    title,
    category: "",
    content_type: normalizedContentType,
    destination_slug: $("destination_slug")?.value.trim() || "",
    region_slug: $("region_slug")?.value.trim() || "",
    region_name: getRegionLabel(getSelectedRegion()),
    recommendation_category_slug: shouldSaveRecommendationCategory ? ($("recommendationCategorySlug")?.value.trim() || "") : "",
    recommendation_category_name: shouldSaveRecommendationCategory ? getRecommendationCategoryLabel(selectedRecommendationCategory) : "",
    recommendation_category_description: shouldSaveRecommendationCategory ? getRecommendationCategoryDescription(selectedRecommendationCategory) : "",
    hotel_pick_label: shouldSaveHotelHero ? selectedHotelPick.label : "",
    hotel_hero: shouldSaveHotelHero ? collectHotelHeroFormData() : {},
    mood_tags: shouldSaveHotelHero ? getCheckedCurationValues() : [],
    situation_tags: [],
    meta_description: $("meta_description").value.trim(),
    summary: $("summary").value.trim(),
    cover_image: coverData.image,
    cover_image_alt: coverData.alt,
    cover_image_source: coverData.source,
    cover_image_link_url: coverData.link,
    cover_image_srcset: coverData.srcset,
    affiliate_disclosure: $("affiliate_disclosure")?.value.trim() || "",
    focus_keyword: $("focusKeyword")?.value.trim() || "",
    longtail_keywords: parseKeywords($("longtailKeywords")?.value || ""),
    seo_keywords: {
      focus: $("focusKeyword")?.value.trim() || "",
      longtail: parseKeywords($("longtailKeywords")?.value || ""),
      lsi: parseKeywords($("lsiKeywords")?.value || "")
    },
    status: $("status").value,
    enable_sidebar_ad: Boolean($("enable_sidebar_ad")?.checked),
    enable_inarticle_ads: Boolean($("enable_inarticle_ads")?.checked),
    tags: parseTags($("tags").value),
    content_md: buildContentWithMetaTokens($("content_md").value),
    faq_md: $("faq_md") ? $("faq_md").value : ""
  };

  if (!title || !payload.content_md.trim()) {
    statusEl.textContent = "제목과 본문은 필수입니다.";
    return;
  }

  if (!payload.content_type || !payload.destination_slug) {
    statusEl.textContent = "글 종류, 나라, 도시를 모두 선택해 주세요.";
    return;
  }

  const res = await fetch("/api/posts", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    statusEl.textContent = json?.message || "저장 실패";
    console.error(json);
    return;
  }

  broadcastPostSaved(payload, slug);

  if (payload.status === "draft") {
    statusEl.textContent = "초안 저장 완료! 미리보기 페이지로 이동합니다…";
    location.href = `/post/${encodeURIComponent(slug)}/?preview=1&v=${Date.now()}`;
    return;
  }

  statusEl.textContent = "발행 완료! 공개 페이지로 이동합니다…";
  location.href = `/post/${encodeURIComponent(slug)}/`;
}

function handleRealtimeChange() {
  const tocStatus = $("tocStatus");
  if (tocStatus) tocStatus.textContent = "";
  syncHotelHeroCardVisibility();
  syncInlineImageVisibility();
  syncAffiliateSectionVisibility();
  syncTocControlsFromContent();
  updateSlugPreview();
  updateAllCounts();
  renderSeoChecklist();
  renderPreview();
}

const inlineImageFieldIds = [
  ...Array.from({ length: INLINE_IMAGE_LIMIT }, (_, offset) => {
    const index = offset + 1;
    return [`inlineImage${index}Id`, `inlineImage${index}Alt`, `inlineImage${index}Caption`, `inlineImage${index}Position`, `inlineImage${index}Placement`];
  }).flat(),
  ...Array.from({ length: AGODA_INLINE_IMAGE_LIMIT }, (_, offset) => {
    const index = offset + 1;
    return [`agodaInlineImage${index}Html`, `agodaInlineImage${index}Alt`, `agodaInlineImage${index}Caption`, `agodaInlineImage${index}Position`, `agodaInlineImage${index}Placement`];
  }).flat()
];

["title", "meta_description", "summary", "affiliate_disclosure", "content_md", "faq_md", "focusKeyword", "longtailKeywords", "lsiKeywords", "cover_image", "agoda_image_html", "cover_image_alt", "tags", "content_type", "country", "destination_slug", "region_slug", "recommendationCategorySlug", "heroHotelPickCustomText", "heroHotelName", "heroHotelNameEn", "heroHotelLocationType", "heroHotelStarRating", "heroHotelPriceUrl", "heroKeyPointAttractions", "heroKeyPointTransport", "heroKeyPointDiningShopping", "heroKeyPointSignature", ...inlineImageFieldIds, "affiliateImageUrl1", "affiliateLinkUrl1", "affiliateProductName1", "affiliateCurrentPrice1", "affiliateSalePrice1", "affiliateDiscountRate1", "affiliateButtonText1", "affiliatePosition1", "affiliateImageUrl2", "affiliateLinkUrl2", "affiliateProductName2", "affiliateCurrentPrice2", "affiliateSalePrice2", "affiliateDiscountRate2", "affiliateButtonText2", "affiliatePosition2", "affiliateImageUrl3", "affiliateLinkUrl3", "affiliateProductName3", "affiliateCurrentPrice3", "affiliateSalePrice3", "affiliateDiscountRate3", "affiliateButtonText3", "affiliatePosition3", "affiliateImageUrl4", "affiliateLinkUrl4", "affiliateProductName4", "affiliateCurrentPrice4", "affiliateSalePrice4", "affiliateDiscountRate4", "affiliateButtonText4", "affiliatePosition4", "affiliateImageUrl5", "affiliateLinkUrl5", "affiliateProductName5", "affiliateCurrentPrice5", "affiliateSalePrice5", "affiliateDiscountRate5", "affiliateButtonText5", "affiliatePosition5", "affiliateCtaButtonText", "affiliateCtaLinkUrl", "affiliateCtaPosition"].forEach((id) => {
  const el = $(id);
  if (el) el.addEventListener("input", handleRealtimeChange);
  if (el && (el.tagName === "SELECT" || el.type === "checkbox")) el.addEventListener("change", handleRealtimeChange);
});

for (let index = 1; index <= INLINE_IMAGE_LIMIT; index += 1) {
  $(`enableInlineImage${index}`)?.addEventListener("change", handleRealtimeChange);
}
for (let index = 1; index <= AGODA_INLINE_IMAGE_LIMIT; index += 1) {
  $(`enableAgodaInlineImage${index}`)?.addEventListener("change", handleRealtimeChange);
}
document.querySelectorAll('input[name="inlineImageEditorSource"]').forEach((input) => {
  input.addEventListener("change", () => { syncInlineImageSourcePanels(); handleRealtimeChange(); });
});
$("enableAffiliateLinks")?.addEventListener("change", handleRealtimeChange);
$("enableAffiliateCta")?.addEventListener("change", () => { syncAffiliateCtaVisibility(); handleRealtimeChange(); });
$("addAffiliateCtaBtn")?.addEventListener("click", addAffiliateCtaEditorRow);
$("affiliateCtaList")?.addEventListener("input", handleRealtimeChange);
$("affiliateCtaList")?.addEventListener("change", handleRealtimeChange);
$("affiliateCtaList")?.addEventListener("click", (event) => {
  const removeButton = event.target.closest("[data-remove-affiliate-cta]");
  if (removeButton) removeAffiliateCtaEditorRow(removeButton);
});
$("enable_inarticle_ads")?.addEventListener("change", handleRealtimeChange);
$("enable_sidebar_ad")?.addEventListener("change", handleRealtimeChange);
document.querySelectorAll('input[name="heroHotelBadge"]').forEach((input) => {
  input.addEventListener("change", handleRealtimeChange);
});
bindHotelPickControls();
window.CoverImageSourceUtils?.bind(handleRealtimeChange);
$("addAffiliateItemBtn")?.addEventListener("click", () => { addAffiliateItemCard(); handleRealtimeChange(); });
document.querySelectorAll("[data-affiliate-remove]").forEach((button) => {
  button.addEventListener("click", () => { removeAffiliateItemCard(Number(button.dataset.affiliateRemove || "0")); handleRealtimeChange(); });
});
if ($("saveBtn")) $("saveBtn").addEventListener("click", save);
bindTravelSettingsManagerEvents();
$("enableToc")?.addEventListener("change", applyTocControls);
$("includeTocH3")?.addEventListener("change", () => {
  if (!$("enableToc")?.checked) return;
  applyTocControls();
});
$("previewOpenBtn")?.addEventListener("click", openPreview);
$("previewCloseBtn")?.addEventListener("click", closePreview);
$("previewBackdrop")?.addEventListener("click", closePreview);
document.querySelectorAll("[data-preview-width]").forEach((button) => {
  button.addEventListener("click", () => setPreviewDevice(button.dataset.previewWidth || "pc"));
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") { closePreview(); closeTravelSettingsModal(); }
});

syncAffiliateCtaVisibility();
if ($("title") && $("content_md")) {
  syncInlineImageVisibility();
  syncAffiliateSectionVisibility();
  syncTocControlsFromContent();
  bindTravelPlacementEvents();
  renderContentTypeOptions();
  loadTravelSettings();
  updateSlugPreview();
  updateAllCounts();
  renderSeoChecklist();
  renderPreview();
  setPreviewDevice("pc");
} else {
  console.warn("add.html 에디터 폼 요소가 누락되어 초기화를 건너뜁니다.");
}


// Hotel curation taxonomy (Travel by Mood)
let hotelCurationItems = [];
let hotelCurationLoadSequence = 0;

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initHotelKeyPointsEditor,{once:true});
else initHotelKeyPointsEditor();

function getCheckedCurationValues(){
  return Array.from(document.querySelectorAll('input[name="travelMoodSlug"]:checked'))
    .map((input)=>String(input.value||"").trim())
    .filter(Boolean);
}
function setCheckedCurationValues(values=[]){
  const selected=new Set(Array.isArray(values)?values.map((value)=>String(value||"").trim()):[]);
  document.querySelectorAll('input[name="travelMoodSlug"]').forEach((input)=>{input.checked=selected.has(String(input.value||"").trim());});
}
function renderHotelCurationOptions(selectedMood=[]){
  const el=$("travelMoodOptions");
  if(!el)return;
  const active=hotelCurationItems
    .filter(x=>x.type==="mood"&&Number(x.is_active??1)!==0)
    .sort((a,b)=>(Number(a.sort_order||0)-Number(b.sort_order||0))||String(a.name).localeCompare(String(b.name),"ko"));
  el.innerHTML=active.length
    ? active.map(x=>`<label class="editor-curation-checkbox-option"><input type="checkbox" name="travelMoodSlug" value="${escapeHtml(x.slug)}"><span>${escapeHtml(x.name)}</span></label>`).join("")
    : '<div class="small editor-curation-checkbox-empty">등록된 Travel by Mood 항목이 없습니다.</div>';
  setCheckedCurationValues(selectedMood);
  el.querySelectorAll('input[name="travelMoodSlug"]').forEach((input)=>input.addEventListener('change',handleRealtimeChange));
}
async function loadHotelCurationItems(selectedMood=[]){
  const sequence=++hotelCurationLoadSequence;
  try{
    const r=await fetch(`/api/curation-items?ts=${Date.now()}`,{credentials:"same-origin",cache:"no-store"});
    const j=await r.json().catch(()=>({}));
    if(sequence!==hotelCurationLoadSequence)return;
    hotelCurationItems=Array.isArray(j.items)?j.items:[];
    renderHotelCurationOptions(selectedMood);
  }catch(e){
    if(sequence===hotelCurationLoadSequence)console.warn("큐레이션 항목을 불러오지 못했습니다.",e);
  }
}
function syncHotelCurationCardVisibility(){const show=isHotelIntroContentSelected();document.querySelectorAll('.editor-hotel-curation-card').forEach(card=>{card.hidden=!show;card.setAttribute('aria-hidden',show?'false':'true');});}
document.addEventListener('DOMContentLoaded',()=>{loadHotelCurationItems();syncHotelCurationCardVisibility();$('content_type')?.addEventListener('change',syncHotelCurationCardVisibility);});
