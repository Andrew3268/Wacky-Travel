import { okJson, getAdminSession, requireAdmin } from "../_utils.js";
import { normalizeContentType } from "../../lib/travel/travel-settings.js";
import { normalizeCoverImagePayload, ensureCoverImageColumns } from "../../lib/posts/cover-image.js";
import { ensurePublicModifiedDateColumn, isMissingPublicModifiedColumnError } from "../../lib/posts/public-modified-date.js";
import { normalizeAffiliateDisclosure, ensureAffiliateDisclosureColumn } from "../../lib/posts/affiliate-disclosure.js";

function clampInt(value, fallback, min, max) {
  const num = Number.parseInt(String(value || ""), 10);
  if (!Number.isFinite(num)) return fallback;
  return Math.min(max, Math.max(min, num));
}

function slugifyValue(value = "") {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9\-가-힣]/g, "")
    .replace(/\-+/g, "-")
    .replace(/^-|-$/g, "");
}


function normalizeStatusValue(value = "published") {
  const raw = String(value || "published").trim().toLowerCase();
  if (["draft", "초안", "임시저장", "임시 저장"].includes(raw)) return "draft";
  return "published";
}


const HOTEL_HERO_BADGE_OPTIONS = Object.freeze([
  "훌륭한 위치",
  "뚜벅이 최적",
  "깔끔한 위생",
  "친절한 서비스",
  "쇼핑·맛집 중심",
  "높은 만족도",
  "공항 이동 편리",
  "전망 좋은 뷰",
  "넓고 쾌적한 객실",
  "조식 맛집",
  "아이동반 최적",
  "커플 여행 최적",
  "호캉스 최적",
]);


const HOTEL_KEY_POINT_OPTIONS = Object.freeze([
  ["attractions", "명소 접근성"],
  ["transport", "대중교통"],
  ["airport", "공항 접근성"],
  ["dining_shopping", "맛집 및 쇼핑"],
  ["signature", "호텔 시그니처"]
]);

function normalizeHotelKeyPoints(value = []) {
  let source = value;
  if (!Array.isArray(source)) {
    try { source = JSON.parse(String(source || "[]")); } catch (_) { source = []; }
  }
  const input = new Map((Array.isArray(source) ? source : []).map((item) => [String(item?.key || "").trim(), String(item?.text || "").replace(/\s+/g, " ").trim().slice(0, 240)]));
  return HOTEL_KEY_POINT_OPTIONS.map(([key, label]) => ({ key, label, text: input.get(key) || "" })).filter((item) => item.text);
}

function normalizeBadgeArray(value) {
  const source = Array.isArray(value)
    ? value
    : String(value || "").split(/[,.，、|]/);
  const selected = new Set(source.map((item) => String(item || "").trim()).filter(Boolean));
  return HOTEL_HERO_BADGE_OPTIONS.filter((item) => selected.has(item));
}

function normalizeHotelPickLabel(value = "") {
  const label = String(value || "").replace(/\s+/g, " ").trim().slice(0, 30);
  if (!label) return "";
  return label === "가성비" ? "가성비픽" : label;
}

async function ensureHotelColumns(db) {
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN badges_json TEXT DEFAULT '[]'`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN name_en TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN area TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN star_rating TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN guest_rating TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN price_level TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN region_slug TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN region_name TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE hotels ADD COLUMN key_points_json TEXT DEFAULT '[]'`).run(); } catch (_) {}
}

async function ensurePostRegionColumns(db) {
  await ensureCoverImageColumns(db);
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN region_slug TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN region_name TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN recommendation_category_slug TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN recommendation_category_name TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN recommendation_category_description TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN hotel_pick_label TEXT DEFAULT ''`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN mood_tags_json TEXT DEFAULT '[]'`).run(); } catch (_) {}
  try { await db.prepare(`ALTER TABLE posts ADD COLUMN situation_tags_json TEXT DEFAULT '[]'`).run(); } catch (_) {}
  await ensurePublicModifiedDateColumn(db);
  await ensureAffiliateDisclosureColumn(db);
  try { await db.prepare(`CREATE INDEX IF NOT EXISTS idx_posts_region_slug ON posts(region_slug)`).run(); } catch (_) {}
  try { await db.prepare(`CREATE INDEX IF NOT EXISTS idx_posts_destination_region ON posts(destination_slug, region_slug)`).run(); } catch (_) {}
  try { await db.prepare(`CREATE INDEX IF NOT EXISTS idx_posts_recommendation_category ON posts(recommendation_category_slug)`).run(); } catch (_) {}
  try { await db.prepare(`CREATE INDEX IF NOT EXISTS idx_posts_destination_recommendation_category ON posts(destination_slug, recommendation_category_slug)`).run(); } catch (_) {}
}

function isHeroValueBadgeEnabled(value = "") {
  const raw = String(value ?? "").trim().toLowerCase();
  return value === true || raw === "1" || raw === "true" || raw === "yes" || raw.includes("가성비");
}

function normalizeHeroLocationType(value = "") {
  const raw = String(value || "").replace(/\s+/g, " ").trim();
  const aliases = {
    "시내중심": "시내 중심",
    "도심": "시내 중심",
    "도심권": "시내 중심",
    "중심부": "시내 중심",
    "중심가": "중심가 인근",
    "관광지근처": "관광지 인근",
    "관광지 주변": "관광지 인근",
    "해변근처": "해변 근처",
    "비치 근처": "해변 근처",
    "공항근처": "공항 근처",
    "역 근처": "역세권",
    "역 주변": "역세권",
    "외각": "외곽"
  };
  return aliases[raw] || raw;
}

function normalizeHeroGuestRating(value = "") {
  const raw = String(value || "").trim().replace(/^평점\s*/i, "");
  const normalized = raw.match(/^(6(?:\.5)?|7(?:\.5)?|8(?:\.5)?|9(?:\.5)?)\+?$/)?.[1];
  return normalized ? `${normalized}+` : "";
}

function hasHotelHeroInput(hero = {}) {
  const badges = Array.isArray(hero.badges) ? hero.badges : String(hero.badges || hero.badges_json || "").trim();
  return Boolean(
    String(hero.name || hero.name_ko || "").trim() ||
    String(hero.name_en || "").trim() ||
    normalizeHeroLocationType(hero.area || hero.location_type || "") ||
    String(hero.star_rating || "").trim() ||
    normalizeHeroGuestRating(hero.guest_rating || hero.guest_score || hero.review_rating || "") ||
    isHeroValueBadgeEnabled(hero.price_level || hero.value_badge || "") ||
    badges ||
    normalizeHotelKeyPoints(hero.key_points || hero.key_points_json || []).length ||
    String(hero.price_url || hero.primary_url || "").trim()
  );
}

async function syncHotelHeroData(db, body = {}, { destinationSlug = "", regionSlug = "", regionName = "", fallbackSlug = "", title = "", now = "" } = {}) {
  const hero = body.hotel_hero && typeof body.hotel_hero === "object" ? body.hotel_hero : {};
  const nameInput = String(hero.name || hero.name_ko || "").trim();
  const nameEn = String(hero.name_en || "").trim();
  const area = normalizeHeroLocationType(hero.area || hero.location_type || "");
  const priceLevel = isHeroValueBadgeEnabled(hero.price_level || hero.value_badge || "") ? "가성비" : "";
  const hasHeroInput = hasHotelHeroInput(hero);
  const name = nameInput || (hasHeroInput ? String(title || "").trim() : "");
  const explicitHotelSlug = String(body.hotel_slug || hero.slug || fallbackSlug || "").trim();
  const hotelSlug = explicitHotelSlug || (name ? slugifyValue(nameEn || name) : "");

  if (!hasHeroInput || !hotelSlug || !name || !destinationSlug) return hotelSlug;

  const starRating = String(hero.star_rating || "").trim();
  const guestRating = normalizeHeroGuestRating(hero.guest_rating || hero.guest_score || hero.review_rating || "");
  const badges = normalizeBadgeArray(hero.badges || hero.badges_json || "");
  const keyPoints = normalizeHotelKeyPoints(hero.key_points || hero.key_points_json || []);
  const summary = String(hero.summary || body.summary || "").trim();
  const coverImage = String(body.cover_image || "").trim();
  const coverImageAlt = String(body.cover_image_alt || name || title || "").trim();
  const publishedAt = String(body.published_at || now);

  await ensureHotelColumns(db);

  await db.prepare(`
    INSERT INTO hotels (
      slug, destination_slug, region_slug, region_name, name, name_en, area, star_rating, guest_rating, badges_json, key_points_json, price_level, summary,
      cover_image, cover_image_alt, status, published_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', ?, ?)
    ON CONFLICT(slug) DO UPDATE SET
      destination_slug = excluded.destination_slug,
      region_slug = excluded.region_slug,
      region_name = excluded.region_name,
      name = excluded.name,
      name_en = excluded.name_en,
      area = excluded.area,
      star_rating = excluded.star_rating,
      guest_rating = excluded.guest_rating,
      badges_json = excluded.badges_json,
      key_points_json = excluded.key_points_json,
      price_level = excluded.price_level,
      summary = excluded.summary,
      cover_image = excluded.cover_image,
      cover_image_alt = excluded.cover_image_alt,
      status = 'published',
      updated_at = excluded.updated_at
  `).bind(
    hotelSlug,
    destinationSlug,
    regionSlug,
    regionName,
    name,
    nameEn,
    area,
    starRating,
    guestRating,
    JSON.stringify(badges),
    JSON.stringify(keyPoints),
    priceLevel,
    summary,
    coverImage,
    coverImageAlt,
    publishedAt,
    now
  ).run();

  const primaryUrl = String(hero.price_url || hero.primary_url || "").trim();
  const links = [
    primaryUrl ? { provider: "hero_price", label: "객실 가격 확인하기", affiliate_url: primaryUrl, button_text: "객실 가격 확인하기", sort_order: 1 } : null
  ].filter(Boolean);

  await db.prepare(`DELETE FROM hotel_affiliate_links WHERE hotel_slug = ? AND provider IN ('hero_price', 'hero_availability')`).bind(hotelSlug).run();
  for (const link of links) {
      await db.prepare(`
        INSERT INTO hotel_affiliate_links (hotel_slug, provider, label, affiliate_url, button_text, sort_order, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
      `).bind(
        hotelSlug,
        link.provider,
        link.label,
        link.affiliate_url,
        link.button_text,
        link.sort_order,
        now,
        now
      ).run();
  }

  return hotelSlug;
}

const BLOCKED_SINGLE_SEARCH_KEYWORDS = new Set(["호텔", "숙소", "여행", "추천"]);

function normalizePublicSearchQuery(value = "") {
  return String(value || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function isBlockedSingleSearchKeyword(value = "") {
  return BLOCKED_SINGLE_SEARCH_KEYWORDS.has(normalizePublicSearchQuery(value));
}

async function loadPostListItems(db, sql, binds = []) {
  try {
    return await db.prepare(sql).bind(...binds).all();
  } catch (error) {
    const message = String(error?.message || error || "");
    const missingAffiliateDisclosure = /no such column:\s*(?:posts\.)?affiliate_disclosure/i.test(message);
    if (!isMissingPublicModifiedColumnError(error) && !missingAffiliateDisclosure) throw error;
    const fallbackSql = sql
      .replace(
        "COALESCE(NULLIF(content_modified_at, ''), published_at) AS content_modified_at",
        "published_at AS content_modified_at"
      )
      .replace("      affiliate_disclosure,", "      '' AS affiliate_disclosure,");
    return db.prepare(fallbackSql).bind(...binds).all();
  }
}

export async function onRequestGet({ env, request }) {
  const url = new URL(request.url);
  const status = String(url.searchParams.get("status") || "published").trim().toLowerCase();
  const category = String(url.searchParams.get("category") || "").trim();
  const tag = String(url.searchParams.get("tag") || "").trim();
  const moodTag = String(url.searchParams.get("mood_tag") || "").trim();
  const situationTag = String(url.searchParams.get("situation_tag") || "").trim();
  const contentTypeParam = String(url.searchParams.get("content_type") || url.searchParams.get("content_types") || "").trim();
  const contentTypes = [...new Set(contentTypeParam.split(/[,.，、|]/).map((item) => normalizeContentType(item)).filter(Boolean))].slice(0, 10);
  const query = String(url.searchParams.get("q") || "").trim().toLowerCase();
  const searchTitle = String(url.searchParams.get("search_title") || "1").trim() !== "0";
  const searchContent = String(url.searchParams.get("search_content") || "0").trim() === "1";
  const sort = String(url.searchParams.get("sort") || url.searchParams.get("order") || "").trim().toLowerCase();
  const page = clampInt(url.searchParams.get("page"), 1, 1, 9999);
  const perPage = clampInt(url.searchParams.get("per_page"), 8, 1, 24);
  const offset = (page - 1) * perPage;

  if (query && isBlockedSingleSearchKeyword(query)) {
    return okJson({
      items: [],
      blocked: true,
      blocked_reason: "broad_single_keyword",
      message: "검색어가 너무 넓습니다. 도시, 지역 또는 여행 조건을 함께 입력해 주세요.",
      examples: ["다낭 호텔", "하카타역 숙소", "공항 근처 호텔"],
      pagination: { page, per_page: perPage, total: 0, total_pages: 1, has_more: false, next_page: null }
    }, { headers: { "cache-control": "no-store" } });
  }

  const allowedStatuses = new Set(["published", "draft", "all"]);
  const requestedStatus = allowedStatuses.has(status) ? status : "published";
  const includeDraftsIfAdmin = requestedStatus === "published"
    && ["1", "true", "yes", "on"].includes(String(url.searchParams.get("include_drafts_if_admin") || "").trim().toLowerCase());
  const adminRequested = ["1", "true", "yes"].includes(String(url.searchParams.get("admin") || "").trim().toLowerCase());
  const requiresAdmin = adminRequested || requestedStatus !== "published";
  const shouldCheckAdmin = requiresAdmin || includeDraftsIfAdmin;
  const admin = shouldCheckAdmin ? await getAdminSession(env, request) : null;

  if (requiresAdmin && !admin) {
    return okJson({ message: "관리자 로그인이 필요합니다." }, {
      status: 401,
      headers: { "cache-control": "private, no-store" }
    });
  }

  const safeStatus = includeDraftsIfAdmin
    ? (admin ? "all" : "published")
    : (admin ? requestedStatus : "published");

  const where = [];
  const binds = [];

  if (safeStatus !== "all") {
    where.push("status = ?");
    binds.push(safeStatus);
  }

  if (category) {
    where.push("TRIM(COALESCE(category, '')) = ?");
    binds.push(category);
  }

  if (tag) {
    where.push("EXISTS (SELECT 1 FROM json_each(COALESCE(tags_json, '[]')) WHERE TRIM(json_each.value) = ?)");
    binds.push(tag);
  }

  if (moodTag) {
    where.push("EXISTS (SELECT 1 FROM json_each(COALESCE(mood_tags_json, '[]')) WHERE TRIM(json_each.value) = ?)");
    binds.push(moodTag);
  }

  if (situationTag) {
    where.push("EXISTS (SELECT 1 FROM json_each(COALESCE(situation_tags_json, '[]')) WHERE TRIM(json_each.value) = ?)");
    binds.push(situationTag);
  }

  if (contentTypes.length) {
    where.push(`TRIM(COALESCE(content_type, '')) IN (${contentTypes.map(() => "?").join(", ")})`);
    binds.push(...contentTypes);
  }

  if (query) {
    const qLike = `%${query}%`;
    const queryParts = [];

    if (searchTitle) {
      queryParts.push(`LOWER(COALESCE(title, '')) LIKE ?`);
      binds.push(qLike);
    }

    if (searchContent) {
      queryParts.push(`LOWER(COALESCE(summary, '')) LIKE ?`);
      queryParts.push(`LOWER(COALESCE(meta_description, '')) LIKE ?`);
      queryParts.push(`LOWER(COALESCE(category, '')) LIKE ?`);
      queryParts.push(`LOWER(COALESCE(content_md, '')) LIKE ?`);
      queryParts.push(`EXISTS (
        SELECT 1
        FROM json_each(COALESCE(tags_json, '[]'))
        WHERE LOWER(TRIM(json_each.value)) LIKE ?
      )`);
      binds.push(qLike, qLike, qLike, qLike, qLike);
    }

    if (!queryParts.length) {
      queryParts.push(`LOWER(COALESCE(title, '')) LIKE ?`);
      binds.push(qLike);
    }

    where.push(`(${queryParts.join(" OR ")})`);
  }

  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const orderSql = sort === "published" || sort === "published_at"
    ? "ORDER BY published_at DESC, updated_at DESC"
    : "ORDER BY updated_at DESC, published_at DESC";

  const itemsSql = `
    SELECT
      slug,
      title,
      category,
      meta_description,
      summary,
      cover_image,
      cover_image_alt,
      cover_image_source,
      cover_image_link_url,
      cover_image_srcset,
      focus_keyword,
      longtail_keywords_json,
      enable_sidebar_ad,
      enable_inarticle_ads,
      tags_json,
      content_type,
      destination_slug,
      region_slug,
      region_name,
      recommendation_category_slug,
      recommendation_category_name,
      recommendation_category_description,
      hotel_pick_label,
      mood_tags_json,
      situation_tags_json,
      hotel_slug,
      (SELECT h.name FROM hotels h WHERE h.slug = posts.hotel_slug LIMIT 1) AS hotel_name,
      (SELECT h.name_en FROM hotels h WHERE h.slug = posts.hotel_slug LIMIT 1) AS hotel_name_en,
      affiliate_enabled,
      affiliate_disclosure,
      search_intent,
      status,
      view_count,
      published_at,
      COALESCE(NULLIF(content_modified_at, ''), published_at) AS content_modified_at,
      updated_at
    FROM posts
    ${whereSql}
    ${orderSql}
    LIMIT ? OFFSET ?
  `;

  const countSql = `SELECT COUNT(*) AS total FROM posts ${whereSql}`;

  const baseBind = [...binds];
  const statusCountWhereSql = admin ? "" : whereSql;
  const statusCountBinds = admin ? [] : [...binds];
  const [itemsRows, countRow, categoryRows, popularRows, statusRows] = await Promise.all([
    loadPostListItems(env.TRAVEL_DB, itemsSql, [...baseBind, perPage, offset]),
    env.TRAVEL_DB.prepare(countSql).bind(...binds).first(),
    env.TRAVEL_DB.prepare(`
      SELECT TRIM(COALESCE(category, '')) AS category_name, COUNT(*) AS count
      FROM posts
      ${whereSql}
      GROUP BY TRIM(COALESCE(category, ''))
      ORDER BY count DESC, category_name COLLATE NOCASE ASC
      LIMIT 20
    `).bind(...binds).all(),
    env.TRAVEL_DB.prepare(`
      SELECT slug, title, view_count, updated_at, published_at
      FROM posts
      ${whereSql}
      ORDER BY view_count DESC, updated_at DESC, published_at DESC
      LIMIT 10
    `).bind(...binds).all(),
    env.TRAVEL_DB.prepare(`
      SELECT status, COUNT(*) AS count
      FROM posts
      ${statusCountWhereSql}
      GROUP BY status
    `).bind(...statusCountBinds).all()
  ]);

  const total = Number(countRow?.total || 0);
  const totalPages = Math.max(1, Math.ceil(total / perPage));
  const statusMap = new Map((statusRows?.results || []).map((row) => [String(row.status || "published").trim().toLowerCase(), Number(row.count || 0)]));
  const publicCacheHeaders = includeDraftsIfAdmin
    ? { "cache-control": "private, no-store", "vary": "Cookie" }
    : (!admin && safeStatus === "published"
      ? { "cache-control": "public, max-age=30, s-maxage=60" }
      : { "cache-control": "private, no-store" });

  return okJson({
    items: itemsRows.results || [],
    filters: {
      status: safeStatus,
      category,
      tag,
      mood_tag: moodTag,
      situation_tag: situationTag,
      content_type: contentTypes.join(","),
      q: query
    },
    pagination: {
      page,
      per_page: perPage,
      total,
      total_pages: totalPages,
      has_more: page < totalPages,
      next_page: page < totalPages ? page + 1 : null
    },
    sidebar: {
      counts: {
        total,
        published: statusMap.get("published") || 0,
        draft: statusMap.get("draft") || 0
      },
      categories: (categoryRows.results || []).map((row) => ({
        name: String(row.category_name || "").trim() || "미분류",
        count: Number(row.count || 0)
      })),
      popular: (popularRows.results || []).map((row) => ({
        slug: row.slug,
        title: row.title,
        view_count: Number(row.view_count || 0),
        updated_at: row.updated_at,
        published_at: row.published_at
      }))
    }
  }, { headers: publicCacheHeaders });
}

export async function onRequestPost({ env, request }) {
  const admin = await requireAdmin(env, request);
  if (!admin) return okJson({ message: "관리자 로그인이 필요합니다." }, { status: 401 });
  const body = await request.json().catch(() => null);
  if (!body) {
    return okJson({ message: "JSON이 필요합니다." }, { status: 400 });
  }

  const slug = String(body.slug || "").trim();
  const title = String(body.title || "").trim();
  const category = String(body.category || "").trim();
  const metaDescription = String(body.meta_description || "").trim();
  const summary = String(body.summary || "").trim();
  const coverData = normalizeCoverImagePayload(body);
  if (!coverData.ok) return okJson({ message: coverData.message }, { status: 400 });
  const coverImage = coverData.image;
  const coverImageAlt = coverData.alt;
  const coverImageSource = coverData.source;
  const coverImageLinkUrl = coverData.link;
  const coverImageSrcset = coverData.srcset;
  const focusKeyword = String(body.focus_keyword || "").trim();
  const longtailKeywords = Array.isArray(body.longtail_keywords) ? body.longtail_keywords : [];
  const contentMd = String(body.content_md || "").trim();
  const faqMd = String(body.faq_md || "").trim();
  const enableSidebarAd = body.enable_sidebar_ad === true ? 1 : 0;
  const enableInarticleAds = body.enable_inarticle_ads === true ? 1 : 0;
  const status = normalizeStatusValue(body.status || "published");
  const tags = Array.isArray(body.tags) ? body.tags : [];
  const contentType = normalizeContentType(body.content_type || "travel_tip");
  const destinationSlug = String(body.destination_slug || "").trim();
  const regionSlug = String(body.region_slug || "").trim();
  const regionName = String(body.region_name || "").trim();
  const recommendationCategorySlug = String(body.recommendation_category_slug || "").trim();
  const recommendationCategoryName = String(body.recommendation_category_name || "").trim();
  const recommendationCategoryDescription = String(body.recommendation_category_description || "").trim();
  const hotelPickLabel = contentType === "hotel_intro" ? normalizeHotelPickLabel(body.hotel_pick_label || "") : "";
  const moodTags = Array.isArray(body.mood_tags) ? [...new Set(body.mood_tags.map(slugifyValue).filter(Boolean))] : [];
  const situationTags = Array.isArray(body.situation_tags) ? [...new Set(body.situation_tags.map(slugifyValue).filter(Boolean))] : [];
  let hotelSlug = String(body.hotel_slug || "").trim();
  const affiliateEnabled = body.affiliate_enabled === true || body.affiliate_enabled === 1 || body.affiliate_enabled === "1" ? 1 : 0;
  const affiliateDisclosure = normalizeAffiliateDisclosure(body.affiliate_disclosure);
  const searchIntent = String(body.search_intent || "").trim();

  if (!slug || !title || !contentMd) {
    return okJson(
      { message: "slug, title, content_md는 필수입니다." },
      { status: 400 }
    );
  }

  const now = new Date().toISOString();
  await ensurePostRegionColumns(env.TRAVEL_DB);
  hotelSlug = await syncHotelHeroData(env.TRAVEL_DB, body, { destinationSlug, regionSlug, regionName, fallbackSlug: slug, title, now });

  await env.TRAVEL_DB.prepare(`
    INSERT INTO posts (
      slug,
      title,
      category,
      meta_description,
      summary,
      cover_image,
      cover_image_alt,
      cover_image_source,
      cover_image_link_url,
      cover_image_srcset,
      focus_keyword,
      longtail_keywords_json,
      tags_json,
      content_md,
      faq_md,
      enable_sidebar_ad,
      enable_inarticle_ads,
      content_type,
      destination_slug,
      region_slug,
      region_name,
      recommendation_category_slug,
      recommendation_category_name,
      recommendation_category_description,
      hotel_pick_label,
      mood_tags_json,
      situation_tags_json,
      hotel_slug,
      affiliate_enabled,
      affiliate_disclosure,
      search_intent,
      status,
      published_at,
      content_modified_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(slug) DO UPDATE SET
      title = excluded.title,
      category = excluded.category,
      meta_description = excluded.meta_description,
      summary = excluded.summary,
      cover_image = excluded.cover_image,
      cover_image_alt = excluded.cover_image_alt,
      cover_image_source = excluded.cover_image_source,
      cover_image_link_url = excluded.cover_image_link_url,
      cover_image_srcset = excluded.cover_image_srcset,
      focus_keyword = excluded.focus_keyword,
      longtail_keywords_json = excluded.longtail_keywords_json,
      tags_json = excluded.tags_json,
      content_md = excluded.content_md,
      faq_md = excluded.faq_md,
      enable_sidebar_ad = excluded.enable_sidebar_ad,
      enable_inarticle_ads = excluded.enable_inarticle_ads,
      content_type = excluded.content_type,
      destination_slug = excluded.destination_slug,
      region_slug = excluded.region_slug,
      region_name = excluded.region_name,
      recommendation_category_slug = excluded.recommendation_category_slug,
      recommendation_category_name = excluded.recommendation_category_name,
      recommendation_category_description = excluded.recommendation_category_description,
      hotel_pick_label = excluded.hotel_pick_label,
      mood_tags_json = excluded.mood_tags_json,
      situation_tags_json = excluded.situation_tags_json,
      hotel_slug = excluded.hotel_slug,
      affiliate_enabled = excluded.affiliate_enabled,
      affiliate_disclosure = excluded.affiliate_disclosure,
      search_intent = excluded.search_intent,
      status = excluded.status,
      published_at = excluded.published_at,
      content_modified_at = COALESCE(NULLIF(posts.content_modified_at, ''), posts.published_at, excluded.content_modified_at),
      updated_at = excluded.updated_at
  `).bind(
    slug,
    title,
    category,
    metaDescription,
    summary,
    coverImage,
    coverImageAlt,
    coverImageSource,
    coverImageLinkUrl,
    coverImageSrcset,
    focusKeyword,
    JSON.stringify(longtailKeywords),
    JSON.stringify(tags),
    contentMd,
    faqMd,
    enableSidebarAd,
    enableInarticleAds,
    contentType,
    destinationSlug,
    regionSlug,
    regionName,
    recommendationCategorySlug,
    recommendationCategoryName,
    recommendationCategoryDescription,
    hotelPickLabel,
    JSON.stringify(moodTags),
    JSON.stringify(situationTags),
    hotelSlug,
    affiliateEnabled,
    affiliateDisclosure,
    searchIntent,
    status,
    now,
    now,
    now
  ).run();

  return okJson({ ok: true, slug });
}
