# Be Stayable

- v11: 오사카·도쿄·삿포로·오키나와 hotel-location-survey 결과 정확도 보정 로직 추가 및 결과 문구 일부 개선. SSR Blog


## 2026-08-03 여행 스타일별 호텔 추천 H3·특징 뱃지 보완

- `top5_series` 본문의 H3가 모바일에서도 한 줄로 유지되도록 `flex-wrap: nowrap`과 `white-space: nowrap`을 적용했습니다.
- H3 글자 크기를 17px로 조정했습니다.
- 호텔 특징 뱃지 문단의 글자 크기를 16px, 글자 굵기를 400으로 조정했습니다.
- 실제 포스트와 add/edit 미리보기 스타일을 동일하게 맞췄습니다.

Be Stayable은 독립적으로 운영되는 여행 제휴마케팅/애드센스 블로그입니다.  
도시 허브는 정적 HTML로 제공하고, Cloudflare Pages Functions + D1 + SSR은 게시글·국가 페이지·API에 사용하도록 구성되어 있습니다.



## 도시 목적 페이지 공통 정적 템플릿

15개 도시의 아래 5개 목적 페이지는 하나의 공통 렌더러와 도시별 JSON 데이터에서 정적 HTML로 생성합니다.

```text
first-trip
value-hotel
near-trip
family-trip
quiet-stay
```

- 공통 렌더러: `src/purpose-pages/render-purpose-page.mjs`
- 도시별 원본 데이터: `src/purpose-pages/data/{city}/`
- 정적 HTML 생성: `tools/build-purpose-pages.mjs`
- 구조 검사: `tools/test-purpose-page-template.mjs`
- 공통 자산 설정: `src/purpose-pages/config.mjs`
- 배포 결과: `public/destinations/{city}/{purpose}/index.html`

`public/destinations/{city}/{purpose}/index.html`은 빌드 결과물이므로 직접 수정하지 않습니다. 문구·호텔·FAQ·메타데이터는 도시별 JSON에서 수정하고, 클래스와 섹션 구조는 공통 렌더러에서만 변경합니다.

```bash
npm run build:purpose-pages
npm run check:purpose-page-template
```

브라우저에서는 JSON이나 템플릿을 불러오지 않습니다. Cloudflare Pages 배포 전에 75개의 완성된 정적 HTML을 생성하므로 페이지 요청 시 D1·Function·클라이언트 렌더링이 추가되지 않습니다.

## 출시 라우팅 수정

- `functions/destinations/[slug].js` 동적 도시 라우트를 제거했습니다.
- `/destinations/{city}/` 요청은 `public/destinations/{city}/index.html` 정적 페이지를 제공합니다.
- 전체 HTML 미들웨어 적용은 유지하되, 정적 도시 페이지를 동적 SSR이 가로채지 않도록 분리했습니다.
- 배포 전 검사에서 15개 도시 정적 메인 페이지와 동적 도시 Functions 부재를 확인합니다.

## bestayable-v1.12 변경 요약

- 일본 5개 도시 메인 index 페이지 Area Guide에서 `wt-city-area-panel__eyebrow`와 `wt-city-area-panel__decision span`의 좌우 패딩을 0으로 조정했습니다.
- 데스크탑에서 Area Guide의 정보 그리드와 한 줄 판단 영역 사이, 한 줄 판단 영역 하단 간격을 줄였습니다.
- 압축파일에는 `README.md` 외 별도 Markdown 문서를 포함하지 않도록 정리했습니다.


## Be Stayable 브랜드 전환

- 실제 서비스명: `Be Stayable(비스테이어블)`
- 공식 도메인: `https://bestayable.com`
- 기존 Cloudflare Pages 프로젝트명 `wacky-travel`, D1 데이터베이스명 `wacky-travel-db`, 바인딩명 `TRAVEL_DB`는 배포 연결을 보호하기 위해 유지합니다.
- 기존 운영 D1의 `site_name`은 `npm run d1:migrate:brand:remote`로 갱신합니다. 로컬 D1은 `npm run d1:migrate:brand`를 사용합니다.
- 도메인 연결 전에는 `CUSTOM_DOMAIN_CONNECTED = "false"`, `ENFORCE_SITE_ORIGIN = "false"`를 유지합니다. 연결 완료 후 두 값을 `true`로 전환합니다.

## 핵심 구조

```text
functions/
  post/[slug].js                  일반 여행 글 SSR
  api/                            관리자/글/여행지 설정 API

lib/travel/
  travel-utils.js                 여행 공통 헤더/푸터/SEO head
  seo-jsonld.js                   JSON-LD 생성

db/
  schema.sql                      D1 기본 스키마
  seed.sql                        샘플 여행 데이터
```

## V24 변경 요약

- 도시 상세 페이지에서 `top5_series`, `hotel_intro`, `hotel_roundup`, `hotel_review` 글은 호텔 추천 카드 영역에만 카드형으로 노출됩니다.
- 일반 여행 팁 글은 기존처럼 `travel-list__item` 리스트형으로 유지됩니다.
- 여행 스타일별 호텔 추천 글의 `destination_slug`가 비어 있어도 제목, 요약, 태그, 카테고리에 도시명이 포함되면 해당 도시 페이지 호텔 추천 카드에 보완 노출됩니다.
- 글 대표 이미지 수정 후 도시 페이지와 글 상세 페이지에 즉시 반영되도록 글 수정일 기반 캐시 키와 이미지 버전 파라미터를 적용했습니다.

## V28 변경 요약

- 도시 상세 페이지 호텔 탭의 초기 SSR 노출 개수를 3개로 조정했습니다.
- 더보기 클릭 시 각 탭에서 최대 3개씩만 추가 로드되도록 조정했습니다.
- V27 테스트용 후쿠오카 더미 데이터 마이그레이션과 seed 반영분을 제거했습니다.

## V29 변경 요약

- index 메인 페이지에서 `여행 스타일별 호텔 추천` 섹션은 `top5_series` 글이 1개 이상 있을 때만 노출되도록 변경했습니다.
- index 메인 페이지에서 `최신 여행 글` 섹션은 최신 글 데이터가 1개 이상 있을 때만 노출되도록 변경했습니다.
- 글이 없을 때 기존에 보이던 빈 안내 카드 대신 섹션 내부 콘텐츠를 비우고 섹션 전체를 숨기도록 조정했습니다.
- 숨겨진 섹션으로 이동하는 상단 메뉴/히어로 CTA도 글 존재 여부에 맞춰 함께 노출되도록 보완했습니다.

## V30 변경 요약

- 나라 페이지의 `top5_series`, `hotel_intro`, `travel_tip` 하위 섹션은 각 분류에 글이 1개 이상 있을 때만 노출됩니다.
- 세 분류 모두 글이 없을 경우 `최근 업데이트된 나라 여행 관련 글` 부모 섹션까지 함께 숨겨 빈 영역이 남지 않도록 보완했습니다.

## V31 변경 요약

- `/destinations/도시` 페이지의 `hotel-tabs__nav` 버튼은 연결된 글이 1개 이상 있는 분류만 출력되도록 변경했습니다.
- `top5_series` 글이 없으면 `여행 스타일별 호텔 추천` 탭 버튼과 패널이 렌더링되지 않습니다.
- `hotel_intro` 글이 없으면 `추천 호텔 리뷰` 탭 버튼과 패널이 렌더링되지 않습니다.
- 두 호텔 분류가 모두 비어 있을 경우 `호텔 추천` 섹션 전체가 숨겨져 빈 탭 영역이 남지 않도록 보완했습니다.
- `/destinations/도시` 페이지의 `도시명 여행 콘텐츠` 섹션은 일반 여행 콘텐츠가 1개 이상 있을 때만 노출되도록 변경했습니다.
- 여행 콘텐츠가 없을 때 기존 빈 안내 카드가 보이지 않도록 제거했습니다.

## V32 변경 요약

- `add.html`과 `edit.html`의 `호텔 히어로 정보` 입력 섹션은 글 종류가 `추천 호텔 리뷰`(`hotel_intro`)일 때만 노출되도록 변경했습니다.
- 글 종류가 `여행 스타일별 호텔 추천` 또는 `여행이 쉬워지는 작은 팁` 등 다른 값일 때는 `card editor-option-card editor-hotel-hero-card` 섹션이 화면에 표시되지 않습니다.
- 데이터 로딩 전에도 호텔 히어로 섹션이 잠깐 보이지 않도록 초기 HTML에 `hidden` 처리를 추가했습니다.
- 비호텔 글로 저장할 때는 호텔 히어로 연결값이 저장 payload에 남지 않도록 정리했습니다.
- 미리보기에서도 `추천 호텔 리뷰` 글이 아닐 경우 호텔 히어로 패널이 표시되지 않도록 맞췄습니다.

## Cloudflare D1 설정

```text
Cloudflare Pages 프로젝트명: wacky-travel
D1 데이터베이스명: wacky-travel-db
D1 바인딩명: TRAVEL_DB
```

`wrangler.toml` 예시:

```toml
name = "wacky-travel"
compatibility_date = "2026-03-25"
pages_build_output_dir = "public"

[[d1_databases]]
binding = "TRAVEL_DB"
database_name = "wacky-travel-db"
database_id = "YOUR_D1_DATABASE_ID"
```

## 실행 명령어

```bash
npm install
npm run dev
```

원격 D1에 테이블과 샘플 데이터를 넣을 때:

```bash
npx wrangler d1 execute wacky-travel-db --remote --file=./db/schema.sql
npx wrangler d1 execute wacky-travel-db --remote --file=./db/seed.sql
```

## 배포 설정

Cloudflare Pages에서 GitHub 저장소를 연결한 뒤 아래처럼 설정합니다.

```text
Framework preset: None
Build command: npm run build
Build output directory: public
D1 binding name: TRAVEL_DB
D1 database: wacky-travel-db
```

## 확인 URL

```text
/
/destinations/danang
/post/danang-hotel-location-guide
/sitemap.xml
```

## 운영 전 수정할 값

- `wrangler.toml`의 `database_id`
- `db/seed.sql`의 제휴 링크 `YOUR_CID`, `YOUR_ID`
- 실제 도메인을 연결한 뒤 `functions/post/[slug].js`, `functions/sitemap.xml.js`, `public/robots.txt`의 기본 도메인

## 주의

- 이 프로젝트의 D1 바인딩은 `TRAVEL_DB`입니다.
- 이 프로젝트의 데이터베이스 바인딩 이름은 반드시 `TRAVEL_DB`로 유지하세요.
- `node_modules`는 압축파일과 GitHub에 올리지 않습니다. `npm install`로 다시 설치합니다.

## 2026-07-12 홈 인기 여행지 이미지 로딩 수정
- Unsplash 직접 URL을 `/img/{base64url}` 동일 출처 프록시 경로로 변경했습니다.
- `functions/img/[encoded].js`의 허용 호스트에 `images.unsplash.com`을 추가했습니다.
- 관리자 `hero_image`/`cover_image`의 R2 URL도 홈 카드에서 동일 출처 프록시로 변환합니다.
- 관리자 이미지가 실패하면 카드별 레퍼런스 이미지로 자동 교체합니다.
- `travel.css` 쿼리 버전을 갱신해 기존 장기 캐시가 새 카드 CSS를 가리지 않도록 했습니다.
- 메인 인덱스에는 특정 도시 이미지 preload를 사용하지 않습니다.

## Agoda 카드 할인 찾기 통합

- 페이지: `/agoda-card-discount/`
- 딥링크 변환 API: `POST /api/resolve-agoda-link`
- 지원 입력: 일반 Agoda 호텔 URL, `https://www.agoda.com/sp/...` 앱 공유 링크
- `/sp/` 링크는 Cloudflare Pages Function이 리디렉션을 추적해 일반 호텔 URL로 변환합니다.
- 페이지 전용 CSS 클래스는 `wt-agoda-` 접두어를 사용해 기존 스타일과 충돌하지 않도록 분리했습니다.
- `/hotel-promotions/`의 Agoda 카드 할인 항목에서 새 페이지로 연결됩니다.

## 기술 SEO 운영 설정

이 버전은 공개 HTML, 동적 게시물, 도시 허브가 동일한 URL 정책을 사용하도록 구성되어 있습니다.

- 공개 페이지 URL: 후행 슬래시(`/`)로 통일
- canonical·Open Graph·JSON-LD: `SITE_ORIGIN` 기준 절대 URL로 응답
- 사이트맵: 실제 색인 가능 정적 HTML과 D1의 발행 글·도시를 합쳐 자동 생성
- 검색·관리자·API·오류 페이지: `noindex` 및 캐시 제한
- 호텔 목록 페이지: 최초 HTML에 발행 글 링크를 서버 렌더링
- 정적 자산: 장기 캐시, HTML: 재검증 캐시
- 보안 헤더: CSP, HSTS, MIME 스니핑 차단, 프레임 제한, Referrer Policy 적용

사용자 지정 도메인을 연결할 때 `wrangler.toml`의 값을 실제 주소로 변경합니다.

```toml
[vars]
SITE_ORIGIN = "https://bestayable.com"
CUSTOM_DOMAIN_CONNECTED = "true"
ENFORCE_SITE_ORIGIN = "true"
```

`ENFORCE_SITE_ORIGIN = "true"`이면 다른 호스트로 들어온 공개 페이지 요청을 `SITE_ORIGIN`으로 308 리디렉션합니다. 도메인 연결 전에는 `false`로 유지합니다.

배포 전 검증:

```bash
npm run check
```

Cloudflare Pages의 권장 빌드 설정:

```text
Build command: npm run build
Build output directory: public
```

전체 회귀 검사는 Git 업로드 전 또는 배포 전 별도로 실행합니다.

```bash
npm run check
```

배포 후 확인 주소:

```text
https://운영도메인/robots.txt
https://운영도메인/sitemap.xml
```

## 2026-07-31 도시 메인 관리자 전용 추천 호텔 버튼

- 모바일 CSS의 강제 `display: inline-flex` 선택자가 `hidden` 속성을 덮어쓰던 문제를 수정했습니다.
- 모바일 표시 규칙은 `:not([hidden])` 상태의 버튼에만 적용됩니다.
- 15개 도시 메인 페이지에서 추천 호텔 버튼은 관리자 인증 전과 로그아웃 상태에 숨겨집니다.


## 2026-08-02 2차 성능 최적화

- 포스트 조회수 증가는 `waitUntil()`으로 분리해 HTML 응답과 Edge Cache 적중 응답을 막지 않습니다.
- 검색 API는 스키마 `PRAGMA` 검사와 본문 500건 선조회를 제거하고, 필요한 컬럼만 DB 페이지네이션으로 조회합니다.
- 검색 실패 시 `/api/posts`를 최대 30페이지 순회하던 예비 검색을 제거했습니다.
- 기존 `status` 값은 `016_status_normalization.sql`로 한 번 정규화하고, 읽기 쿼리는 `status = 'published'`처럼 직접 비교합니다.
- HTML과 이미지의 Edge Cache 저장은 `waitUntil()`에서 처리합니다.

운영 D1 적용 명령:

```bash
npm run d1:migrate:status-normalization:remote
```

## 2026-08-02 3차 프런트엔드 최적화

- 기존 약 891KB의 `travel.css`를 공통·홈·도시·목적별·아카이브·서베이 CSS로 분리했습니다.
- 완전히 동일한 CSS 규칙 75개를 제거하고, 페이지 유형에 필요한 기능 CSS만 로드합니다.
- 모든 로컬 CSS의 캐시 버전을 `20260803-frontend-v4` 하나로 통일했습니다.
- 15개 도시 서베이는 도시별 데이터 파일과 공통 실행 엔진으로 분리했습니다.
- 일반 엔진은 10개 도시, 고급 엔진은 4개 도시가 공유하며 후쿠오카는 기존 정밀 점수 보정 로직을 유지한 분리 엔진을 사용합니다.
- `npm run check:phase3-frontend`에서 CSS 분리, 버전 통일, 서베이 엔진 연결 및 15개 도시 초기 실행을 검증합니다.


## 여행 스타일별 호텔 추천 세트 메타 정보 (2026-08-03)
- 각 호텔 세트에 성급(3~5성급), 평점(6.5+~9.5+), 뱃지 텍스트 입력을 추가했습니다.
- 값은 기존 `content_md`의 `STYLE_HOTEL_IMAGE` 토큰에 저장되어 별도 D1 마이그레이션이 필요하지 않습니다.
- 실제 포스트와 add/edit 미리보기에서 호텔 이미지 아래에 성급·평점·뱃지가 표시됩니다.


## 여행 스타일별 호텔 추천 이미지 뱃지 보완 (2026-08-03)
- 호텔별 메타 입력에서 `뱃지` 명칭을 `특징 뱃지`로 변경했습니다.
- 성급·평점 아래에 특징 뱃지 70%, 이미지 뱃지 30%의 한 줄 입력 영역을 추가했습니다.
- 이미지 뱃지는 호텔 이미지 왼쪽 상단에 검은색 배경과 흰색 텍스트로 출력됩니다.
- 평점 메타의 border와 border-radius를 실제 포스트와 미리보기에서 모두 제거했습니다.

## 2026-08-03 여행 스타일별 호텔 추천 시각 조정 v8

- 호텔 성급·평점 메타 항목의 개별 패딩을 제거하고 메타 전체의 글자색과 굵기를 통일했습니다.
- 특징 뱃지 폰트 크기를 17px로 조정했습니다.
- 이미지 뱃지 좌우 패딩을 모든 화면에서 30px로 통일하고, 상단 위치를 데스크톱·태블릿 19px, 모바일 20px로 조정했습니다.
- 호텔 성급·평점 메타 하단 여백을 모든 화면에서 5px로 조정했습니다.
- 포스트 본문 이미지의 테두리를 제거했습니다.
- CSS 캐시 버전과 동적 포스트 렌더 캐시 버전을 갱신했습니다.


## 2026-08-03 여행 스타일별 호텔 추천 H3·마무리 본문 보완 (v9)

- `top5_series` 글의 H3 상·하단 테두리 제거
- H3 폰트 크기 18px 적용
- H3 제목 오른쪽에 제한된 길이의 실선 추가
- 기존 호텔 리뷰 H3 테두리 규칙의 적용 범위를 `top5_series` 외 글로 제한
- `[[STYLE_HOTEL_ENDING]]` 이후 Markdown을 `.post-style-hotel-ending` 섹션으로 묶고 상단 구분선 적용
- add/edit 미리보기에도 동일한 H3 및 마무리 구분선 적용
- 포스트 Edge Cache 렌더 버전 갱신
- CSS 버전 `20260803-frontend-v10`로 통일
- D1 SQL 변경 없음

## 2026-08-03 가이드형 포스트 H3 최종 보완

- `body.post-page-body .post-shell--guide-style .post-body .post-content h3`의 기본·모바일·후반부 최종 선언을 `font-size: 18px`, `margin-top: 30px`로 통일했습니다.
- `top5_series` 전용 H3가 기존 값을 17px/34px로 다시 덮어쓰던 문제를 제거했습니다.
- add/edit 미리보기 H3도 18px/30px로 통일했습니다.
- CSS 캐시 버전을 `20260803-frontend-v10`, 포스트 렌더 캐시를 `20260803-guide-h3-18-v11`로 갱신했습니다.

### 2026-08-04 포스트 작성자·뱃지 레이아웃 보완
- 작성자 프로필 영역을 전체 너비로 확장하고 상·하단 테두리, 10px 패딩, 20px 세로 여백을 적용했습니다.
- 게시글 브레드크럼 너비에서 `calc(100% - 32px)` 보정을 제거하고 `min(100%, var(--container))`로 통일했습니다.
- 여행 스타일별 호텔 추천의 특징 뱃지에 상·하단 테두리와 20px 세로 패딩을 추가했습니다.
- CSS 캐시 버전을 `20260804-frontend-v13`, 포스트 렌더 캐시를 `20260804-post-author-profile-layout-v13`으로 갱신했습니다.

## 2026-08-04 모바일 포스트 이미지 보완

- 호텔 특징 뱃지 상하 패딩을 10px로 조정했습니다.
- 760px 이하 화면에서 대표 이미지와 본문 인라인 이미지만 좌우 페이지 거터를 넘어 화면 폭에 맞게 표시합니다.
- 본문 텍스트, 제목, 뱃지 등 나머지 콘텐츠의 좌우 여백은 유지합니다.

## 2026-08-04 모바일 포스트 이미지 보완 v15

- 모바일에서 대표 이미지(`post-cover-wrap`)를 포스트 좌우 거터 밖까지 확장했습니다.
- 모바일 포스트 대표 이미지와 본문 이미지의 `border-radius`를 제거했습니다.
- 모바일 호텔 이미지 뱃지를 `top: 50px`, `left: 15px`로 조정했습니다.
- 모바일 전역 H1의 `line-height`를 `1.4`로 변경했습니다.
- D1 마이그레이션은 필요하지 않습니다.

## 모바일 포스트 전체 이미지 풀블리드 보완 (2026-08-04)
- 모바일에서 대표 이미지뿐 아니라 모든 `figure.post-inline-image` 래퍼가 페이지 좌우 거터를 상쇄하도록 수정했습니다.
- R2 본문 이미지, 아고다 본문 이미지, 여행 스타일별 호텔 이미지가 화면 좌우 끝까지 표시됩니다.
- 이미지 캡션은 읽기 쉽도록 기존 모바일 거터만큼 내부 패딩을 유지합니다.
- CSS 캐시 버전 `20260807-frontend-v21`, 포스트 렌더 버전 `20260804-post-mobile-all-images-fullbleed-v16`으로 갱신했습니다.
- 도시 스냅샷 좌우 아이콘 버튼은 카드 영역과 겹치지 않도록 그리드 아래 오른쪽의 별도 컨트롤 영역에 배치합니다.
- D1 변경은 없습니다.

